out.println('Jenkins DSL wiki: https://github.com/jenkinsci/job-dsl-plugin/wiki')

def jobFolderName = 'DSL'
def jobFolderPrefix = "${jobFolderName}/"

def disabledGlobal = false
def disabledTools = false

def jdk8 = 'jdk1.8.0_121'
def descriptionDslWarning = '<font color="blue">*** DSL MAINTAINED ***</font> -- \nDO NOT MANUALLY MODIFY. \nManual config changes will not survive. \nEdit, commit and push the dsl script instead.'
def labelsSupportingChannelGitSsh = 'master'
def labelsSupportingSvapRepo = "master"


def pipelineJobPrefix = "${jobFolderPrefix}pipeline-"

def viewColumnsDef = {
	status()
	weather()
	name()
	lastSuccess()
	lastFailure()
	lastDuration()
	buildButton()
	lastBuildConsole()
}
folder(jobFolderName) {
	displayName jobFolderName
	description "${descriptionDslWarning}"
}

def viewBuildRegex = '.*pipeline.*'
listView("${jobFolderPrefix}pipeline"){
	columns viewColumnsDef
	jobs {
	  regex viewBuildRegex
	}
}

@groovy.transform.ToString(includeNames = true, includeFields=true)
class PipelineJob {
	String scmUrl
	String[] branches
	String scriptPath
	String cron = 'H/4 * * * *'
	String jdk = 'jdk1.8.0_121'
	String mailTo = 'dontabhaktuni.m@hcl.com'
}
def pipelineJobs = [
	new PipelineJob([scmUrl: 'git@github.deere.com:service-opeions/svnd.git', branches: ['master'],scriptPath:'./EmptyFile.txt',mailTo: 'dontabhaktuni.m@hcl.com']),
	
	]
	
	out.println('----- pipeline Jobs entries begin -----')
	pipelineJobs.each {
		out.println("  -- ${it}")
	}
	out.println('----- pipeline Jobsentries end -----')
	out.println()
	
	pipelineJobs.each {
		def aJob = it
		def repoPath = aJob.scmUrl
		def repoName = repoPath.substring(repoPath.lastIndexOf('/')+1)
		repoName = repoName.substring(0, repoName.indexOf('.git'))
		def  ScriptPath = aJob.scriptPath
		def branchNames = aJob.branches
		  branchNames.each {
			def branchName = it
			def isRelease = branchName == 'release'
			def jobName = jobFolderPrefix + repoName + '_pipeline-' + branchName + 'Branch'
			  pipelineJob(jobName) {
				description "Builds ${branchName}"
				logRotator (30, 100)
				jdk aJob.jdk
				label "${labelsSupportingChannelGitSsh}&&${labelsSupportingSvapRepo}"
				definition {
				cpsScm{
					scm {
						git {
							remote {
								url(repoPath)
							}
							branch branchName
					}
				}
				scriptPath(ScriptPath)
			}
		}
				publishers {
				  mailer aJob.mailTo, false, true
				}
			  }
		}
	}
