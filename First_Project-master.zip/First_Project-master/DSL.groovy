pipelineJob("DSL-Test") {
	description()
	keepDependencies(false)
	definition {
		cpsScm {
			scm {
				git {
					remote {
						github("DontabhaktuniManohar/First_Project", "https")
					}
					branch("*/master")
				}
			}
			scriptPath("EmptyFile.txt")
		}
	}
	disabled(false)
}
