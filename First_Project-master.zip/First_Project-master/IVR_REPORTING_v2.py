#!/opt/projects/anaconda3/bin/python
#############
# VERSION 2 #
#############
import collections
import pandas as pd
from pytz import timezone # 'US/Alaska', 'US/Arizona', 'US/Central', 'US/Eastern', 'US/Hawaii', 'US/Mountain', 'US/Pacific', 'UTC'
import re
import smtplib
import socket
from email.mime.text import MIMEText
from toolkit import connections


def _dict_loader(cursor,key_index):
    a={}
    for row in cursor:
        i=0
        a.update({row[key_index]:{}})
        l=len(row)
        while i<l:
            a[row[key_index]].update({cursor.description[i][0]:row[i]})
            i+=1
    return a


class IVR_REPORTING:

    def __init__(self, application_name, plan_dim_ck, dnis_type, edwcon, oraclecon):

        self.application_name=application_name
        self.plan_dim_ck=plan_dim_ck 
        self.edwcon=edwcon # edwd, edwt, edwp
        self.dnis_type=dnis_type # 'CARE IVR', 'MRKT IVR'
        self.oraclecon=oraclecon # ivrrepusertest, ivrrepuserprod

        conn = connections.edw(edwcon=self.edwcon)
        # the data type for menus and submenus is pandas.core.series.Series
        self.menus = pd.read_sql_query('SELECT APPLICATION_MENU_NAME FROM ivr_app_own.dim_ivr_menu', conn).iloc[:,0:1]
        self.submenus = pd.read_sql_query('SELECT APPLICATION_MENU_NAME FROM ivr_app_own.dim_ivr_sub_menu', conn).iloc[:,0:1]
        conn.close()

    def error_email(self,excp):

        msg=MIMEText("IVR Reporting for "+self.application_name+" errored out on "+str(socket.gethostname())+" at "+str(pd.Timestamp.today())+"\n\n"+str(excp))
        msg['Subject']=self.application_name+' IVR Reporting Failed'
        msg['From']='STL_CallCtr_Support@CENTENE.COM'
        if self.edwcon == 'edwp':
            msg['To']='alan.d.shaw@centene.com' #, ltieman@centene.com, kholder@centene.com, rhedrick@centene.com'
        else:
            msg['To']='alan.d.shaw@centene.com'
        s=smtplib.SMTP('mail.centene.com')
        s.send_message(msg)
        s.close()

    def autorun(self):
        sql = "SELECT MAX(DDTE.DATE_DATE) AS MAX_DATE \
               FROM IVR_APP_OWN.FT_IVR_CALL FCLL \
               INNER JOIN IVR_APP_OWN.DIM_DATE DDTE \
               ON FCLL.START_DATE_DIM_CK = DDTE.DATE_DIM_CK \
               INNER JOIN IVR_APP_OWN.DIM_DNIS DDNS \
               ON FCLL.DNIS_DIM_CK = DDNS.DNIS_DIM_CK \
               WHERE DDNS.PLAN_DIM_CK = ? AND DDNS.DNIS_TYPE = ?; "
        conn = connections.edw(edwcon=self.edwcon)
        # Medicare_Provider has made it such that we cannot use APPLICATION_ID as the DNIS_PLAN_NAME
        curs = conn.cursor()
        curs.execute(sql, (self.plan_dim_ck, self.dnis_type))
        from_date = curs[0]
        curs.close()
        conn.close()
        print(from_date)

    def run(self, from_date, to_date):

        # the parameters must be conformable to pandas.Timestamp, or an error will be raised here
        # Python native Datetime.Datetime should convert cleanly, because it is the parent class
        from_datetime = pd.Timestamp(from_date)
        to_datetime = pd.Timestamp(to_date)

        # ensure that the parameters are in Central Time

        if from_datetime.tz is not None: # convert to Central
            from_datetime = from_datetime.astimezone(timezone('US/Central'))
        else: # assume Central
            from_datetime = from_datetime.tz_localize(tz=timezone('US/Central'))

        if to_datetime.tz is not None: # convert to Central
            to_datetime = to_datetime.astimezone(timezone('US/Central'))
        else: # assume Central
            to_datetime = to_datetime.tz_localize(tz=timezone('US/Central'))

        # now enforce clean day boundaries
        from_datetime -= pd.Timedelta(hours=from_datetime.hour, minutes=from_datetime.minute, seconds=from_datetime.second, microseconds=from_datetime.microsecond)
        to_datetime += pd.Timedelta(days=1)
        to_datetime -= pd.Timedelta(hours=to_datetime.hour, minutes=to_datetime.minute, seconds=to_datetime.second, microseconds=to_datetime.microsecond)


        print(str(pd.Timestamp.today()) + '\tIVR Reporting: ' + self.application_name + '\tstarting ETL')

        self._extractVPAPPLOG(from_datetime, to_datetime)    
        print(str(pd.Timestamp.today()) + '\tIVR Reporting: ' + self.application_name + '\tfinished extracting from VPAPPLOG')

        self._update_transfer_groups()
        print(str(pd.Timestamp.today())+'\tIVR Reporting: ' + self.application_name + '\tfinished processing Transfer Groups and DNIS')


        # Process VPAPPLOG
        dtfs = self._processVPAPPLOG()
        print(str(pd.Timestamp.today()) + '\tIVR Reporting: ' + self.application_name + '\tfinished processing extract from VPAPPLOG')

        # Process Calls 
        if isinstance(dtfs['call'], pd.DataFrame) and len(dtfs['call']) > 0:
            self._processCall(dtfs['call'])
            print(str(pd.Timestamp.today()) + '\tIVR Reporting: ' + self.application_name + '\tfinished processing calls')
        else:
            print(str(pd.Timestamp.today()) + '\tIVR Reporting: ' + self.application_name + '\tnothing to process')
            return

        # Process Menus 
        if isinstance(dtfs['menu'], pd.DataFrame) and len(dtfs['menu']) > 0:
            self._processMenu(dtfs['menu'])
        print(str(pd.Timestamp.today()) + '\tIVR Reporting: ' + self.application_name + '\tfinished processing menus')

        # Process Submenus 
        if isinstance(dtfs['submenu'], pd.DataFrame) and len(dtfs['submenu']) > 0:
            self._processSubmenu(dtfs['submenu'])
        print(str(pd.Timestamp.today()) + '\tIVR Reporting: ' + self.application_name + '\tfinished processing submenus')

        # Process Drilldowns 
        if isinstance(dtfs['drilldown'], pd.DataFrame) and len(dtfs['drilldown']) > 0:
            self._processDrilldown(dtfs['drilldown'])
        print(str(pd.Timestamp.today()) + '\tIVR Reporting: ' + self.application_name + '\tfinished processing drilldowns')

        # Update Call Summary
        self._update_call_summary(from_date, to_date)
        print(str(pd.Timestamp.today()) + '\tIVR Reporting: ' + self.application_name + '\tfinished ETL')

        self.oracle_extract_dtf = None

    def _extractVPAPPLOG(self, from_date, to_date):    

        # LOGTIMESTAMP is Central Time but stored in the Oracle DB as VARCHAR
        # MSGTIMESTAMP is UTC but stored as TIMESTAMP without timezone
        sql  = "SELECT SESSIONID, SESSIONINDEX, SUBSTR(LOGTIMESTAMP, 1, 26) AS LOGTIMESTAMP, ACTIVITYNAME, MESSAGE, LOGTYPE, VARNAME, VARVALUE "
        sql += "FROM VPAPPLOG WHERE SESSIONID IN (SELECT DISTINCT SESSIONID FROM VPAPPLOG WHERE APPLICATIONID = :a AND MSGTIMESTAMP >= :b AND MSGTIMESTAMP < :c)"
        sql += "ORDER BY SESSIONID, SESSIONINDEX" # the subquery is needed to prevent sessions from being fragmented by the day boundaries
    
        param_list = [self.application_name,]

        if from_date.tz is None:
            param_list.append(from_date)
        else:
            param_list.append(from_date.astimezone(timezone('UTC')).tz_localize(tz=None))

        if to_date.tz is None:
            param_list.append(to_date)
        else:
            param_list.append(to_date.astimezone(timezone('UTC')).tz_localize(tz=None))

        conn = connections.oracle(oraclecon=self.oraclecon)
        self.oracle_extract_dtf = pd.read_sql_query(sql, conn, params=param_list)
        conn.close()

    def _update_transfer_groups(self):

        oracle_e_lst = []
        record = {'SessionID': None, 'dnis': None, 'callertype': None, 'tod': None, 'transfergroup': None, 'transfernumber': None, 'language': None}
        for i in range(len(self.oracle_extract_dtf.index)):

            line = self.oracle_extract_dtf.iloc[i]

            if record['SessionID'] != line[0]: # new session (call)
                if pd.notnull(record['SessionID']):
                    oracle_e_lst.append(record)
                    record = {'SessionID': None, 'dnis': None, 'callertype': None, 'tod': None, 'transfergroup': None, 'transfernumber': None, 'language': None}
                record['SessionID'] = line[0]

            if line[6] == 'var_DNIS' and re.sub('[\s|-]', '', line[7]) != '':
                record['dnis'] = line[7]

            if line[6] == 'var_CallerType' and re.sub('[\s|-]', '', line[7]) != '':
                record['callertype'] = line[7]

            if line[6] == 'var_ToDStatus' and re.sub('[\s|-]', '', line[7]) != '':
                record['tod'] = line[7]

            if line[3] == 'Transfer' and line[6] == 'var_TransferGroup' and re.sub('[\s|-]', '', line[7]) != '':
                record['transfergroup'] = line[7]

            if line[3] == 'Transfer' and line[6] == 'var_TransferNumber' and re.sub('[\s|-]', '', line[7]) != '':
                record['transfernumber'] = line[7]

            if line[3] == 'Transfer' and line[6] == 'var_Email' and re.sub('[\s|-]', '', line[7]) != '':
                record['email'] = line[7]

            if line[6] == 'var_Language' and re.sub('[\s|-]', '', line[7]) != '':
                record['language'] = line[7]

        self.transfer_groups = pd.DataFrame.from_records(oracle_e_lst)
        self.transfer_groups['callertype'] = self.transfer_groups['callertype'].map(lambda x: 'provider' if x == 'MED_MGMT' else ('member' if pd.isnull(x) else x.lower()))
        self.transfer_groups['tod'] = self.transfer_groups['tod'].map(lambda x: 'NONE' if pd.isnull(x) else x)
        self.transfer_groups['transferpoint'] = self.transfer_groups.apply(lambda row: 'NONE' if pd.isnull(row['transfernumber']) else (row['email'] if 'email' in row['transfernumber'].lower() else row['transfernumber']), axis=1)
        self.transfer_groups['language'] = self.transfer_groups['language'].map(lambda x: 'English' if pd.isnull(x) else x)
        del self.transfer_groups['SessionID']
        del self.transfer_groups['transfernumber']
        self.transfer_groups.drop_duplicates(inplace=True)
        self.transfer_groups = self.transfer_groups[['dnis','callertype','tod','transfergroup','transferpoint','language']]
        self.transfer_groups = self.transfer_groups[pd.notnull(self.transfer_groups['dnis'])]
        ######################
        self._update_dnis() # re-using this data set for DNIS, but DNIS needs to go in, first
        ######################
        self.transfer_groups = self.transfer_groups[pd.notnull(self.transfer_groups['transfergroup'])]
        if len(self.transfer_groups.index) == 0:
            return

        edw_dnis_e_sql="select min(dnis_dim_ck) as DNIS_DIM_CK, trim(dnis) as dnis from ivr_app_own.dim_dnis where dnis_type=? group by trim(dnis)"
        edw_lang_e_sql='select language_dim_ck,language_desc from ivr_app_own.dim_language'
        edw_callertype_e_sql="select min(caller_type_dim_ck) as CALLER_TYPE_DIM_CK, trim(lower(caller_type_desc)) from ivr_app_own.dim_caller_type group by 2"

        insert_sql="insert into ivr_app_own_tables.dim_transfer_grp_stage (dnis_dim_ck,language_dim_ck,caller_type_dim_ck,ToD,Transfer_Group,Transfer_Point,Createdon,Modifiedon) values (?,?,?,?,?,?,current_date,current_date)"

        insert_table_sql="insert into ivr_app_own.dim_transfer_grp (dnis_dim_ck, language_dim_ck, caller_type_dim_ck, ToD, Transfer_Group, Transfer_Point, createdon,modifiedon)    select  a.dnis_dim_ck, a.language_dim_ck, a.caller_type_dim_ck, a.ToD, a.Transfer_Group, a.Transfer_Point, a.createdon, a.modifiedon       from  ivr_app_own_tables.dim_transfer_grp_stage a left join   ivr_app_own.dim_transfer_grp b  on a.dnis_dim_ck=b.dnis_dim_ck  and a.language_dim_ck=b.language_dim_ck  and a.caller_type_dim_ck=b.caller_type_dim_ck  and a.ToD=b.ToD  and a.Transfer_Group=b.Transfer_Group  and a.Transfer_Point=b.Transfer_Point  where b.dnis_dim_ck is null"

        truncate_table_sql='delete from ivr_app_own_tables.dim_transfer_grp_stage all'

        edw_con=connections.edw(edwcon=self.edwcon)
        edw_cur=edw_con.cursor()

        edw_cur.execute(edw_dnis_e_sql,(self.dnis_type,))
        dnis=_dict_loader(edw_cur,1)

        edw_cur.execute(edw_lang_e_sql)
        lang=_dict_loader(edw_cur,1)

        edw_cur.execute(edw_callertype_e_sql)
        callertype=_dict_loader(edw_cur,1)

        edw_cur.execute(truncate_table_sql)
        edw_con.commit()

        for i in range(len(self.transfer_groups.index)):
            row = self.transfer_groups.iloc[i]
            try:
                row_dnis=dnis[str(row[0])]['DNIS_DIM_CK'] # join on dnis
            except:
                if row[0] == None:
                    row_dnis=dnis['UNKNOWN']['DNIS_DIM_CK']
                else:
                    raise ValueError('Unrecognized DNIS: ' + str(row[0]))
            try:
                row_callertype=callertype[row[1]]['CALLER_TYPE_DIM_CK'] # join on callertype
            except:
                raise ValueError('Unrecognized Caller Type: ' + str(row[1]))
            try:
                row_lang=lang[row[5]]['LANGUAGE_DIM_CK'] # join on language
            except:
                row_lang=lang['English']['LANGUAGE_DIM_CK'] # default to English
            row=(int(row_dnis),int(row_lang),int(row_callertype),row[2],row[3],row[4])
            edw_cur.execute(insert_sql,row)
        edw_cur.execute(insert_table_sql)
        edw_cur.execute(truncate_table_sql)
        edw_con.commit()
        edw_cur.close()
        edw_con.close()
        self.transfer_groups = None

    def _update_dnis(self):
        # call this WITHIN _update_transfer_groups()
        oracle_e_dtf = self.transfer_groups.copy()
        oracle_e_dtf = oracle_e_dtf[pd.notnull(oracle_e_dtf['dnis'])].drop_duplicates()

        edw_e_sql="select dnis_dim_ck, trim(dnis) from ivr_app_own.dim_dnis where dnis_type=?"
        edw_insert_sql="insert into ivr_app_own.dim_dnis (dnis,plan_dim_ck,dnis_plan_name,infrd_ind,dw_update_user,dw_update_date,dnis_type) values (?,?,?,'N','IVRUSER',current_date,?)"

        edw_con=connections.edw(edwcon=self.edwcon)
        edw_cur=edw_con.cursor()
        edw_cur.execute(edw_e_sql, (self.dnis_type,))

        dnis=_dict_loader(edw_cur,1)

        for i in range(len(oracle_e_dtf.index)):
            row = oracle_e_dtf.iloc[i]
            try:
                dnis[row[0]]
            except:
                edw_cur.execute(edw_insert_sql,(row[0],self.plan_dim_ck,self.application_name,self.dnis_type))
                edw_con.commit()
        edw_cur.close()
        edw_con.close()

    def _prepareFields(self,line):
    
        fields = dict()
        fields['SessionID']    = re.sub('\s', '', line[0]) # remove all whitespace
        #---------------------------------------------------------------
        # Temporary Fix
        # SessionIDs starting with cncpxmpp1001-, cncpxmpp1002-, cncpxmpp1003- are overflowing the target field
        if len(fields['SessionID']) > 26:
            fields['SessionID'] = re.sub('-', '', fields['SessionID'])[-26:]
        #---------------------------------------------------------------
        fields['SessionIndex'] = str(line[1])
        fields['LogTimestamp'] = re.sub('^\s*|\s*$', '', line[2]) # remove leading and trailing whitespace
        fields['Message']      = re.sub('\s', '', line[4]) # remove all whitespace
        fields['LogType']      = re.sub('\s', '', line[5]) # remove all whitespace
        fields['VarName']      = re.sub('^\s*var_|\s', '', line[6]) # remove all whitespace and the var_ prefix
        fields['VarValue']     = re.sub('^\s*|\s*$', '', line[7]) # remove leading and trailing whitespace
        #this is a minor kludge to make other code cleaner:
        if fields['VarName'] == 'MemberValidated':
            fields['ActivityName'] = 'MemberAuthentication'
        else:
            fields['ActivityName'] = re.sub('^\s*CCS_MCare_|^\s*CCS_|\s', '', line[3]) # remove all whitespace and the CCS_ prefix
        #another kludge; heaven help us:
        if (fields['VarName'] == 'CallerType' and fields['VarValue'] == 'MED_MGMT'):
            fields['VarValue'] = 'Provider'

        return fields

    def _determineLineType(self,vpapplog):
    
        if vpapplog['VarName'] in ('DNIS', 'CallerType', 'Language'):
            return 'Call'
        elif vpapplog['ActivityName'] in self.menus.values:
            return 'Menu'
        elif vpapplog['ActivityName'] in self.submenus.values:
            return 'Submenu'
        else:
            return 'Skip'

    def _processVPAPPLOG(self):

        dtfs = collections.defaultdict(dict)

        call_list = []
        menu_list = []
        submenu_list = []
        drilldown_list = []
    
        # this is a special dictionary that adds a key when it is first referenced instead of throwing a key error
        call = collections.defaultdict(dict)
        menu = collections.defaultdict(dict)
        submenu = collections.defaultdict(dict)

        for i in range(len(self.oracle_extract_dtf.index)):

            vpapplog = self._prepareFields(self.oracle_extract_dtf.iloc[i])
            lineType = self._determineLineType(vpapplog)

            if vpapplog['SessionID'] != call['SessionID']: #reset for new session
    
                if len(str(call['SessionID'])) > 2:
                    call_list.append(call)
                call = collections.defaultdict(dict)
                call['SessionID'] = vpapplog['SessionID']
                call['Start'] = vpapplog['LogTimestamp']
                call['CallerType'] = 'Member' # default; may be overridden later
                call['DNIS'] = self.application_name # default; may be overridden later
                call['Language'] = 'English' # default; may be overridden later
    
                if len(str(menu['SessionID'])) > 2:
                    menu_list.append(menu)
                menu = collections.defaultdict(dict)
                menu['SessionID'] = call['SessionID']
                menu['Menu_ID'] = vpapplog['SessionIndex']
                menu['Name'] = 'MainMenu' # default, in case no menu is encountered but a submenu is
                menu['Start'] = vpapplog['LogTimestamp']
                menu['End'] = vpapplog['LogTimestamp'] 
    
                if len(str(submenu['SessionID'])) > 2:
                    submenu_list.append(submenu)
                submenu = collections.defaultdict(dict)
    
            if lineType == 'Call' and vpapplog['VarValue'] != '-': #only need one line because determineLineType is so specific in this case

                call[vpapplog['VarName']] = vpapplog['VarValue']

                if vpapplog['VarName'] == 'CallerType':
                    submenu['CallerType'] = vpapplog['VarValue']

            elif lineType == 'Menu':
    
                if vpapplog['ActivityName'] == menu['Name']:
                    menu['End'] = vpapplog['LogTimestamp']
                else: # new menu
                    if len(str(menu['SessionID'])) > 2:
                        menu_list.append(menu)
                    menu = collections.defaultdict(dict)
                    menu['SessionID'] = call['SessionID']
                    menu['Menu_ID'] = vpapplog['SessionIndex']
                    menu['Name'] = vpapplog['ActivityName']
                    menu['Start'] = vpapplog['LogTimestamp']
                    menu['End'] = vpapplog['LogTimestamp']
                    if vpapplog['ActivityName'] == 'ProviderMainMenu':
                        call['CallerType'] = 'Provider'
    
            elif lineType == 'Submenu':
    
                if vpapplog['ActivityName'] != submenu['Name']: # new submenu
    
                    if len(str(submenu['SessionID'])) > 2:
                        submenu_list.append(submenu)
                    submenu = collections.defaultdict(dict)
                    submenu['SessionID']  = call['SessionID']
                    submenu['Menu_ID']    = menu['Menu_ID']
                    submenu['Submenu_ID'] = vpapplog['SessionIndex']
                    submenu['Name']       = vpapplog['ActivityName']
                    submenu['Start']      = vpapplog['LogTimestamp']
                    submenu['Successful'] = 'False'
                    submenu['DNIS']       = call['DNIS']
                    submenu['Language']   = call['Language']
                    submenu['CallerType'] = call['CallerType']
                    submenu['ToD']        = 'NONE'
                    submenu['Transfer_Group'] = ''
                    submenu['Transfer_Point'] = ''
    
                # mutually exclusive variable collection scenarios
                if vpapplog['VarName'] != '-' and vpapplog['VarValue'] != '-':
    
                    if vpapplog['VarName'] == 'ToDStatus':
                        submenu['ToD'] = vpapplog['VarValue']
                    elif vpapplog['VarName'] == 'TransferGroup':
                        submenu['Transfer_Group'] = vpapplog['VarValue']
                    elif vpapplog['VarName'] == 'TransferNumber':
                        submenu['Transfer_Point'] = vpapplog['VarValue']
                    elif vpapplog['VarName'] == 'Email' and vpapplog['VarValue'] != 'EMAIL': # prevent this generic value from overwriting an actual email address
                        submenu['Transfer_Point'] = vpapplog['VarValue']
                    elif vpapplog['VarName'] == 'pcEnterExtension:value':
                        submenu['Successful'] = 'True'
                        drilldown_list.append({'SessionID': call['SessionID'], 'Menu_ID': menu['Menu_ID'], 'Submenu_ID': submenu['Submenu_ID'], 'Drilldown_ID': vpapplog['SessionIndex'], 'Selection_Time': vpapplog['LogTimestamp'], 'Variable': vpapplog['VarName'], 'Value': vpapplog['VarValue']})
                    elif vpapplog['VarName'] in ('MemberValidated', 'ProvAuthenticated', 'ProviderValidated'):
                        submenu['Successful'] = vpapplog['VarValue']
                    elif vpapplog['ActivityName'] == 'Eligibility' and vpapplog['VarName'] == 'EligibilityFlag' and vpapplog['VarValue'] in ('Y', 'N'):
                        submenu['Successful'] = 'True'
                        drilldown_list.append({'SessionID': call['SessionID'], 'Menu_ID': menu['Menu_ID'], 'Submenu_ID': submenu['Submenu_ID'], 'Drilldown_ID': vpapplog['SessionIndex'], 'Selection_Time': vpapplog['LogTimestamp'], 'Variable': vpapplog['VarName'], 'Value': vpapplog['VarValue']})
                    elif vpapplog['ActivityName'] == 'IdCardRequest' and vpapplog['VarName'] == 'Status' and vpapplog['VarValue'] == 'Y':
                        submenu['Successful'] = 'True'
                    elif vpapplog['ActivityName'] in ('Transfer', 'Fax') and vpapplog['VarName'] == 'Status' and vpapplog['VarValue'] == 'Success':
                        submenu['Successful'] = 'True'
                    elif vpapplog['ActivityName'] == 'GetPCP' and vpapplog['VarName'] == 'EligPCPName':
                        submenu['Successful'] = 'True'
                        drilldown_list.append({'SessionID': call['SessionID'], 'Menu_ID': menu['Menu_ID'], 'Submenu_ID': submenu['Submenu_ID'], 'Drilldown_ID': vpapplog['SessionIndex'], 'Selection_Time': vpapplog['LogTimestamp'], 'Variable': vpapplog['VarName'], 'Value': vpapplog['VarValue']})
                    else:
                        drilldown_list.append({'SessionID': call['SessionID'], 'Menu_ID': menu['Menu_ID'], 'Submenu_ID': submenu['Submenu_ID'], 'Drilldown_ID': vpapplog['SessionIndex'], 'Selection_Time': vpapplog['LogTimestamp'], 'Variable': vpapplog['VarName'], 'Value': vpapplog['VarValue']})
    
                submenu['End'] = vpapplog['LogTimestamp']
    
            call['End'] = vpapplog['LogTimestamp']

        # append remaining dictionaries
        if len(str(call['SessionID'])) > 2:
            call_list.append(call)
        if len(str(menu['SessionID'])) > 2:
            menu_list.append(menu)
        if len(str(submenu['SessionID'])) > 2:
            submenu_list.append(submenu)   
        
        dtfs['call']  = pd.DataFrame(call_list)
        dtfs['menu']  = pd.DataFrame(menu_list)
        dtfs['submenu']  = pd.DataFrame(submenu_list)
        dtfs['drilldown']  = pd.DataFrame(drilldown_list)
    
        return dtfs

    def _processCall(self,call_dtf): # add caller type, language, and dnis to the call dataframe and then load it into EDW

        clrtyp_sql = "SELECT MIN(CALLER_TYPE_DIM_CK) AS CALLER_TYPE_DIM_CK, CALLER_TYPE_DESC FROM ivr_app_own.DIM_CALLER_TYPE GROUP BY 2"
        lang_sql   = "SELECT LANGUAGE_DIM_CK, LANGUAGE_DESC FROM ivr_app_own.DIM_LANGUAGE"
        dnis_sql   = "SELECT DNIS, MIN(DNIS_DIM_CK) AS DNIS_DIM_CK FROM ivr_app_own.DIM_DNIS WHERE DNIS_TYPE = ? GROUP BY DNIS UNION \
                      SELECT DNIS_PLAN_NAME AS DNIS, MIN(DNIS_DIM_CK) AS DNIS_DIM_CK FROM ivr_app_own.DIM_DNIS WHERE DNIS_TYPE = ? GROUP BY DNIS_PLAN_NAME"

        conn = connections.edw(edwcon=self.edwcon)

        clrtyp_dtf = pd.read_sql_query(clrtyp_sql, conn)
        clrtyp_dtf.rename(columns=lambda x: x.lower(), inplace=True) # make column names lowercase
        lang_dtf = pd.read_sql_query(lang_sql, conn)
        lang_dtf.rename(columns=lambda x: x.lower(), inplace=True) # make column names lowercase
        dnis_dtf = pd.read_sql_query(dnis_sql, conn, params=(self.dnis_type, self.dnis_type))
        dnis_dtf.rename(columns=lambda x: x.lower(), inplace=True) # make column names lowercase

        for i in call_dtf.index:
            if isinstance(call_dtf['CallerType'][i], str):
                call_dtf['CallerType'][i] = call_dtf['CallerType'][i].title()
            else: 
                call_dtf['CallerType'][i] = ''

        call_dtf = pd.merge(call_dtf, clrtyp_dtf, how='left', left_on='CallerType', right_on='caller_type_desc')
        clrtyp_dtf = None
        del call_dtf['caller_type_desc'] # remove redundant column

        call_dtf = pd.merge(call_dtf, lang_dtf, how='left', left_on='Language', right_on='language_desc')
        lang_dtf = None
        del call_dtf['language_desc'] # remove redundant column

        dnis_dtf['dnis'] = dnis_dtf['dnis'].map(lambda x: re.sub('\s', '', x)) # strip whitespace
        call_dtf = pd.merge(call_dtf, dnis_dtf, how='left', left_on='DNIS', right_on='dnis')
        dnis_dtf = None
        del call_dtf['dnis'] # remove redundant column

        call_dtf['start_date_dim_ck'] = call_dtf['Start'].map(lambda x: re.sub('-', '', x)).map(lambda x: int(x[0:8]))
        call_dtf['end_date_dim_ck'] = call_dtf['End'].map(lambda x: re.sub('-', '', x)).map(lambda x: int(x[0:8]))

        insert_sql = "INSERT INTO ivr_app_own.FT_IVR_CALL (IVR_SESSION_ID, DNIS_DIM_CK, CALLER_TYPE_DIM_CK, START_DATE_DIM_CK, "
        insert_sql += "START_TIME, END_DATE_DIM_CK, END_TIME, LANGUAGE_DIM_CK) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        call_dtf=call_dtf.rename(columns={'Start':'START_TIME','End':'END_TIME','SessionID':'IVR_SESSION_ID','dnis_dim_ck':'DNIS_DIM_CK','caller_type_dim_ck':'CALLER_TYPE_DIM_CK','language_dim_ck':'LANGUAGE_DIM_CK','start_date_dim_ck':'START_DATE_DIM_CK','end_date_dim_ck':'END_DATE_DIM_CK'})
        df=call_dtf[['IVR_SESSION_ID','DNIS_DIM_CK','CALLER_TYPE_DIM_CK','START_DATE_DIM_CK','START_TIME','END_DATE_DIM_CK','END_TIME','LANGUAGE_DIM_CK']]
        connections.pd2td(df,'ivr_app_own_tables','ft_ivr_call','ivr_app_own', edwcon=self.edwcon, itenerator=self.application_name)
    
    def _processMenu(self,menu_dtf):

        sql = "SELECT application_menu_name, ivr_menu_dim_ck FROM ivr_app_own.dim_ivr_menu"

        conn = connections.edw(edwcon=self.edwcon)

        dim_menu_dtf = pd.read_sql_query(sql, conn)
        conn.close()
        dim_menu_dtf.rename(columns=lambda x: x.lower(), inplace=True) # make column names lowercase

        menu_dtf = pd.merge(menu_dtf, dim_menu_dtf, how='left', left_on='Name', right_on='application_menu_name')
        dim_menu_dtf = None
        del menu_dtf['Name']
        del menu_dtf['application_menu_name']
        menu_dtf = menu_dtf.rename(columns={'SessionID':'IVR_SESSION_ID','Menu_ID':'IVR_MENU_ID','ivr_menu_dim_ck':'IVR_MENU_DIM_CK','Start':'START_TIME','End':'END_TIME'})
        connections.pd2td(menu_dtf, 'ivr_app_own_tables', 'FT_IVR_MENU', 'ivr_app_own', edwcon=self.edwcon, itenerator=self.application_name)

    def _processSubmenu(self,submenu_dtf):

        dim_ivr_submenu_sql = "SELECT application_menu_name, ivr_menu_dim_ck as ivr_submenu_dim_ck FROM ivr_app_own.dim_ivr_sub_menu"
        
        dim_transfer_group_sql = "SELECT MIN(T.transfer_grp_dim_ck) AS transfer_grp_dim_ck, C.CALLER_TYPE_DESC, L.LANGUAGE_DESC, "
        dim_transfer_group_sql += "D.DNIS, T.ToD, T.Transfer_Group, T.Transfer_Point FROM ivr_app_own.dim_transfer_grp T "
        dim_transfer_group_sql += "LEFT JOIN ivr_app_own.DIM_CALLER_TYPE C ON T.caller_type_dim_ck = C.CALLER_TYPE_DIM_CK "
        dim_transfer_group_sql += "LEFT JOIN ivr_app_own.DIM_LANGUAGE L ON T.language_dim_ck = L.LANGUAGE_DIM_CK "
        dim_transfer_group_sql += "LEFT JOIN ivr_app_own.DIM_DNIS D ON T.dnis_dim_ck = D.DNIS_DIM_CK "
        dim_transfer_group_sql += "GROUP BY C.CALLER_TYPE_DESC, L.LANGUAGE_DESC, D.DNIS, T.ToD, T.Transfer_Group, T.Transfer_Point"

        conn = connections.edw(edwcon=self.edwcon)

        dim_ivr_submenu_dtf = pd.read_sql_query(dim_ivr_submenu_sql, conn)
        dim_ivr_submenu_dtf.rename(columns=lambda x: x.lower(), inplace=True) # make column names lowercase
        dim_transfer_group_dtf = pd.read_sql_query(dim_transfer_group_sql, conn)
        dim_transfer_group_dtf.rename(columns=lambda x: x.lower(), inplace=True) # make column names lowercase
        conn.close()

        dim_transfer_group_dtf['dnis'] = dim_transfer_group_dtf['dnis'].map(lambda x: re.sub('\s', '', x)) # strip whitespace

        submenu_dtf['CallerType'] = submenu_dtf['CallerType'].map(lambda x: x.title())
        submenu_dtf = pd.merge(submenu_dtf, dim_ivr_submenu_dtf, how='left', left_on='Name', right_on='application_menu_name')
        del submenu_dtf['application_menu_name'] # remove redundant column
        submenu_dtf = pd.merge(submenu_dtf, dim_transfer_group_dtf, how='left', left_on=('CallerType', 'DNIS', 'Language', 'ToD', 'Transfer_Group', 'Transfer_Point'), right_on=('caller_type_desc', 'dnis', 'language_desc', 'tod', 'transfer_group', 'transfer_point'))
        del submenu_dtf['caller_type_desc'] # remove redundant column
        del submenu_dtf['dnis'] # remove redundant column
        del submenu_dtf['language_desc'] # remove redundant column
        del submenu_dtf['tod'] # remove redundant column
        del submenu_dtf['transfer_group'] # remove redundant column
        del submenu_dtf['transfer_point'] # remove redundant column

        submenu_dtf = submenu_dtf[['SessionID', 'Menu_ID', 'Submenu_ID', 'ivr_submenu_dim_ck', 'Start', 'End', 'transfer_grp_dim_ck', 'Successful']]
        submenu_dtf = submenu_dtf.rename(columns={'SessionID':'IVR_SESSION_ID', 'Menu_ID':'IVR_MENU_ID', 'Submenu_ID':'IVR_SUBMENU_ID', 'ivr_submenu_dim_ck':'IVR_SUBMENU_DIM_CK', 'Start':'START_TIME', 'End':'END_TIME', 'transfer_grp_dim_ck':'TRANSFER_GRP_DIM_CK', 'Successful':'SUCCESSFUL'})
        submenu_dtf['SUCCESSFUL'] = submenu_dtf['SUCCESSFUL'].map(lambda x: 'Y' if x == 'True' or x == 'Y' else 'N')
        connections.pd2td(submenu_dtf, 'ivr_app_own_tables', 'FT_IVR_SUBMENU', 'ivr_app_own', edwcon=self.edwcon, itenerator=self.application_name)

    def _processDrilldown(self,drilldown_dtf): # arrange and rename columns, then load into EDW

        drilldown_dtf = drilldown_dtf[['SessionID','Menu_ID','Submenu_ID','Drilldown_ID','Selection_Time','Variable','Value']]
        drilldown_dtf = drilldown_dtf.rename(columns={'SessionID':'IVR_SESSION_ID','Menu_ID':'IVR_MENU_ID','Submenu_ID':'IVR_SUBMENU_ID','Drilldown_ID':'IVR_DRILLDOWN_ID','Selection_Time':'SELECTION_TIME','Variable':'VARIABLE','Value':'VARVALUE'})
        connections.pd2td(drilldown_dtf, 'ivr_app_own_tables', 'IVR_SUBMENU_DRILLDOWN', 'ivr_app_own', edwcon=self.edwcon, itenerator=self.application_name)

    def _update_call_summary(self, fromDate, toDate):
        sum_sql = "\
        MERGE INTO IVR_APP_OWN.FT_CALL_SUMMARY AS TARGET_TABLE \
        USING ( \
        SELECT DNIS_DIM_CK, \
               CALLER_TYPE_DIM_CK, \
        	   START_DATE_DIM_CK, \
        	   LANGUAGE_DIM_CK, \
        	   CALL_VOL_DIM_CK, \
        	   COUNT(*) AS CALL_CNT, \
        	   AVG(CALLTIME) AS AVG_CALL_LNGTH \
        FROM \
        (SELECT FCLL.DNIS_DIM_CK, \
                FCLL.CALLER_TYPE_DIM_CK, \
                FCLL.START_DATE_DIM_CK, \
                FCLL.LANGUAGE_DIM_CK, \
                CASE WHEN /*TRANSFERS*/MAX(CASE WHEN FSUB.TRANSFER_GRP_DIM_CK IS NULL THEN 0 ELSE 1 END)=1 \
                      AND /*SS_SUCCESS*/MAX(CASE WHEN FSUB.SUCCESSFUL= 'Y' AND DSUB.MENU_NAME<>'Transfer' THEN 1 WHEN FSUB.SUCCESSFUL= 'N' THEN 0 ELSE NULL END)=1 \
                     THEN 'XFER_TRAN' \
                     WHEN  /*TRANSFERS*/MAX(CASE WHEN FSUB.TRANSFER_GRP_DIM_CK IS NULL THEN 0 ELSE 1 END)=1 \
                       OR /*DIRECT_TRANSFER*/MAX(CASE DSUB.MENU_NAME WHEN 'Transfer to Extension' THEN 1 ELSE 0 END)=1 \
                      AND /*SS_SUCCESS*/MAX(CASE WHEN FSUB.SUCCESSFUL= 'Y' AND DSUB.MENU_NAME<>'Transfer' THEN 1 WHEN FSUB.SUCCESSFUL= 'N' THEN 0 ELSE NULL END)=0 \
                     THEN 'XFER' \
                     WHEN  /*TRANSFERS*/MAX(CASE WHEN FSUB.TRANSFER_GRP_DIM_CK IS NULL THEN 0 ELSE 1 END)=0 \
                      AND /*SS_SUCCESS*/MAX(CASE WHEN FSUB.SUCCESSFUL= 'Y' AND DSUB.MENU_NAME<>'Transfer' THEN 1 WHEN FSUB.SUCCESSFUL= 'N' THEN 0 ELSE NULL END)=1 \
                     THEN 'SS_TRAN' \
                     WHEN /*EXTERNAL_TRANSFER*/MAX(CASE WHEN INDEX(DTGP.TRANSFER_POINT,'@')=0 AND LENGTH(DTGP.TRANSFER_POINT)>10 THEN 1 ELSE 0 END)=1 \
                     THEN 'SS_3PRTY' \
                     ELSE 'OTHER' \
                END AS CALL_VOL_TYPE_CD, \
                FCLL.IVR_SESSION_ID, \
                (FCLL.END_TIME-FCLL.START_TIME)SECOND(4,6) AS CALLTIME \
         FROM   IVR_APP_OWN.FT_IVR_CALL FCLL \
                LEFT JOIN IVR_APP_OWN.FT_IVR_MENU      FMNU ON FCLL.IVR_SESSION_ID=FMNU.IVR_SESSION_ID \
                LEFT JOIN IVR_APP_OWN.FT_IVR_SUBMENU   FSUB ON FCLL.IVR_SESSION_ID=FSUB.IVR_SESSION_ID AND FMNU.IVR_MENU_ID=FSUB.IVR_MENU_ID \
                LEFT JOIN IVR_APP_OWN.DIM_IVR_MENU     DMNU ON FMNU.IVR_MENU_DIM_CK=DMNU.IVR_MENU_DIM_CK \
                LEFT JOIN IVR_APP_OWN.DIM_IVR_SUB_MENU DSUB ON FSUB.IVR_SUBMENU_DIM_CK=DSUB.IVR_MENU_DIM_CK \
                LEFT JOIN IVR_APP_OWN.DIM_TRANSFER_GRP DTGP ON FSUB.TRANSFER_GRP_DIM_CK=DTGP.TRANSFER_GRP_DIM_CK \
         WHERE  FCLL.START_DATE_DIM_CK BETWEEN ? AND ? \
         GROUP BY 1, 2, 3, 4, 6, 7) SUBQ INNER JOIN IVR_APP_OWN.DIM_CALL_VOLUME_TYPE DCVT ON SUBQ.CALL_VOL_TYPE_CD = DCVT.CALL_VOL_TYPE_CD \
        GROUP BY 1, 2, 3, 4, 5 \
        ) AS SOURCE_TABLE \
        ON  TARGET_TABLE.DNIS_DIM_CK = SOURCE_TABLE.DNIS_DIM_CK \
        AND TARGET_TABLE.CALL_VOL_DIM_CK = SOURCE_TABLE.CALL_VOL_DIM_CK \
        AND TARGET_TABLE.LANGAGE_DIM_CK = SOURCE_TABLE.LANGUAGE_DIM_CK \
        AND TARGET_TABLE.CALLER_TYPE_DIM_CK = SOURCE_TABLE.CALLER_TYPE_DIM_CK \
        AND TARGET_TABLE.CALL_DT_CK = SOURCE_TABLE.START_DATE_DIM_CK \
        WHEN MATCHED THEN UPDATE SET CALL_CNT = SOURCE_TABLE.CALL_CNT, AVG_CALL_LNGTH = SOURCE_TABLE.AVG_CALL_LNGTH, DW_UPDATE_USER = 'IVR_USER', DW_UPDATE_DATE = CURRENT_DATE \
        WHEN NOT MATCHED THEN INSERT \
        VALUES (SOURCE_TABLE.DNIS_DIM_CK, SOURCE_TABLE.CALL_VOL_DIM_CK, SOURCE_TABLE.LANGUAGE_DIM_CK, SOURCE_TABLE.CALLER_TYPE_DIM_CK, SOURCE_TABLE.START_DATE_DIM_CK, SOURCE_TABLE.CALL_CNT, SOURCE_TABLE.AVG_CALL_LNGTH, 'IVR_USER', CURRENT_DATE); "
        # Medicare_Provider has made it such that we cannot use APPLICATION_ID as the DNIS_PLAN_NAME
        con=connections.edw(edwcon=self.edwcon)
        cur=con.cursor()
        cur.execute(sum_sql,(fromDate.strftime('%Y%m%d'),toDate.strftime('%Y%m%d')))
        con.commit()
        cur.close()
        con.close()

#-----------------------------------------------------------------------
# this section enables the module to be used as a command line script, but
# if the module is imported by other Python code, this section will be ignored
#-----------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    # sys.argv[0] is the script name; the rest of the list
    # are the command line arguments passed to the script
    if len(sys.argv) != 8:
        print(sys.argv[0] + ": Invalid argument count")
        sys.exit()
    try:
        reporter = IVR_REPORTING(application_name=sys.argv[1], plan_dim_ck=sys.argv[2], dnis_type=sys.argv[3], edwcon=sys.argv[4], oraclecon=sys.argv[5])
        reporter.run(datetime.strptime(sys.argv[6], '%Y-%m-%d'), datetime.strptime(sys.argv[7], '%Y-%m-%d'))
    except Exception as excp:
        self.error_email(excp)
        raise

