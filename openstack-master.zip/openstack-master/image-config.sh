#!/usr/bin/env bash
set -eu

source ./set-environment.sh

openstack image list --format json
