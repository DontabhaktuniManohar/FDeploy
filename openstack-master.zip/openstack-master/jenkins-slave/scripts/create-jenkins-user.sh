#!/usr/bin/env bash
set -e

. /tmp/config/credentials &> /dev/null

sudo adduser -m -d /var/jenkins --shell /bin/bash --comment "jenkins slave user account" jenkins
echo "${JENKINS_SLAVE_USER}:${JENKINS_SLAVE_PASSWORD}" | sudo chpasswd
