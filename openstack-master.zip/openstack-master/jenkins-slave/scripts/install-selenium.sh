#!/usr/bin/env bash
set -e

sudo pip install selenium
