#!/usr/bin/env bash
set -e

sudo wget https://dl.yarnpkg.com/rpm/yarn.repo -O /etc/yum.repos.d/yarn.repo

curl --silent --location https://rpm.nodesource.com/setup_6.x | sudo bash -

sudo wget -qO- https://raw.githubusercontent.com/creationix/nvm/v0.33.2/install.sh | bash

sudo yum install -y yarn

sudo yum install -y bzip2
