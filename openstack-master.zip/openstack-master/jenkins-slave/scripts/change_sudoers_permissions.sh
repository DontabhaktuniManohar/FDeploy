#!/usr/bin/env bash
set -xv

pwd
cd /etc/
pwd
ls -la sudo*

sudo chmod 0200 sudoers
#cat /tmp/temp_sudoers >> sudoers
sudo echo "# Members of the admin group may gain root privileges" >> sudoers
sudo echo "%admin  ALL=(ALL) NOPASSWD:ALL" >> sudoers
sudo echo "root    ALL=(ALL) ALL" >> sudoers
sudo echo "jenkins ALL=(ALL) NOPASSWD:ALL" >> sudoers
sudo chmod 0440 sudoers

