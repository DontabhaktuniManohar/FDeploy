#!/usr/bin/env bash
set -e

wget --no-cookies \
--no-check-certificate \
--header "Cookie: oraclelicense=accept-securebackup-cookie" \
"http://download.oracle.com/otn-pub/java/jdk/8u131-b11/d54c1d3a095b4ff2b6607d096fa80163/jdk-8u131-linux-x64.rpm" \
-O jdk-8u131-linux-x64.rpm

sudo rpm -ivh jdk-8u131-linux-x64.rpm

sudo cp /etc/profile /etc/profile_backup
echo 'export JAVA_HOME=/usr/java/jdk1.8.0' | sudo tee -a /etc/profile
source /etc/profile

sudo wget -O /usr/local/packer_zip 'https://releases.hashicorp.com/packer/0.12.3/packer_0.12.3_linux_amd64.zip?_ga=1.117470401.993636481.1489757856'
sudo unzip /usr/local/packer_zip -d /usr/local
sudo rm /usr/local/packer_zip

sudo yum -y install groovy

sudo yum -q -y install \
python-devel python-pip \
gcc-objc.x86_64

sudo yum -y install cifs-utils

sudo pip install pip --upgrade --ignore-installed PyYAML --ignore-installed requests
sudo pip install python-openstackclient
sudo pip install python-heatclient
