#!/usr/bin/env bash

sudo yum -q -y update
sudo yum -q -y install git
sudo yum -q -y install wget
sudo yum -q -y install unzip
