#!/usr/bin/env bash
set -e

#sudo sed -i /etc/selinux/config -r -e 's/^SELINUX=.*/SELINUX=disabled/g'   # Disabled SELinux
sudo sed -i 's/^\(PasswordAuthentication\s*\)no/\1yes/' /etc/ssh/sshd_config
sudo cat /etc/ssh/sshd_config
sudo sed -i 's/^\(ssh_pwauth:\s*\)0/\11/' /etc/cloud/cloud.cfg
sudo cat /etc/cloud/cloud.cfg
