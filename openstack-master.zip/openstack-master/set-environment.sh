#!/usr/bin/env bash

set -ea

OS_AUTH_URL=${OS_AUTH_URL}

OS_TENANT_NAME=${OS_TENANT_NAME}
OS_PROJECT_NAME=${OS_TENANT_NAME}

OS_USERNAME=${OS_USERNAME}
OS_PASSWORD=${OS_PASSWORD}

string1=${OS_AUTH_URL}
string2="v3"
if [[ $string1 == *$string2* ]]; then {
     OS_NO_CACHE=1
     OS_DOMAIN_NAME='jdnet'
     OS_USER_DOMAIN_NAME='jdnet'
     OS_PROJECT_DOMAIN_NAME='jdnet'
     OS_REGION_NAME='RegionOne'
     OS_IDENTITY_API_VERSION=3
     OS_AUTH_VERSION=3
   }
fi
