pipelineJob('JenkinsInfra') {
    description("Create Jenkins Infrastructure")
    definition {
        parameters {
            nonStoredPasswordParam('ENCRYPTION_KEY', 'encryption key to be used to encrypt credentials')
            stringParam('OS_TENANT_NAME', '', 'Openstack tenant name')
            stringParam('SHORT_NAME', '', 'Prefix for resources that will be used to identify OpenStack resources.  If used it is recommended ending with a - to delimit the names')
            stringParam('OS_USERNAME', '', 'application id with access to openstack')
            nonStoredPasswordParam('OS_PASSWORD', '')
            stringParam('JENKINS_SLAVE_USER', '', 'User Id to be created on the Slave to be used for the Master to sign on.')
            nonStoredPasswordParam('JENKINS_SLAVE_PASSWORD', '')
            stringParam('OS_AUTH_URL', 'https://openstack.deere.com:5000/v2.0', '')
            stringParam('RECORD_DOMAIN', '', 'Must end in a period and exist in the tenant')
            stringParam('JENKINS_DOMIAN', '', 'Must end in a period')
            stringParam('STACK_OPERATION', 'create', '')
            stringParam('BASE_IMAGE', '', 'Use Timestamp extension or -* to choose the latest version.')
            stringParam('ADMIN_AD_GROUP', '', 'AD Group that will be set as an Administrator in the Jenkins Master')
            stringParam('DEVELOPER_AD_GROUP', '', 'AD Group that will be set as a non-Administrator in the Jenkins Master')
            stringParam('KEY_PAIR', 'jenkins-key', 'Must exist in the Tenant')
        }
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://github.deere.com/it-modernization/openstack-jenkins-pipeline.git')
                        credentials('a900480_GitHub_Token')
                    }
                }
            }
            scriptPath('Jenkinsfile')
        }
    }
}
