#!/usr/bin/env bash
set -eu

source ./set-environment.sh

#openstack router list --format json
network_id=$(openstack router list --format value -c ID)
openstack router show --format value $network_id -c external_gateway_info
