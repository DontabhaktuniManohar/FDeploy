#!/usr/bin/env bash
set -eu

source ./set-environment.sh

openstack network list --format json