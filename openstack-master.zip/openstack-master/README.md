# OpenStack Jenkins Infrastructure Automation
Template for creating Jenkins infrastructure in OpenStack.

# About
OpenStack is a free and open-source software platform for cloud computing, deployed as an infrastructure-as-a-service (IaaS) at Deere data center.
More information on OpenStack can be found at http://devwiki.deere.com/wiki/Openstack.
This repository contains template for creating jenkins or CI infrastructure based on CentOS Linux image in OpenStack.
The CI infrastructure created by this template will have all the required Jenkins plugins and its configuration maintained in code.

# Steps to automate Jenkins Infrastructure in Openstack

  Refer to the Confluence page for detailed instructions: https://confluence.deere.com:8443/display/ITM/Version+2+-+Jenkins+Pipeline
  
# Resources
  - Jenkins Init http://jenkins-init.itm-tooling.ic.deere.com
