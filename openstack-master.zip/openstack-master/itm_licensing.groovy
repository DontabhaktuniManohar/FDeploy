pipelineJob('itm-licensing') {
    description("Create Jenkins Infrastructure for License Monitoring Jobs")
    definition {
        parameters {
            nonStoredPasswordParam('ENCRYPTION_KEY', 'encryption key to be used to encrypt credentials')
            stringParam('OS_TENANT_NAME', 'itm-enterprise-tooling', 'Openstack tenant name')
            stringParam('SHORT_NAME', 'itm-licensing-', 'Prefix for resources that will be used to identify OpenStack resources.  If used it is recommended ending with a - to delimit the names')
            stringParam('OS_USERNAME', 'A900152', 'application id with access to openstack')
            nonStoredPasswordParam('OS_PASSWORD', '')
            stringParam('JENKINS_SLAVE_USER', 'jenkins', 'User Id to be created on the Slave to be used for the Master to sign on.')
            stringParam('JENKINS_SLAVE_PASSWORD', 'jenkins123')
            stringParam('OS_AUTH_URL', 'https://openstack.deere.com:5000/v2.0', '')
            stringParam('RECORD_DOMAIN', 'itm-tooling.ic.deere.com.', 'Must end in a period and exist in the tenant')
            stringParam('JENKINS_DOMIAN', 'licensing.', 'Must end in a period')
            stringParam('STACK_OPERATION', 'create', '')
            stringParam('BASE_IMAGE', 'centos-7-current-*', 'Use Timestamp extension or -* to choose the latest version.')
            stringParam('ADMIN_AD_GROUP', 'G90_SVN_DEVELOPER_ENABLEMENT_RW', 'AD Group that will be set as an Administrator in the Jenkins Master')
            stringParam('DEVELOPER_AD_GROUP', 'G90_SVN_DEVELOPER_ENABLEMENT_R', 'AD Group that will be set as a non-Administrator in the Jenkins Master')
            stringParam('KEY_PAIR', 'jenkins-key', 'Must exist in the Tenant')
        }
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://github.deere.com/it-modernization/openstack-jenkins-pipeline.git')
                        credentials('git-access-token')
                    }
                }
            }
            scriptPath('Jenkinsfile')
        }
    }
}
