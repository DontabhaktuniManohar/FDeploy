#!/usr/bin/env bash
set -eu

cat > credentials << EOF
#!/usr/bin/env bash

set -eu

JENKINS_SLAVE_USER=${JENKINS_SLAVE_USER}
JENKINS_SLAVE_PASSWORD=${JENKINS_SLAVE_PASSWORD}

OPENSTACK_IDENTITY=${OS_TENANT_NAME}:${OS_USERNAME}
OPENSTACK_CREDENTIAL=${OS_PASSWORD}

ENCRYPTION_KEY=${ENCRYPTION_KEY}

EOF

gpg -c -q --yes --batch --passphrase ${ENCRYPTION_KEY} --cipher-algo AES256 -o ../config/credentials.gpg --symmetric credentials

