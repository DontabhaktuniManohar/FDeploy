job('keep-love-alive') {
    label('openstack')
    description('This job will keep the openstack slave alive.  Putting -1 in the slave expiration will do the same thing but this also acts like a ping job for this instance keeping track of any downtime.') 
    triggers {
        cron('@hourly')
    }
    steps {
        shell('echo "Jenkins slave connected successfully!!"')
    }
}
