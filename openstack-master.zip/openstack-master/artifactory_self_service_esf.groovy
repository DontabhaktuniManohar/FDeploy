pipelineJob('artifactory-self-service-esf') {
    description("Create Jenkins Infrastructure")
    definition {
        parameters {
            nonStoredPasswordParam('ENCRYPTION_KEY', 'encryption key to be used to encrypt credentials')
            stringParam('OS_TENANT_NAME', 'artifactory-self-service', 'Openstack tenant name')
            stringParam('SHORT_NAME', 'artifactory-ss-', 'Prefix for resources that will be used to identify OpenStack resources.  If used it is recommended ending with a - to delimit the names')
            stringParam('OS_USERNAME', 'A900152', 'application id with access to openstack')
            nonStoredPasswordParam('OS_PASSWORD', '')
            stringParam('JENKINS_SLAVE_USER', 'jenkins', 'User Id to be created on the Slave to be used for the Master to sign on.')
            stringParam('JENKINS_SLAVE_PASSWORD', 'jenkins123')
            stringParam('OS_AUTH_URL', 'https://openstack-esf.deere.com:5000/v3', '')
            stringParam('RECORD_DOMAIN', 'art-ss.itm.ic-esf.deere.com.', 'Must end in a period')
            stringParam('JENKINS_DOMIAN', 'artifactory.ss.', 'Must end in a period and exist in the tenant')
            stringParam('STACK_OPERATION', 'create', '')
            stringParam('BASE_IMAGE', 'centos-7-current-*', 'Use Timestamp extension or -* to choose the latest version.')
            stringParam('ADMIN_AD_GROUP', 'G90_SVN_DEVELOPER_ENABLEMENT_RW', 'AD Group that will be set as an Administrator in the Jenkins Master')
            stringParam('DEVELOPER_AD_GROUP', 'G90_SVN_DEVELOPER_ENABLEMENT_RW', 'AD Group that will be set as a non-Administrator in the Jenkins Master')
            stringParam('KEY_PAIR', 'jenkins-key', 'Must exist in the Tenant')
        }
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://github.deere.com/it-modernization/openstack-jenkins-pipeline.git')
                        credentials('git-access-token')
                    }
                }
            }
            scriptPath('Jenkinsfile')
        }
    }
}
