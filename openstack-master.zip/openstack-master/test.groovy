pipelineJob('JenkinsInfra') {
    description("Create Jenkins Infrastructure")
    definition {
        parameters {
            nonStoredPasswordParam('ENCRYPTION_KEY', 'encryption key to be used to encrypt credentials')
            stringParam('OS_TENANT_NAME', '', 'Openstack tenant name')
            stringParam('SHORT_NAME', '', 'Short name that will be used to identify OpenStack resouces by prepending to instances and Images.  If used it is recommened ending with a - to delimit the names')
            stringParam('OS_USERNAME', '', 'application id with access to openstack')
            nonStoredPasswordParam('OS_PASSWORD', '')
            stringParam('JENKINS_SLAVE_USER', '', '')
            nonStoredPasswordParam('JENKINS_SLAVE_PASSWORD', '')
            stringParam('OS_AUTH_URL', 'https://openstack.deere.com:5000/v2.0', '')
            stringParam('RECORD_DOMAIN', '', '')
            stringParam('JENKINS_DOMIAN', '', '')
            stringParam('STACK_OPERATION', 'create', '')
            stringParam('BASE_IMAGE', '', '')
            stringParam('ADMIN_AD_GROUP', '', '')
            stringParam('DEVELOPER_AD_GROUP', '', '')
            stringParam('KEY_PAIR', 'jenkins-key', '')
        }
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://github.deere.com/it-modernization/openstack-jenkins-pipeline.git')
                        credentials('a900480_GitHub_Token')
                    }
                }
            }
            scriptPath('Jenkinsfile')
        }
    }
}