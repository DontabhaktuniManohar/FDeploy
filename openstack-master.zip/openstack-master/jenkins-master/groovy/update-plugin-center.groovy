import jenkins.model.*

jenkins = Jenkins.getInstance()
updateCenter = jenkins.getUpdateCenter()
updateCenter.updateAllSites()
