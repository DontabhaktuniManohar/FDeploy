import jenkins.model.*
import hudson.security.*
import hudson.plugins.active_directory.*
   
def jenkins = Jenkins.getInstance()
String domain = 'JDNET.deere.com'
String site = ''
String server = ''
String bindName = ''
String bindPassword = ''
adrealm = new ActiveDirectorySecurityRealm(domain, site, bindName, bindPassword, server, GroupLookupStrategy.RECURSIVE)
jenkins.setSecurityRealm(adrealm)
jenkins.save()