import jenkins.*
import jenkins.model.*
import hudson.*
import hudson.model.*
import hudons.scm.*
import hudson.security.*
import com.cloudbees.plugins.credentials.*

def props = new Properties()
new File("/tmp/config/application.properties").withInputStream {
    stream -> props.load(stream)
}

def configuration = new ConfigSlurper().parse(props)

jenkins = Jenkins.getInstance()
strategy = new ProjectMatrixAuthorizationStrategy()

contIntAdminGroup = configuration.authorization.config.admin.group
developersGroup = configuration.authorization.config.developer.group
authenticatedUser = "authenticated"
anonymousUser = "anonymous"

strategy.add(CredentialsProvider.CREATE, contIntAdminGroup)
strategy.add(CredentialsProvider.DELETE, contIntAdminGroup)
strategy.add(CredentialsProvider.MANAGE_DOMAINS, contIntAdminGroup)
strategy.add(CredentialsProvider.UPDATE, contIntAdminGroup)
strategy.add(CredentialsProvider.VIEW, contIntAdminGroup)
strategy.add(Computer.BUILD, contIntAdminGroup)
strategy.add(Computer.CONFIGURE, contIntAdminGroup)
strategy.add(Computer.CONNECT, contIntAdminGroup)
strategy.add(Computer.CREATE, contIntAdminGroup)
strategy.add(Computer.DELETE, contIntAdminGroup)
strategy.add(Computer.DISCONNECT, contIntAdminGroup)
strategy.add(Jenkins.ADMINISTER, contIntAdminGroup)
strategy.add(PluginManager.CONFIGURE_UPDATECENTER, contIntAdminGroup)
strategy.add(Jenkins.READ, contIntAdminGroup)
strategy.add(Jenkins.RUN_SCRIPTS, contIntAdminGroup)
strategy.add(PluginManager.UPLOAD_PLUGINS, contIntAdminGroup)
strategy.add(Item.BUILD, contIntAdminGroup)
strategy.add(Item.CANCEL, contIntAdminGroup)
strategy.add(Item.CONFIGURE, contIntAdminGroup)
strategy.add(Item.CREATE, contIntAdminGroup)
strategy.add(Item.DELETE, contIntAdminGroup)
strategy.add(Item.DISCOVER, contIntAdminGroup)
strategy.add(Item.READ, contIntAdminGroup)
strategy.add(Item.WORKSPACE, contIntAdminGroup)
strategy.add(Run.DELETE, contIntAdminGroup)
strategy.add(Run.UPDATE, contIntAdminGroup)
strategy.add(View.CONFIGURE, contIntAdminGroup)
strategy.add(View.CREATE, contIntAdminGroup)
strategy.add(View.DELETE, contIntAdminGroup)
strategy.add(View.READ, contIntAdminGroup)
strategy.add(hudson.scm.SCM.TAG, contIntAdminGroup)

strategy.add(Jenkins.READ, developersGroup)
strategy.add(Item.BUILD, developersGroup)
strategy.add(Item.CANCEL, developersGroup)
strategy.add(Item.DISCOVER, developersGroup)
strategy.add(Item.READ, developersGroup)
strategy.add(Item.WORKSPACE, developersGroup)
strategy.add(View.READ, developersGroup)
strategy.add(Item.CONFIGURE, developersGroup)
strategy.add(Item.CREATE, developersGroup)
strategy.add(Item.DELETE, developersGroup)

strategy.add(Jenkins.READ, anonymousUser)
strategy.add(Item.DISCOVER, authenticatedUser)
strategy.add(Item.READ, authenticatedUser)

jenkins.setAuthorizationStrategy(strategy)
jenkins.save()
