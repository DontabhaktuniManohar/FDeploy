import jenkins.model.*
import hudson.plugins.*

instance = Jenkins.getInstance()

timestampFormat = "'<b>'yyyy-MM-dd HH:mm:ss z'</b>' "

timestamper = instance.getDescriptor("hudson.plugins.timestamper.TimestamperConfig")
timestamper.setSystemTimeFormat(timestampFormat)
timestamper.setElapsedTimeFormat(timestampFormat)

timestamper.save()
