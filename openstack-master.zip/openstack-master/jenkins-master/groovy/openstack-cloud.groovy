import jenkins.model.*
import jenkins.plugins.openstack.compute.*
import java.util.*

def props = new Properties()
new File("/tmp/config/application.properties").withInputStream {
    stream -> props.load(stream)
}

def configuration = new ConfigSlurper().parse(props)

instance = Jenkins.getInstance()

imageId_slave = configuration.cloud.config.slave.imageId

hardwareId = "2"
networkId = configuration.cloud.config.networkId
userDataId = ""
instanceCap = 1
floatingIpPool = "FLOATINGIPNETWORKPLACEHOLDER"
securityGroup = "SECURITYGROUPPLACEHOLDER"
availabilityZone = ""
startTimeout = 600000
keyPairName = ""
numExecutors = 2
jvmOptions = ""
fsRoot = "/var/jenkins"
credentialsId = "jenkins-slave-credentials"
slaveType = JCloudsCloud.SlaveType.SSH
retentionTime = 90

slaveOptions = new SlaveOptions(imageId_slave, hardwareId, networkId, userDataId, instanceCap, floatingIpPool, securityGroup, availabilityZone, startTimeout, keyPairName, numExecutors, jvmOptions, fsRoot, credentialsId, slaveType, retentionTime)

templateSlaveName = "jenkins-slave"
templateSlaveLabel = "npm selenium groovy java8 openstack slave"
templateSlaveOptions = slaveOptions

jCloudSlaveTemplates = new ArrayList<JCloudsSlaveTemplate>()
jCloudSlaveTemplates.add(new JCloudsSlaveTemplate(templateSlaveName, templateSlaveLabel, templateSlaveOptions))

cloudName = "Jenkins-OpenStack"
identity = args[0]
credential = args[1]
endPointUrl = "OPENSTACKURLPLACEHOLDER"
zone = ""

jCloud = new JCloudsCloud(cloudName, endPointUrl.contains('v3') ? identity + ':jdnet' : identity, credential, endPointUrl, zone, slaveOptions, jCloudSlaveTemplates)

clouds = new ArrayList<JCloudsCloud>()
clouds.add(jCloud)
instance.clouds.addAll(clouds)

instance.save()

