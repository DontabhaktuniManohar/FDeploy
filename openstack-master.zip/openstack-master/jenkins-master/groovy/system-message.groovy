import jenkins.model.*

Jenkins.instance.setSystemMessage("""Welcome to <em>Jenkins</em>.""")

