import jenkins.model.*
import hudson.markup.*

instance = Jenkins.getInstance()

instance.setMarkupFormatter(new RawHtmlMarkupFormatter(false))
instance.save()
