import jenkins.model.*

def props = new Properties()
new File("/tmp/config/application.properties").withInputStream {
    stream -> props.load(stream)
}

def configuration = new ConfigSlurper().parse(props)

jenkinsLocationConfiguration = JenkinsLocationConfiguration.get()
jenkinsLocationConfiguration.setAdminAddress(configuration.location.config.email)
jenkinsLocationConfiguration.setUrl(configuration.location.config.url)
jenkinsLocationConfiguration.save()
