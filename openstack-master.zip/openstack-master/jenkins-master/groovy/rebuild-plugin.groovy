import com.sonyericsson.rebuild.*
import jenkins.model.*
import hudson.plugins.*


instance = Jenkins.getInstance()

rebuilder = instance.getDescriptor("com.sonyericsson.rebuild.RebuildDescriptor")
rebuilder.getRebuildConfiguration().setRememberPasswordEnabled(false)

rebuilder.save()
