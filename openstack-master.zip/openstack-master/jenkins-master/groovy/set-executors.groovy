import jenkins.model.*

jenkins = Jenkins.getInstance()
jenkins.setNumExecutors(0)
jenkins.save()
