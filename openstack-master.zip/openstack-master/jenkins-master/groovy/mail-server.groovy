import jenkins.model.*

def inst = Jenkins.getInstance()

def desc = inst.getDescriptor("hudson.tasks.Mailer")

desc.setReplyToAddress("")
desc.setSmtpHost("mailhost.dx.deere.com")
desc.setDefaultSuffix("@johndeere.com")
desc.setUseSsl(false)
desc.setSmtpPort("")
desc.setCharset("UTF-8")

desc.save()