//Based on https://github.com/jenkinsci/jenkins-scripts/tree/master/scriptler\
//https://github.com/jenkinsci/jenkins-scripts/blob/master/scriptler/configMavenAutoInstaller.groovy
import hudson.*
import jenkins.*
import hudson.tools.InstallSourceProperty;
import hudson.tools.ToolProperty;
import hudson.tools.ToolPropertyDescriptor;
import hudson.util.DescribableList;

//Get Jenkins instance details
def desc = jenkins.model.Jenkins.instance.getDescriptor("hudson.plugins.groovy.Groovy")

// Set up properties for our new Groovy installation
def isp = new InstallSourceProperty()
def autoInstaller = new hudson.plugins.groovy.GroovyInstaller("2.4.9")
isp.installers.add(autoInstaller)
def proplist = new DescribableList<ToolProperty<?>, ToolPropertyDescriptor>()
proplist.add(isp)
 
// Define and add our Groovy installation to Jenkins
def groovyinst = new hudson.plugins.groovy.GroovyInstallation("groovy-2.4.9", "", proplist)
desc.setInstallations(groovyinst)
 
// Output current Groovy installations, to verify that our's is now present
println desc.getInstallations()
