import jenkins.model.*
import hudson.util.*
import org.jenkinsci.plugins.plaincredentials.*
import org.jenkinsci.plugins.plaincredentials.impl.*
import com.cloudbees.plugins.credentials.*
import com.cloudbees.plugins.credentials.common.*
import com.cloudbees.plugins.credentials.domains.*
import com.cloudbees.plugins.credentials.impl.*
import com.cloudbees.jenkins.plugins.sshcredentials.impl.*

store = SystemCredentialsProvider.getInstance()

jenkinsSlaveUser = args[0]
jenkinsSlavePwd = args[1]

store.addCredentials(Domain.global(), new UsernamePasswordCredentialsImpl(
        CredentialsScope.SYSTEM,
        "jenkins-slave-credentials",
        "Jenkins master/slave access",
        jenkinsSlaveUser, jenkinsSlavePwd))