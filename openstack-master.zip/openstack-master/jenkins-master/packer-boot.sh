#!/usr/bin/env bash

set -ea

source ../set-environment.sh

ENCRYPTION_KEY=${ENCRYPTION_KEY}

/usr/local/packer build -var-file=../properties.json packer-template/jenkins-master.json