#!/usr/bin/env bash

if [ $STACK_OPERATION = 'create' ]; then
    sh heat-template/stack-create.sh
elif [ $STACK_OPERATION = 'delete' ]; then
    sh heat-template/stack-delete.sh
else
    printf "%s\n" "No such operation defined"
fi
