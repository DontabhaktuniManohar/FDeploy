#!/usr/bin/env bash
set -e

echo ${ENCRYPTION_KEY} | gpg -q --yes --batch --passphrase-fd 0 --output /tmp/config/credentials /tmp/config/credentials.gpg

