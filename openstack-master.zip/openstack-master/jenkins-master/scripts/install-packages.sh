#!/usr/bin/env bash
set -e

sudo yum -y update
sudo yum -q -y install git
sudo yum -q -y install wget

wget --no-cookies \
--no-check-certificate \
--header "Cookie: oraclelicense=accept-securebackup-cookie" \
"http://download.oracle.com/otn-pub/java/jdk/8u131-b11/d54c1d3a095b4ff2b6607d096fa80163/jdk-8u131-linux-x64.rpm" \
-O jdk-8u131-linux-x64.rpm

sudo rpm -ivh jdk-8u131-linux-x64.rpm

sudo cp /etc/profile /etc/profile_backup
echo 'export JAVA_HOME=/usr/java/jdk1.8.0' | sudo tee -a /etc/profile
source /etc/profile

sudo wget https://pkg.jenkins.io/redhat-stable/jenkins-2.89.4-1.1.noarch.rpm
sudo rpm -ivh jenkins-2.89.4-1.1.noarch.rpm

sudo sed -i /etc/selinux/config -r -e 's/^SELINUX=.*/SELINUX=disabled/g'   # Disabled SELinux
sudo yum install -q -y nginx
