#!/usr/bin/env bash
set -e

sudo cp /tmp/config/nginx/nginx.conf /etc/nginx/nginx.conf
sudo chmod 644 /etc/nginx/nginx.conf

sudo cp /tmp/config/nginx/jenkins.conf /etc/nginx/conf.d/jenkins.conf
sudo chmod 644 /etc/nginx/conf.d/jenkins.conf

sudo setsebool -P httpd_can_network_connect 1
sudo systemctl restart nginx

sudo systemctl enable nginx
