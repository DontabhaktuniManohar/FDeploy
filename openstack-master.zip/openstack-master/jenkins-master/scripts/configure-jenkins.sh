#!/usr/bin/env bash
set -e

. /tmp/config/credentials &> /dev/null

function jenkinsCli {
  java -jar ${JENKINS_CLI_LOCATION} -remoting -s http://localhost "$@"
}

function testJenkinsService {
  until [ $(curl -Is http://localhost/api/json | grep HTTP/1.1 | awk {'print $2'}) -eq 200 ]; do
    echo "Jenkins service not available, waiting..."
    sleep 5
  done

  echo "Jenkins service available."
}

function installJenkinsPlugin {
  PLUGIN_ID="$1"
  PLUGIN_VERSION="$2"

  sudo wget https://updates.jenkins-ci.org/download/plugins/${PLUGIN_ID}/${PLUGIN_VERSION}/${PLUGIN_ID}.hpi -O /var/lib/jenkins/plugins/${PLUGIN_ID}.jpi
}

sudo cp /tmp/config/jenkins/jenkins /etc/sysconfig/jenkins
sudo chmod 644 /etc/sysconfig/jenkins
sudo service jenkins restart

testJenkinsService

sudo wget http://localhost/jnlpJars/jenkins-cli.jar -O ${JENKINS_CLI_LOCATION}
sudo chmod 755 ${JENKINS_CLI_LOCATION}

jenkinsCli groovy /tmp/groovy/update-plugin-center.groovy
sudo service jenkins stop

installJenkinsPlugin ghprb 1.33.1
installJenkinsPlugin groovy 2.0
installJenkinsPlugin pipeline-stage-tags-metadata 1.2.7
installJenkinsPlugin throttle-concurrents 2.0.1
installJenkinsPlugin jira 2.5
installJenkinsPlugin resource-disposer 0.6
installJenkinsPlugin git-server 1.7
installJenkinsPlugin pipeline-model-declarative-agent 1.1.1
installJenkinsPlugin blueocean-core-js 1.4.2
installJenkinsPlugin jenkins-design-language 1.4.2
installJenkinsPlugin blueocean-web 1.4.2
installJenkinsPlugin pipeline-graph-analysis 1.6
installJenkinsPlugin github-pullrequest 0.1.0-rc24
installJenkinsPlugin jsch 0.1.54.2
installJenkinsPlugin pipeline-rest-api 2.8
installJenkinsPlugin cloud-stats 0.12
installJenkinsPlugin pipeline-input-step 2.8
installJenkinsPlugin docker-workflow 1.15.1
installJenkinsPlugin workflow-step-api 2.14
installJenkinsPlugin blueocean-rest-impl 1.4.2
installJenkinsPlugin pipeline-stage-view 2.8
installJenkinsPlugin javadoc 1.4
installJenkinsPlugin github-api 1.90
installJenkinsPlugin mask-passwords 2.10.1
installJenkinsPlugin windows-slaves 1.3.1
installJenkinsPlugin pubsub-light 1.12
installJenkinsPlugin blueocean-bitbucket-pipeline 1.4.2
installJenkinsPlugin badge 1.4
installJenkinsPlugin groovy-postbuild 2.4
installJenkinsPlugin jquery-detached 1.2.1
installJenkinsPlugin jquery 1.11.2-0
installJenkinsPlugin token-macro 2.1
installJenkinsPlugin plain-credentials 1.4
installJenkinsPlugin script-security 1.41
installJenkinsPlugin blueocean-i18n 1.4.2
installJenkinsPlugin ws-cleanup 0.33
installJenkinsPlugin external-monitor-job 1.7
installJenkinsPlugin jobConfigHistory 2.15
installJenkinsPlugin matrix-auth 2.2
installJenkinsPlugin pam-auth 1.3
installJenkinsPlugin ace-editor 1.1
installJenkinsPlugin workflow-cps-global-lib 2.9
installJenkinsPlugin maven-plugin 2.16
installJenkinsPlugin blueocean-display-url 2.2.0
installJenkinsPlugin junit 1.24
installJenkinsPlugin credentials-binding 1.15
installJenkinsPlugin variant 1.1
installJenkinsPlugin active-directory 2.6
installJenkinsPlugin handlebars 1.1.1
installJenkinsPlugin sonar 2.6.1
installJenkinsPlugin credentials 2.1.16
installJenkinsPlugin subversion 2.10.2
installJenkinsPlugin git-client 2.7.1
installJenkinsPlugin mercurial 2.2
installJenkinsPlugin email-ext 2.61
installJenkinsPlugin momentjs 1.1.1
installJenkinsPlugin workflow-support 2.18
installJenkinsPlugin command-launcher 1.2
installJenkinsPlugin durable-task 1.18
installJenkinsPlugin promoted-builds 2.27
installJenkinsPlugin scm-api 2.2.6
installJenkinsPlugin project-inheritance 2.0.0
installJenkinsPlugin workflow-job 2.17
installJenkinsPlugin rebuild 1.25
installJenkinsPlugin workflow-aggregator 2.5
installJenkinsPlugin antisamy-markup-formatter 1.5
installJenkinsPlugin blueocean-autofavorite 1.2.1
installJenkinsPlugin workflow-durable-task-step 2.19
installJenkinsPlugin ldap 1.15
installJenkinsPlugin blueocean-git-pipeline 1.4.2
installJenkinsPlugin blueocean-jira 1.4.2
installJenkinsPlugin blueocean-rest 1.4.2
installJenkinsPlugin docker-commons 1.11
installJenkinsPlugin cloudbees-folder 6.3
installJenkinsPlugin git 3.7.0
installJenkinsPlugin gatling 1.2.2
installJenkinsPlugin authentication-tokens 1.3
installJenkinsPlugin blueocean-pipeline-editor 1.4.2
installJenkinsPlugin buildtriggerbadge 2.8.1
installJenkinsPlugin cloudbees-bitbucket-branch-source 2.2.8
installJenkinsPlugin ssh-slaves 1.25
installJenkinsPlugin blueocean-commons 1.4.2
installJenkinsPlugin jackson2-api 2.7.3
installJenkinsPlugin blueocean 1.4.2
installJenkinsPlugin blueocean-pipeline-scm-api 1.4.2
installJenkinsPlugin ssh-agent 1.15
installJenkinsPlugin blueocean-events 1.4.2
installJenkinsPlugin envinject-api 1.5
installJenkinsPlugin envinject 2.1.5
installJenkinsPlugin blueocean-dashboard 1.4.2
installJenkinsPlugin structs 1.14
installJenkinsPlugin conditional-buildstep 1.3.5
installJenkinsPlugin github 1.27.0
installJenkinsPlugin openstack-cloud 2.22
installJenkinsPlugin pipeline-milestone-step 1.3.1
installJenkinsPlugin ansicolor 0.5.0
installJenkinsPlugin pipeline-model-extensions 1.2.7
installJenkinsPlugin blueocean-github-pipeline 1.4.2
installJenkinsPlugin run-condition 1.0
installJenkinsPlugin parameterized-trigger 2.35.2
installJenkinsPlugin display-url-api 2.2.0
installJenkinsPlugin blueocean-jwt 1.4.2
installJenkinsPlugin mailer 1.20
installJenkinsPlugin icon-shim 2.0.3
installJenkinsPlugin pipeline-stage-step 2.3
installJenkinsPlugin job-dsl 1.66
installJenkinsPlugin workflow-basic-steps 2.6
installJenkinsPlugin workflow-api 2.25
installJenkinsPlugin apache-httpcomponents-client-4-api 4.5.3-2.0
installJenkinsPlugin mapdb-api 1.0.9.0
installJenkinsPlugin flexible-publish 0.15.2
installJenkinsPlugin pipeline-model-api 1.2.7
installJenkinsPlugin favorite 2.3.1
installJenkinsPlugin blueocean-personalization 1.4.2
installJenkinsPlugin htmlpublisher 1.14
installJenkinsPlugin blueocean-pipeline-api-impl 1.4.2
installJenkinsPlugin view-job-filters 1.27
installJenkinsPlugin matrix-project 1.12
installJenkinsPlugin ant 1.8
installJenkinsPlugin metrics 3.1.2.10
installJenkinsPlugin workflow-cps 2.45
installJenkinsPlugin github-branch-source 2.3.2
installJenkinsPlugin pipeline-utility-steps 1.3.0
installJenkinsPlugin workflow-multibranch 2.17
installJenkinsPlugin config-file-provider 2.16.4
installJenkinsPlugin workflow-scm-step 2.6
installJenkinsPlugin bouncycastle-api 2.16.1
installJenkinsPlugin embeddable-build-status 1.9
installJenkinsPlugin timestamper 1.8.8
installJenkinsPlugin pipeline-model-definition 1.2.7
installJenkinsPlugin branch-api 2.0.18
installJenkinsPlugin blueocean-config 1.4.2
installJenkinsPlugin sse-gateway 1.15
installJenkinsPlugin pipeline-build-step 2.7
installJenkinsPlugin ssh-credentials 1.13
installJenkinsPlugin greenballs 1.15

sudo chown -R jenkins:jenkins /var/lib/jenkins/plugins
sudo service jenkins start

testJenkinsService

jenkinsCli groovy /tmp/groovy/system-message.groovy
jenkinsCli groovy /tmp/groovy/set-executors.groovy
jenkinsCli groovy /tmp/groovy/groovy-auto-installer.groovy
jenkinsCli groovy /tmp/groovy/jenkins-location-configuration.groovy
jenkinsCli groovy /tmp/groovy/jenkins-html-formatter.groovy
jenkinsCli groovy /tmp/groovy/timestamper.groovy
jenkinsCli groovy /tmp/groovy/rebuild-plugin.groovy
jenkinsCli groovy /tmp/groovy/active-directory.groovy
jenkinsCli groovy /tmp/groovy/create-credentials.groovy ${JENKINS_SLAVE_USER} ${JENKINS_SLAVE_PASSWORD}
jenkinsCli groovy /tmp/groovy/openstack-cloud.groovy ${OPENSTACK_IDENTITY} ${OPENSTACK_CREDENTIAL}
jenkinsCli groovy /tmp/groovy/maven-auto-installer.groovy
jenkinsCli groovy /tmp/groovy/mail-server.groovy
jenkinsCli groovy /tmp/groovy/authorization-strategy.groovy
