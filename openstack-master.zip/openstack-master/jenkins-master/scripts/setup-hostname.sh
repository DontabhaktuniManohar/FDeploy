#!/usr/bin/env bash
set_hostname='sudo sed -i "/^127.0.0.1/c 127.0.0.1 localhost $(hostname)" /etc/hosts'

eval $set_hostname

echo "@reboot $set_hostname" > cronjob
crontab cronjob
