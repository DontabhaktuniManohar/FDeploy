#!/usr/bin/env bash
set -eu

source ../set-environment.sh

openstack stack create --template heat-template/template.yaml MASTERSTACKPLACEHOLDER

