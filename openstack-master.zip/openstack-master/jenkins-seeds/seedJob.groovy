String seedDir = "jenkins-seeds/"
String folderName = ""

job(folderName+ '/keepSlaveAlive') {
    label('slave')
    description('This job will keep the slave alive.  Putting -1 in the slave expiration will do the same thing but this also acts like a ping job for this instance keeping track of any downtime.') 
    triggers {
        cron('@hourly')
    }
    steps {
        shell(readFileFromWorkspace(seedDir + 'dumpJavaSlaveInfo.sh'))
        shell('echo "Jenkins Java8 slave connected successfully!!"')
    }
}

job('JenkinsPipelineSeed') {
    logRotator(-1, 10)
    scm {      
       git {
            remote {
                url('https://github.deere.com/it-modernization/openstack-jenkins-pipeline.git')
                credentials('git-credentials')
            }
        }
      }
    
    steps {
        dsl {
            external('*.groovy')
            removeAction('DISABLE')
            ignoreExisting()
        }
    }
}
  
