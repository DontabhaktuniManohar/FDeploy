##########################################
# File: jenkins-seeds/dumpJavaSlaveInfo.sh
##########################################

ls -la
whoami 
java -version
