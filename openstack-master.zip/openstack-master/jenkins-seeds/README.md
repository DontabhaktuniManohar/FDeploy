This folder contains all the seed jobs, support files, and instructions to create the Openstack Jenkins Pipeline jenkins.

Follow these steps to create the environemnt:

1)  Using any Jenkins Instance with a openstack enabled slave
2)  Create the below credential
3)  If needed remove the instance/stack for the itm-enterprise-tooling Openstack Tenant (itm-jenkins-init)
4)  Create a freestyle job with the with the following values:
    a) Name:  itm-openstack-pipeline-creation
    b) SCM:  git, the below cred, and URL: https://github.deere.com/it-modernization/openstack-jenkins-pipeline.git
    c) A Build Step Process job-dsl with itm_jenkins_init.groovy as the job-dsl 
5)  Run the Job to create the pipeline job
6)  Run the pipeline job itm-jenkins-init
7)  Delete the job to clean up.
8)  Switch to the newly created Jenkins Instance:  http://jenkins-init.itm-tooling.ic.deere.com
9)  Create the below crentials
10) Create a new job with the following attributes:
    a) Name: JenkinsPipelineSeed
    b) git repo: https://github.deere.com/it-modernization/openstack-jenkins-pipeline.git
    c) git creds: git-access-token
    d) A Build Step Process job-dsl with *.groovy as the job-dsl 
11) run the job-dsl http://jenkins-init.itm-tooling.ic.deere.com/job/JenkinsPipelineSeed/ to create jobs.
12) Copy the text in the file https://github.deere.com/it-modernization/openstack-jenkins-pipeline/blob/master/jenkins-seeds/systemmessage.html into the Jenkins Systems Message (Management Jenkins->Configure System->System Message)

<table>
  <tr>
    <th>User Name</th>
    <th>ID</th>
    <th>Description</th>
  </tr>
  <tr>
    <td>a900480</td>
    <td>git-access-token</td>
    <td>App Id/APIKey for GIT access</td>
  </tr>
</table>
