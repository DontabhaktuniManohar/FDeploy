import json
import codecs
import os
import shutil
import subprocess
import uuid
global master_file
global logFileToMonitor

def GetValue(search_key):
    for key, value in _dataValue.items():
        if (key ==  search_key):
            corres_value = value
    return (corres_value)
    
    
def load_snippet(snippetFile):
    snippet_text = ''
    with codecs.open ("snippets/" + snippetFile, "r", "utf-8") as snippet:
        snippet_text=snippet.read()
    return snippet_text.encode('utf8', 'ignore')

def create_outfile(directory):
    if os.path.exists(directory):
        shutil.rmtree(directory)
        os.mkdir(directory)
        print("dleteing creating directory")
    else:
        os.mkdir(directory)
        print("creating directory") 

    
def POMParms(artifact):
    pomParms = []
    Segments = artifact.split('/')
    Jar_Name = Segments[-1]
    pom_version = Segments[-2]
    pom_artifactId = Segments[-3]
    pom_groupId = Segments[-4]
    pomParms.append(pom_version)
    pomParms.append(pom_artifactId)
    pomParms.append(pom_groupId)
    return pomParms
    
def JVMParmsinit():
    jvmParms = []
    jvmPath = "/www/"+jvm
    currentDeployedPath = jvmPath + "/current";
    deployRoot = jvmPath + "/deployments";
    deployDir = deployRoot + "/" + POMParms(artifact)[1] + "-" + POMParms(artifact)[0]
    workingDir = jvmPath + "/workingDir";
    logDir = jvmPath + "/logs";
    linkPath = jvmPath + "/current";
    infoDir = deployDir + "/info"
    jarPath = deployDir + "/" + POMParms(artifact)[1] +"-" + POMParms(artifact)[0] +".jar"
    processIdFilePath = deployDir +"/process.id"
    uploadedFilePath = deployDir + ".jar"
    jvmParms.append(jvmPath)
    jvmParms.append(deployRoot)
    jvmParms.append(deployDir)
    jvmParms.append(workingDir)
    jvmParms.append(infoDir)
    jvmParms.append(linkPath)
    jvmParms.append(jarPath)
    jvmParms.append(logDir)
    jvmParms.append(processIdFilePath)
    jvmParms.append(uploadedFilePath)
    return jvmParms
    
def UrlJavaCommand():
    java2 = "-Dserver.tomcat.accessLogPattern=\"%h %l %u %{sm_user}i %t %H %m :%p%U%q %s %b %D\" "
    java3 = "-Dserver.tomcat.accesslog.pattern=\"%h %l %u %{sm_user}i %t %H %m :%p%U%q %s %b %D %{X-Forwarded-For}i\" "
    java4 = "-Dspring.boot.admin.url=http://monitor.svapdevl.ic.deere.com:8070 -Dspring.boot.admin.client.service-url=http://{0}:{1} -Dspring.boot.admin.client.name=\"{2}\"".format(server,port,url)
    java1 = "nohup java -DIafConfigSuffix=\"{0}\" -DIafMOD=\"{1}\" -Dserver.port={2} -Dspring.profiles.active={0} -Dlogdir={3} -Xmx{4}M {5} {6} -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port={7} -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.rmi.port={8} -Djava.rmi.server.hostname={9} -Dcom.sun.management.jmxremote.ssl=false -Dserver.tomcat.accessLogEnabled=true {10} -Dserver.tomcat.accesslog.enabled=true {11} -Dserver.tomcat.basedir={3}/tomcat -DjvmRoute={12} -jar $jarPath > {13} <&- 2> {3}/syserr.log & AGENT_PID=$!  " \
          .format("devl",JVMParmsinit()[3],port,JVMParmsinit()[7],maxMemory,startOptions,java4,"1099","1199",server,java2,java3,loadBalancerRouteName,"/dev/null")
    return java1

def generate_stop_script():
    print("generating_stop_script ")
    server_rep = server.replace('.','_')
    global outfilestop
    outfilestop = os.path.abspath(directory + "\\"+"stop_"+os_siteid+server_rep+".sh")
    stop_data=[]
    stop_script_begin= load_snippet('stop.sh')
    stop_data.append(stop_script_begin)
    with open(outfilestop, 'w') as f:
        for script_line in stop_data:
            f.write(script_line.decode('ASCII').replace("\n","") % (
                JVMParmsinit()[0],
                JVMParmsinit()[8]
                )
                )
            print("Generated  stop_script at "+ os.path.abspath(outfilestop))
def generate_deploy_script():
    print("Generating start script")
    server_rep = server.replace('.','_')
    global outfiledeploy
    outfiledeploy = os.path.abspath(directory +"\\"+"deploy_"+os_siteid+server_rep+".sh")
    deploy_data=[]
    deploy_script_begin= load_snippet('deploy.sh')
    deploy_data.append(deploy_script_begin)
    with open(outfiledeploy, 'w') as f:
        for script_line in deploy_data:
            f.write(script_line.decode('ASCII').replace("\n","") % (
                POMParms(artifact)[1],
                POMParms(artifact)[0],
                jvm,
                JVMParmsinit()[9],
                JVMParmsinit()[0],
                JVMParmsinit()[1],
                JVMParmsinit()[2],
                JVMParmsinit()[3],
                JVMParmsinit()[4],
                JVMParmsinit()[5],
                JVMParmsinit()[6],
                artifact,
                POMParms(artifact)[1],
                POMParms(artifact)[0],
                JVMParmsinit()[2],
                "false"
                )
                )
            print("Generated  DEPLOY_script at "+ os.path.abspath(outfiledeploy))
def generate_start_script():
    print("Generating start script")
    server_rep = server.replace('.','_')
    global outfilestart
    outfilestart = os.path.abspath(directory +"\\"+"start_"+os_siteid+server_rep+".sh")
    start_data = []
    start_script_begin= load_snippet('start.sh')
    start_data.append(start_script_begin)
    with open(outfilestart, 'w') as f:
        for script_line in start_data:
            f.write(script_line.decode('ASCII').replace("\n","") % (
                os_envlvl,
                POMParms(artifact)[1],
                POMParms(artifact)[0],
                jvm ,
                port , 
                jvm,
                POMParms(artifact)[1],
                POMParms(artifact)[0],
                JVMParmsinit()[0],
                JVMParmsinit()[1],
                JVMParmsinit()[2],
                JVMParmsinit()[3],
                JVMParmsinit()[4],
                JVMParmsinit()[5],
                JVMParmsinit()[6],
                JVMParmsinit()[7],
                JVMParmsinit()[7],
                logFileToMonitor,
                UrlJavaCommand(),
                JVMParmsinit()[7],
                logFileToMonitor
                ))
            print("Generated start_script  at "+ os.path.abspath(outfilestart))
            
def generate_master_script():
    print("generating_master_script")
    master_script_begin= load_snippet('master.sh')
    master_data = []
    master_data.append(master_script_begin)
    
    with open(master_file, 'a') as f:
        for script_line in master_data:
            f.write(script_line.decode('ASCII').replace("\n","") % (
                server ,
                jvm ,
                server ,
                JVMParmsinit()[2],
                outfilestart ,
                server ,
                JVMParmsinit()[2],
                outfilestart ,
                server ,
                JVMParmsinit()[2],
                outfilestop ,
                server ,
                JVMParmsinit()[2],
                outfilestop ,
                server ,
                JVMParmsinit()[2],
                outfiledeploy ,
                server ,
                JVMParmsinit()[2],
                outfiledeploy ,
                server ,
                JVMParmsinit()[2],
                server ,
                JVMParmsinit()[2],
                server ,
                jvm
                )
                )
            print("Generated master_script at "+ master_file)
def generate_webSite_script():
    print("generating webSite script")
    webSite_script_begin= load_snippet('webSites-master.sh')
    webSite_data = []
    webSite_data.append(webSite_script_begin)
    with open(master_file, 'a') as f:
        for script_line in webSite_data:
            f.write(script_line.decode('ASCII').replace("\n","") % (
                server ,
                server ,
                temp_file ,
                source ,
                server ,
                temp_file ,
                server ,
                temp_file ,
                jvm,
                temp_file ,
                jvm ,
                temp_file
                )
                )
            print("generated webSite script at"+os.path.abspath(master_file))


    
directory = "tmp"
create_outfile(directory)
random_id=uuid.uuid4()
temp_file="svap2-spa_temp_"+str(random_id)
logFileToMonitor = "SystemOut.log";
#os_siteid = os.environ['siteID']
os_siteid = "svap2"
os_siteGroupNum = "1"
#siteGroupNum
os_programarea ="svap"
os_envlvl = "devl"
#os_programarea=os.environ['programArea']
#os_envlvl=os.environ['envlvl']
master_file = os.path.abspath(directory + "\\"+"master_"+os_siteid+"-exec.sh")
open(master_file,'a').close()
json_file_name=os_programarea+"-"+os_envlvl+".json"
print(os.path.abspath(json_file_name))
with open(json_file_name) as json_file:
    data1 = json.load(json_file)
    for keyvalues in data1:
        dataItems = keyvalues.items()
        dataKeys = keyvalues.keys()
        siteIdList = (dict(keyvalues.items())['siteId'])
        if (siteIdList == os_siteid ):
            for dataList in dataKeys:
                dataKey =  (dataList)
                dataValue = dict(dataItems)[dataList]
                if 'url' in dict(keyvalues.items()):
                    url=dict(keyvalues.items())['url']
                else:
                    url=os_siteid
                if (dataList == "javaProcesses") :
                    for _dataValue in dataValue:
                        for __dataValue in _dataValue:
                            server = GetValue("server")
                            jvm = GetValue("jvm")
                            loadBalancerRouteName = GetValue("loadBalancerRouteName")
                            artifact = GetValue("artifact")
                            siteGroupNum = GetValue("siteGroupNum")
                            port = GetValue("port")
                            startOptions = GetValue("startOptions")
                            maxMemory = GetValue("maxMemory")
                        if 'outputRedirectFile' in __dataValue:
                            outputRedirectFile = GetValue("outputRedirectFile")
                        if (os_siteGroupNum == str(siteGroupNum)):
                            print("validating")
                        generate_stop_script()
                        generate_deploy_script()
                        generate_start_script()
                        generate_master_script()
                else:
                    if (dataList == "webSites") :
                         for _dataValue in dataValue:
                            server = GetValue("server")
                            jvm = GetValue("jvm")
                            source = GetValue("source")
                            siteGroupNum = GetValue("siteGroupNum")
                            generate_webSite_script()


print("execution Done "+master_file)
#subprocess.call(["sh",master_file])
#subprocess.Popen(["sh",master_file])                        
                        
