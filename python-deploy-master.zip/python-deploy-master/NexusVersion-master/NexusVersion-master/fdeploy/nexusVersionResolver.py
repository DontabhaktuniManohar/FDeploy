# -*- coding: utf-8 -*-

import json
import os
import re
import requests  # http://docs.python-requests.org/en/latest/
import xmltodict
import fdeploy
import requests_file


class nexusVersionResolver:

    archiveDir = 'archives'
    useCache = False
    nexusRepo = 'releases'
    releasesRepo = 'releases'
    snapshotsRepo = 'snapshots'
    nexusURL = 'http://sefsmvn.ute.fedex.com:9999'
    nexusOriginalArchiveNames = {}
    nexusResolvedNames = {}
    nexusUrlPulls = {}
    tmpDir = None
    echo = None
    __manifest_resolver__ = None

    def __init__(self, options, _useCache=True, manifestResolver=None, base_dir="tmp"):
        self.__manifest_resolver__ = manifestResolver
        self.useCache = _useCache
        self.tmpDir = base_dir + "/" + self.archiveDir
        if 'silent' in options:
            self.echo = None
        if 'nexusurl' in options:
            self.nexusURL=options['nexusurl']
            if self.echo:
                print("override nexusURL with defaults %s" % (options['nexusurl']))
        if 'snapshotsrepo' in options:
            self.snapshotsRepo = options['snapshotsrepo']
            if self.echo:
                print("override snapshotsRepo with defaults %s" % (options['snapshotsrepo']))
        if 'releasesrepo' in options:
            self.releasesRepo = options['releasesrepo']
            self.nexusRepo = self.releasesRepo
            if self.echo:
                print("override releasesRepo with defaults %s" % (options['releasesrepo']))

    def resolveGavs(self, comp, downloadRequired=False):
        found = None
        for gav in comp.contents:
            if comp.isNexusArtifact(gav):
                print("resolving %s:%s, downloading required %s"  % (gav.groupId, gav.artifactId, downloadRequired))
                #if downloadRequired == True:
                #print str(gav.__dict__)
                if self.resolve(gav) is None:
                    fdeploy.trace("gav %s:%s is not found" % (gav.groupId, gav.artifactId))
                    return None
                if downloadRequired == True:
                    self.download(gav)
                found = gav
        return found

    def get_version(self,gav,majorMinorVersion=None):
        # lookup the version in the manifest
        manifest = self.__manifest_resolver__.__manifest__
        print "\n\n%s\n" % (gav)
        if manifest is None and majorMinorVersion is None:
            raise Exception("FATAL : manifest not found!")
        if (manifest.has_option('RELEASE_MANIFEST', gav.artifactId)):
            # found alternate version
            print gav.artifactId, manifest.get(
                'RELEASE_MANIFEST', gav.artifactId)
            return manifest.get(
                'RELEASE_MANIFEST', gav.artifactId)
        elif majorMinorVersion is not None:
            if self.echo:
                print("user defined resolve version %s" % (majorMinorVersion))
            return majorMinorVersion
        else:
            if manifest.has_section('RELEASE_MANIFEST'):
                print("WARNING : Unresolved version for " + str(gav.artifactId) + " thus skipping.\nWARNING : Please check your RELEASE_MANIFEST.MF, currently contains:")
                if self.echo:
                    for item in manifest.items('RELEASE_MANIFEST'):
                        print "\t " + str(item) + " looking for " + str(gav.artifactId)
                    print "\n"
                return None
            else:
                print "\nFATAL : No Release Manifest section in RELEASE_MANIFEST.MF for %s.\n" % (gav.artifactId)
                return None
        return None


    def resolve(self, gav=None, majorMinorVersion=None):
        groupId = gav.groupId
        if gav.version is None:
            if (self.__manifest_resolver__ is None or self.__manifest_resolver__.isLoaded == False) and majorMinorVersion is None:
                print("\nWARNING : No RELEASE_MANIFEST.MF found with loader for %s.\n" % (gav.artifactId))
                raise Exception("FATAL: No Release Manifest Found")
            else:
                if majorMinorVersion is not None:
                    print("user defined resolve version %s" % (majorMinorVersion))
                    gav.version = majorMinorVersion
                else:
                    gav.version = self.get_version(gav, majorMinorVersion)
            if gav.version is None:
                fdeploy.error("No Release Manifest section in RELEASE_MANIFEST.MF and no hardcoded version found in the content section for %s." % (gav.artifactId))
                return
            defaultrepo = self.nexusRepo
            # setting the repository based on the snapshot notation at the end
            # if self.echo:
            #     print "\n\t%s\n" % (gav)
            if gav.version.endswith('SNAPSHOT'):
                self.nexusRepo = self.snapshotsRepo
                defaultrepo = self.snapshotsRepo
            if gav.repoName:
                self.nexusRepo = gav.repoName
                defaultrepo = gav.repoName
            # print "nvr: %s %s <<<<<<<<<<<<<<<<-- " % (defaultrepo, gav.version)
            groupId = str(gav.groupId).replace('.', '/')
            gversion=gav.version
            gav.version = str(gav.version).replace('*', '')
            nexusMetadataUrl = "%s/nexus/content/repositories/%s/%s/%s/maven-metadata.xml" % (self.nexusURL,defaultrepo,groupId, gav.artifactId )
            
            if "file://" in nexusMetadataUrl:
                nexusMetadataUrl = "%s/%s/%s/maven-metadata.xml" % (self.nexusURL,groupId, gav.artifactId )
            # use the metadata xml in the SNAPSHOT directory, instead of the root of the artifact, to get buildnumber and timestamp
            if gav.version.endswith('SNAPSHOT'):
                nexusMetadataUrl = "%s/nexus/content/repositories/%s/%s/%s/%s/maven-metadata.xml" % (self.nexusURL,defaultrepo,groupId, gav.artifactId, gav.version )
                print nexusMetadataUrl
            print(" < retrieve metadata from " + nexusMetadataUrl)
            ret = self.getWithRetry(nexusMetadataUrl)
            if ret.ok in [200, 201] or ret.ok == True:
                response = xmltodict.parse(ret.content)
                latestVersion = gav.version
                propertyVersion = gav.version
                #if gav.version.endswith('SNAPSHOT') and response['metadata']['versioning']['snapshot']:
                if gav.version.endswith('SNAPSHOT'):
                    alias = re.sub(r'-SNAPSHOT', '', gav.version) # strip the snapshot
                    propertyVersion = "%s-%s-%s" % (alias,response['metadata']['versioning']['snapshot']['timestamp'],response['metadata']['versioning']['snapshot']['buildNumber'])
                elif type(response['metadata']['versioning']['versions']['version']) is list:
                    for row in response['metadata']['versioning']['versions']['version']:
                        if self.echo:
                            print "%s -> %s" % (row,gav.version)
                        if row.startswith(gav.version):
                            latestVersion = row
                            propertyVersion = row
                else:
                    latestVersion = response['metadata']['versioning']['versions']['version']
                    propertyVersion = latestVersion
                    if self.echo:
                        print( ">>>> only one revision available: " + latestVersion )
                gav.version = latestVersion
                gav.buildId = propertyVersion
                if self.echo:
                    print("resolved %s to %s" % (gversion, gav.version))
            else:
                if self.echo:
                    fdeploy.error("failed to load metadata %s" % (nexusMetadataUrl))
            if self.echo:
                print(" > resolved %s --> %s [%s]" % (gav.artifactId, gav.version, str(gav.buildId)))
        else:
            gav.buildId = gav.version
            print(" ! version hardcoded supplied for " + gav.artifactId + " --> " + gav.version )
        return gav

        # retry logic when confronted with a connection exception like
    # requests.exceptions.ConnectionError: HTTPConnectionPool(host='internet.proxy.fedex.com', port=3128): Max retries exceeded with url:
    def getWithRetry(self, _nexusURL, retry=3):
        ret = None
        # retry logic when confronted with a connection exception like
        # requests.exceptions.ConnectionError: HTTPConnectionPool(host='internet.proxy.fedex.com', port=3128): Max retries exceeded with url:
        while (retry > 0 and ret is None):
            try:
                if retry != 3:
                    print( "CONNECT: retries left #" + str(retry) )
                s = requests.Session()
                if 'file://' in _nexusURL:
                    s.mount('file://', FileAdapter())
                ret = s.get(_nexusURL, stream=True, proxies=fdeploy.FDX_PROXIES)
                if not ret.ok and self.echo:
                    print str(ret.content)
                break
            except IOError as e:
                fdeploy.error( "I/O error({0}): {1}".format(e.errno, e.strerror))
            retry = retry - 1
        if retry == 0 or ret is None:
            raise Exception('connection exception after ' +
                            str(3-retry) + ' retries on ' + str(_nexusURL))
        return ret
