from nexusVersionResolver import nexusVersionResolver
from pomResolver import pomResolver
from manifestResolver import manifestResolver

FDX_PROXIES = {
  'http': 'http://internet.proxy.fedex.com:3128',
  'https': 'https://internet.proxy.fedex.com:3128',
}
class Options:
    def __init__(self, **entries):
        self.__dict__.update(entries)
class gavClass(object):

    archiveFileName = None
    saveArchiveName = None

    def __init__(self, content):
        if 'gav' not in content.keys():
            raise
        gavString = content['gav']
        if gavString is None:
            raise
        gav = gavString.strip().split(':')
        retValue = {}
        self.artifactId = gav[1]
        self.groupId = gav[0]
        self.version = None
        self.saveArchiveName = content['saveArchiveName']
        self.relativePath = None
        self.classifier = None
        self.repoName = None
        self.buildId = None

        if 'relativePath' in content:
            self.relativePath = content['relativePath']
        if 'repoName' in content:
            self.repoName = content['repoName']
        if 'buildId' in content:
            self.buildId = content['buildId']
        self._archiveFileName = None

        # have to figure out these
        # group:artifact:packaging
        # group:artifact:version:packaging
        # group:artifact:packaging:classifier
        # group:artifact:version:packaging:classifier
        if len(gav) > 4:
            self.classifier = gav[4]
            self.version = gav[2]
            self.packaging = gav[3]
        elif len(gav) > 3:
            if re.match("^[0-9]+\.", gav[2]):
                self.version = gav[2]
                self.packaging = gav[3]
            else:
                self.packaging = gav[2]
                self.classifier = gav[3]
        else:
            self.version = None
            self.packaging = gav[2]
        if self.buildId is None:
            self.buildId = self.version
