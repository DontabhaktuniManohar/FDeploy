import sys
import os
import getopt
import cloudbees
import requests
import fdeploy


# disable_warnings warnings SSL
try:
    requests.packages.urllib3.disable_warnings()
except AttributeError as ar:
    pass


def main(argv=None):
    os.environ['https_proxy']='https://internet.proxy.fedex.com:3128'
    os.environ['http_proxy']='http://internet.proxy.fedex.com:3128'
    if argv is None:
        argv = sys.argv
    current='.'
    nexusURL='http://sefsmvn.ute.fedex.com:9999'
    nexusRepo='public'
    try:
        opts, args = getopt.getopt(sys.argv[1:], "hd:u:vr:")
    except getopt.error, msg:
        print "Usage: cloudbees.py [-d directory] [-f pomFileNanme] [-h]\n%s\n\n-h|--help      - this text" % (msg)
        print >>sys.stderr, msg
        print >>sys.stderr, "for help use --help"
        return 2
    for o, a in opts:
        if o in ("-h", "--help"):
            print __doc__
            sys.exit(0)
        elif o in ("-d"):
            current=a
        elif o in ("-u"):
            nexusURL=a
        elif o in ("-r"):
            nexusRepo=a
        elif o in ("-v"):
            fdeploy.info("verbose is enabled.")
            fdeploy.logLevel= fdeploy.setLogLevel(None,4)
    cldbz = cloudbees.CloudBees(nexusURL,nexusRepo)
    print cldbz.nextVersion(current)

if __name__ == "__main__":
    sys.exit(main())
