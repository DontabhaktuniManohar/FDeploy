def jobFolderName = 'ServiceAdminPortal'
def jobFolderPrefix = "${jobFolderName}/"

def disabledGlobal = false
def disabledTools = false

def jdk8 = '1.8.0_131'

def viewColumnsDef = {
	status()
	weather()
	name()
	lastSuccess()
	lastFailure()
	lastDuration()
	buildButton()
	lastBuildConsole()
}

def descriptionDslWarning = '<font color="blue">*** DSL MAINTAINED ***</font> --\nDO NOT MANUALLY MODIFY.\nManual config changes will not survive.\nEdit, commit and push the dsl script instead.'

def labelsSupportingChannelGitSsh = 'master'
def labelsSupportingChannelDeployer = "${labelsSupportingChannelGitSsh}||master"
def labelsSupportingSvapRepo = "master"

def toolJobPrefix = "${jobFolderPrefix}tool-"
def sonarJobPrefix = "${jobFolderPrefix}sonar-"
def settingsXmlOverride = '--settings ci-settings.xml --global-settings ci-settings.xml'

def getDeployerScript = '' +
		'git clone git@github.deere.com:service-operations/svap-devops.git\n' +
		'git clone git://channel.jdnet.deere.com/channel-deployer.git\n' +
		'cp channel-deployer/config/svap*.json .\n' +
		'mv channel-deployer/config/svap*.json svap-devops/src\n' +
		'cd  svap-devops/src\n' +
		'python ipn-deploy.py\n' +
		'cd tmp\n' +
		'echo $siteID\n' +
		'ls -l \n' +
		'sh master_$siteID-exec.sh \n' +
		''


////////////////////////////////////////////////////////////////////////////
// folder

folder(jobFolderName) {
	displayName jobFolderName
	description "${descriptionDslWarning}"
	configure { folder ->
		def matrix = folder / 'properties' / 'com.cloudbees.hudson.plugins.folder.properties.AuthorizationMatrixProperty' {
			permission('hudson.model.Item.Create:G90_SVAPCODR')
			permission('hudson.model.Item.Delete:G90_SVAPCODR')
			permission('hudson.model.Item.Configure:G90_SVAPCODR')
			permission('hudson.model.Item.Read:G90_SVAPCODR')
			permission('hudson.model.Item.Discover:G90_SVAPCODR')
			permission('hudson.model.Item.Build:G90_SVAPCODR')
			permission('hudson.model.Item.Workspace:G90_SVAPCODR')
			permission('hudson.model.Item.Cancel:G90_SVAPCODR')
			permission('hudson.model.Item.Release:G90_SVAPCODR')
			permission('hudson.model.Item.ViewStatus:G90_SVAPCODR')
			permission('hudson.model.Item.Move:G90_SVAPCODR')
			permission('hudson.model.Run.Delete:G90_SVAPCODR')
			permission('hudson.model.Run.Update:G90_SVAPCODR')
		}
		def vars = folder / 'properties' / 'com.cloudbees.hudson.plugins.folder.properties.EnvVarsFolderProperty' {
			properties('' +
						'ARTIFACTORY_USERNAME=a909087\n' +
						'ARTIFACTORY_ENCRYPTED_PASSWORD=AP3Z129pURVSPKjn997sfdPdUmE\n' +
			'')
		}
	}
}

////////////////////////////////////////////////////////////////////////////
// build && sonar

def viewBuildRegex = '.*build.*'

listView("${jobFolderPrefix}build"){
	columns viewColumnsDef
	jobs {
	  regex viewBuildRegex
	}
}

viewBuildRegex = '.*sonar.*'

listView("${jobFolderPrefix}sonar"){
	columns viewColumnsDef
	jobs {
	  regex viewBuildRegex
	}
}

@groovy.transform.ToString(includeNames = true, includeFields=true)
class BuildJob {
    String scmUrl
    String[] branches
    String cron = 'H/4 * * * *'
    String jdk = '1.8.0_131'
    String mavenInstallation = 'Maven 3.5.3'
    String mailTo = 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'
    boolean sonar = false
    boolean disabled = false
    
 }

def buildJobs = [
    new BuildJob([scmUrl: 'git@github.deere.com:service-operations/svap-backend.git', branches: ['master','release','hotfix','hotfix-trigger'], sonar: true, mailTo:'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,GangapuramSrinivas@JohnDeere.com'])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/svap-lib.git', branches: ['master','release']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/accountflex-component.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/azure-utils.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/ckc-client.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/dbs-client.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/isg-client.git', branches: ['master','release']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/jdparts-client.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/part-price-client.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/parts-price-microservice.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/pmcalc-client.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/powergard-client.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/product-identity-client.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/rbac-client.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/shared-preferences-component.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/support-management-component.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/svap-core.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/svap-database.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/svap-expert-alerts.git', branches: ['master','release']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/svap-notification.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/svap-preferences.git', branches: ['master','release'], sonar: true])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/svap-reporting.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/svap-messaging-projects.git', branches: ['master','release']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/svap-ui-it-dead.git', disabled: true, branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/unified-user-client.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/warranty-client.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/svap-monitor.git', cron: 'H H/4 * * *', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/spring-boot-starter-parent-svap.git', cron: 'H H/4 * * *', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/credential-utils.git', cron: 'H H/4 * * *', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/accountflex-microservice.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/maintenance-manager-repair-log.git', cron: 'H * * * *', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/translation-app.git', branches: ['master'], sonar: true])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/dtc-collector-microservice.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/eph-microservice.git', branches: ['master','release']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/machine-microservice.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/svap-elastic.git', branches: ['master','release']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/customer-microservice.git', branches: ['master','release']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/pdf-utils.git', branches: ['master']])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/svap-reporting-elastic.git', branches: ['master'], sonar: true, mailTo: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,GangapuramSrinivas@johndeere.com'])
  , new BuildJob([scmUrl: 'git@github.deere.com:service-operations/consent-api-client.git', branches: ['master'], sonar: true, mailTo: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,GangapuramSrinivas@johndeere.com'])
]
def mavenReleaseConfig = {
	releaseGoals('-Dresume=false release:prepare release:perform -DtagNameFormat=@{project.version} --show-version -Darguments="' + settingsXmlOverride + '"')
	dryRunGoals('-Dresume=false -DdryRun=true release:prepare -DtagNameFormat=@{project.version} --show-version -Darguments="' + settingsXmlOverride + '"')
	numberOfReleaseBuildsToKeep(5)
}
def buildNameConfig = '#${BUILD_NUMBER}-${GIT_REVISION,length=8}'
def envVarsPropertiesFile = '/var/lib/jenkins/InjVar/variables.properties'
def wrappersWithRelease = {
	buildName buildNameConfig
	mavenRelease mavenReleaseConfig 
	environmentVariables {
		propertiesFile(envVarsPropertiesFile)
	}
}
def wrappersNoRelease = {
	buildName buildNameConfig
	environmentVariables {
		propertiesFile(envVarsPropertiesFile)
	}
}
def wrappersDefault = {
	environmentVariables {
		propertiesFile(envVarsPropertiesFile)
	}
}

def goOfflineCommand = '' +
	    'if [ -d target ]\n' +
		'then\n' +
		'echo "Deleting previous target directory"\n' +
		'rm -rf target && mkdir -m 775 target\n' +
		'else\n' +
		'mkdir -m 775 target\n' +
		'fi\n' +
		'\n' +
		'mvn dependency:go-offline --update-snapshots ' + settingsXmlOverride + ' --show-version >.go-offline.log\n' +
		'if [ $? -eq 1 ]\n' +
		'then\n' +
		'exit 0\n' +
		'fi\n' +
		''

def git2RallyCommand = '' +
		'export PATH=$PATH:/bin/git\n' +
		'export RALLY_PROPERTIES_FILE=/var/lib/jenkins/InjVar/rally.properties\n' +
		'#export git2rally_url=https://repository.deere.com/artifactory/svap-snapshot/com/deere/svap/development/tools/git2rally/1.0-SNAPSHOT/git2rally-1.0-SNAPSHOT.jar\n' +
		'export git2rally_url=https://repository.deere.com/artifactory/svap-release/com/deere/svap/development/tools/git2rally/1.0/git2rally-1.0.jar\n' +
		'echo downloading and executing $git2rally_url\n' +
		'curl -u $ARTIFACTORY_USERNAME:$ARTIFACTORY_ENCRYPTED_PASSWORD $git2rally_url --output git2rally.jar\n' +
		'java -jar git2rally.jar\n' +
		'rm git2rally.jar\n' +
		'exit 0\n' +
		''

out.println('----- build jobs entries begin -----')
buildJobs.each {
	out.println("  -- ${it}")
}
out.println('----- build jobs entries end -----')
out.println()

def allBuildJobsCommaSeparated = ''

buildJobs.each {
  def aJob = it
  def repoPath = aJob.scmUrl
  def repoName = repoPath.substring(repoPath.lastIndexOf('/')+1)
  repoName = repoName.substring(0, repoName.indexOf('.git'))
  def repoUrlHtml = repoPath
  if(repoUrlHtml.contains('ssh://channel')) {
  	repoUrlHtml = repoUrlHtml.substring(6)
  	repoUrlHtml = repoUrlHtml.substring(repoUrlHtml.indexOf('/')+1)
  	repoUrlHtml = 'https://channel.jdnet.deere.com/code/summary/' + repoUrlHtml.replace('/', '%2F')
  	repoUrlHtml = '<a href="' + repoUrlHtml +'">\n' + repoPath + '</a>'
  }
  if(repoUrlHtml.contains('git@github.deere.com:')) {
  	repoUrlHtml = repoUrlHtml.substring(21)
  	repoUrlHtml = repoUrlHtml.take(repoUrlHtml.length()-4)
  	repoUrlHtml = 'https://github.deere.com/' + repoUrlHtml
  	repoUrlHtml = '<a href="' + repoUrlHtml +'">\n' + repoPath + '</a>'
  }
  def branchNames = aJob.branches
	branchNames.each {
	  def branchName = it
	  def isRelease = branchName == 'release'
	  def jobName = jobFolderPrefix + repoName + '_build-' + branchName + 'Branch'
	  allBuildJobsCommaSeparated = allBuildJobsCommaSeparated + jobName + ', '
		mavenJob(jobName) {
		  disabled disabledGlobal || aJob.disabled
		  configure { project ->
			project / 'settings'( class :'jenkins.mvn.FilePathSettingsProvider' ){
				'path'('ci-settings.xml')
			}
			project / 'globalSettings'( class :'jenkins.mvn.FilePathGlobalSettingsProvider' ){
				'path'('ci-settings.xml')
			}
		  }
		  description "Builds <i>${branchName}</i> branch of\n<i>${repoUrlHtml}</i>\n<br><br>${descriptionDslWarning}"
		  logRotator (30, 100)
		  jdk aJob.jdk
		  label "master"
		  triggers {
		    scm aJob.cron
		    snapshotDependencies true
		  }
		  wrappers wrappersWithRelease
		  scm {
		      git {
		          remote {
		                    url(repoPath)
		          }
		          branch branchName
		          extensions {
			        if(isRelease) {
			          wipeOutWorkspace()
			        }
					localBranch branchName
		          }
		      }
		  }
		  preBuildSteps {
		    shell git2RallyCommand
		    //shell goOfflineCommand
		  }
		  mavenInstallation(aJob.mavenInstallation)
		  goals 'clean dependency:go-offline --update-snapshots source:jar deploy --show-version'
		  mavenOpts '-Xmx1024m -Xms512m'
		  archivingDisabled true
		  publishers {
		        mailer aJob.mailTo, false, true		
		  }
  }
		
		def isMaster = branchName == 'master'
		def createSonarJob = aJob.sonar && isMaster
		if(createSonarJob) {
			def sonarJobName = "${sonarJobPrefix}${repoName}-${branchName}Branch"
			mavenJob(sonarJobName) {
				disabled disabledGlobal
			  configure { project ->
				project / 'settings'( class :'jenkins.mvn.FilePathSettingsProvider' ){
					'path'('ci-settings.xml')
				}
				project / 'globalSettings'( class :'jenkins.mvn.FilePathGlobalSettingsProvider' ){
					'path'('ci-settings.xml')
				}
			  }				
				description "runs Sonar analysis for <i>${branchName}</i> branch of <i>${repoUrlHtml}</i><br><br>${descriptionDslWarning}"
				logRotator (30, 20)
				jdk aJob.jdk
				label "master||${labelsSupportingSvapRepo}"
				wrappers wrappersNoRelease
				triggers {
					scm 'H H/4 * * * '
				}
				scm {
					git {
						remote { url(repoPath)}
						branch branchName
						extensions {
							wipeOutWorkspace()
							localBranch branchName
						}
					}
				}
				mavenInstallation(aJob.mavenInstallation)
				//preBuildSteps {
					//shell goOfflineCommand
				//}
				archivingDisabled true
				goals "clean dependency:go-offline --update-snapshots org.jacoco:jacoco-maven-plugin:prepare-agent install -U --show-version"
				configure { project ->
					project / publishers << 'hudson.plugins.sonar.SonarPublisher' {
						branch branchName
						installationName 'Channel-Sonar'
					}
				}
				publishers { mailer 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com', false, false }
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////
// deploy

def viewDeployRegex = '.*deploy.*'

listView("${jobFolderPrefix}deploy"){
	columns viewColumnsDef
	jobs {
	  regex viewDeployRegex
	}
}

@groovy.transform.ToString(includeNames = true, includeFields=true)
class DeployJob {
    String name
    Boolean disabled = false
    String environment
    String siteIds
    String groupNums = null
    String action = 'deploy'
    String cron
    String emailOnError = 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'
    String authorizedGroup
    String slaveLabels
    String authenticationToken
}
def deployJobs = [
    new DeployJob([name: 'svap2-deploy-devl', environment: 'devl', siteIds: 'svap2', slaveLabels: labelsSupportingChannelDeployer, authorizedGroup: 'G90_SVAPCODR', emailOnError: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'])     
  , new DeployJob([name: 'svap2-spa-deploy-devl', environment: 'devl', siteIds: 'svap2-spa', authenticationToken: 'DfFgGSjJDdPOGfFIj', slaveLabels: labelsSupportingChannelDeployer, authorizedGroup: 'G90_SVAPCODR', emailOnError: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'])   
  , new DeployJob([name: 'dtc-collector-deploy-devl', environment: 'devl', siteIds: 'dtc-collector', cron: null, slaveLabels: labelsSupportingChannelDeployer, authorizedGroup: 'G90_SVAPCODR', emailOnError: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'])   
  , new DeployJob([name: 'dtc-collector-deploy-qual', environment: 'qual', siteIds: 'dtc-collector', cron: null, slaveLabels: labelsSupportingChannelDeployer, authorizedGroup: 'G90_SVAPCODR', emailOnError: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'])   
  , new DeployJob([name: 'dtc-collector-deploy-cert', environment: 'cert', siteIds: 'dtc-collector', cron: null, slaveLabels: labelsSupportingChannelDeployer, authorizedGroup: 'G90_SVAPCODR', emailOnError: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'])   
  , new DeployJob([name: 'svap2-deploy-qual', environment: 'qual', siteIds: 'svap2', slaveLabels: labelsSupportingChannelDeployer, authorizedGroup: 'G90_SVAPCODR', emailOnError: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'])  
  , new DeployJob([name: 'svap2-spa-deploy-qual', environment: 'qual', siteIds: 'svap2-spa', cron: null, slaveLabels: labelsSupportingChannelDeployer, authorizedGroup: 'G90_SVAPCODR', emailOnError: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com']) 
  , new DeployJob([name: 'svap2-deploy-cert', environment: 'cert', siteIds: 'svap2', cron: null, slaveLabels: labelsSupportingChannelDeployer, authorizedGroup: 'G90_SVAPCODR', emailOnError: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'])  
  , new DeployJob([name: 'svap2-spa-deploy-cert', environment: 'cert', siteIds: 'svap2-spa', cron: null, slaveLabels: labelsSupportingChannelDeployer, authorizedGroup: 'G90_SVAPCODR', emailOnError: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'])  
  , new DeployJob([name: 'svap2-deploy-prod', environment: 'prod', siteIds: 'svap2,svap2-spa', cron: null, slaveLabels: labelsSupportingChannelDeployer, authorizedGroup: 'G90_SVAPCODR', emailOnError: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'])  
  , new DeployJob([name: 'svap2-spa-deploy-prod', environment: 'prod', siteIds: 'svap2-spa', cron: null, slaveLabels: labelsSupportingChannelDeployer, authorizedGroup: 'G90_SVAPCODR', emailOnError: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'])  
  , new DeployJob([name: 'svap2-deploy-prod-opsBouncer', environment: 'prod', siteIds: 'svap2', groupNums: '*** ENTER SERVER NUMBER HERE, e.g. if you want to bounce inst1.xxxx, then enter 1 in this field ***', action: 'restart', cron: null, slaveLabels: labelsSupportingChannelDeployer, authorizedGroup: 'G90_193_IPN_OPER', emailOnError: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'])    
]

out.println('----- deployJobs entries begin -----')
deployJobs.each {
     out.println("  -- $it")
}
out.println('----- deployJobs entries end -----')
out.println()

def deployedPropertiesPath = 'logs/deployed.properties'

deployJobs.each {
	def aJob = it
	def jobName = jobFolderPrefix + aJob.name

	def triggersConfig = null
	if(aJob.cron != null) {
		triggersConfig = {
			cron aJob.cron
		}
	}

	freeStyleJob(jobName) {
		disabled aJob.disabled || disabledGlobal
		description "<br>${aJob}<br><br>${descriptionDslWarning}"
		logRotator (30, 20)
		jdk jdk8
		label aJob.slaveLabels
		authorization {
			permission("hudson.model.Item.Cancel:${aJob.authorizedGroup}")
			permission("hudson.model.Item.Read:${aJob.authorizedGroup}")
			permission("hudson.model.Item.Configure:${aJob.authorizedGroup}")
			permission("hudson.model.Item.Discover:${aJob.authorizedGroup}")
			permission("hudson.model.Item.Build:${aJob.authorizedGroup}")
			permission("hudson.model.Item.Workspace:${aJob.authorizedGroup}")
		}
		triggers triggersConfig
		wrappers wrappersDefault
		wrappers { preBuildCleanup() }
		authenticationToken aJob.authenticationToken
		parameters {
			stringParam 'siteID', aJob.siteIds, null
			stringParam 'programArea', 'svap'
			stringParam 'envlvl',  aJob.environment
		}
		steps {
			shell getDeployerScript
			
		}
		publishers {
			mailer aJob.emailOnError, false, true
		}
	}
}

////////////////////////////////////////////////////////////////////////////
// tools

freeStyleJob("${jobFolderPrefix}tool-updateVersionsWithinSvapLib") {
	disabled disabledGlobal
	description "Updates to newer released versions of com.deere.svap dependencies inside of svap-lib, commits and pushes to svap-lib repo.\n<br><br>${descriptionDslWarning}"
	logRotator (30, 100)
	jdk jdk8
	label "master||${labelsSupportingSvapRepo}"
	scm {
		git {
			remote { url('git@github.deere.com:service-operations/svap-lib.git')}
			branch 'master'
			extensions { localBranch('master') }
		}
	}
	triggers {
		cron 'H H/3 * * *'
	}
	parameters {
		stringParam 'MVN_GOAL', 'use-latest-versions', 'see goals at http://www.mojohaus.org/versions-maven-plugin/plugin-info.html'
		stringParam 'MVN_INCLUDES', 'com.deere.svap', 'groupId:artifactId to check'
		stringParam 'MVN_ADDITIONAL_PARAMS', '-DallowMajorUpdates=false', 'see doc'
		stringParam 'MVN_PUSH_CHANGES', 'true', 'see https://maven.apache.org/scm/maven-scm-plugin/checkin-mojo.html#pushChanges'
	}
	wrappers wrappersDefault
	steps {
		shell 'mvn --update-snapshots org.codehaus.mojo:versions-maven-plugin:2.3:$MVN_GOAL -Dincludes=$MVN_INCLUDES -Dexcludes=com.deere.svap:svap-lib $MVN_ADDITIONAL_PARAMS org.apache.maven.plugins:maven-scm-plugin:1.9.5:checkin -Dmessage="versions:$MVN_GOAL" -DpushChanges=$MVN_PUSH_CHANGES --settings ci-settings.xml --global-settings ci-settings.xml'
	}
	publishers {
		mailer "MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com", false, true
	}
}

freeStyleJob("${jobFolderPrefix}tool-buildAll") {
	disabled disabledGlobal
	description "Invokes all build jobs.\n<br><br>${descriptionDslWarning}"
	logRotator (30, 100)
	jdk jdk8
	label "master||${labelsSupportingSvapRepo}"
	steps {
		shell 'echo "going to build all master branches"\n'
	}
	publishers {
		mailer "MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com", false, true
		downstream allBuildJobsCommaSeparated
	}
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// pipeline
viewBuildRegex = '.*Pipeline.*'
listView("${jobFolderPrefix}pipeline"){
	columns viewColumnsDef
	jobs {
	  regex viewBuildRegex
	}
}


@groovy.transform.ToString(includeNames = true, includeFields=true)
class PipelineJob {
	String scmUrl
	String[] branches
	String scriptPath
	String cron = 'H/4 * * * *'
	String jdk = 'jdk1.8.0_121'
	String mailTo = 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com'
}
def pipelineJobs = [
	new PipelineJob([scmUrl: 'git@github.deere.com:service-operations/svap-devops.git', branches: ['master'],scriptPath:'./SVAP-Backend-Pipeline.groovy',mailTo: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com']),
	new PipelineJob([scmUrl: 'git@github.deere.com:service-operations/svap-devops.git', branches: ['master'],scriptPath:'./SVAP-UI-Pipeline.groovy',mailTo: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com']),
	new PipelineJob([scmUrl: 'git@github.deere.com:service-operations/svap-devops.git', branches: ['master'],scriptPath:'./SVAP-Backend-Pipeline-Release.groovy',mailTo: 'MehtaAkshay@JohnDeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@JohnDeere.com']),
	]
	
	out.println('----- pipeline Jobs entries begin -----')
	
	pipelineJobs.each {
		out.println("  -- ${it}")
	}
	out.println('----- pipeline Jobsentries end -----')
	
	pipelineJobs.each {
		def aJob = it
		def repoPath = aJob.scmUrl
		def repoName = repoPath.substring(repoPath.lastIndexOf('/')+1)
		repoName = repoName.substring(0, repoName.indexOf('.git'))
		def  ScriptPath = aJob.scriptPath
		def branchNames = aJob.branches
		  branchNames.each {
			def branchName = it
			def jobName= jobFolderPrefix +'SVAP'+ScriptPath.substring(ScriptPath.lastIndexOf('/')+1)-'SVAP'-'.groovy'+'-'+'Master'
			  pipelineJob(jobName) {
				description "Builds ${branchName}"
				logRotator (30, 100)
				jdk aJob.jdk
				label "master||${labelsSupportingSvapRepo}"
				definition {
				cpsScm{
					scm {
						git {
							remote {
								url(repoPath)
								}
							branch branchName
					}
				}
				scriptPath(ScriptPath)
			}
		}
				publishers {
				  mailer aJob.mailTo, false, true
				}
			  }
		}
	}