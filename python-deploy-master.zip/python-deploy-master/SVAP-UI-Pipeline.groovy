def updateJson(level){
	sh 'pwd'
	 JsonFileName = "config/svap-" + level +".json"
	 echo JsonFileName
	 JsonDict = readJSON file: JsonFileName
	 JsonDict.each {
	   if ( it.siteId== "svap2-spa" ){
		 def webSites = it.webSites
		 webSites.each{
			def elements = it
			it."artifact" = repositoryURL
		  }
		writeJSON file: JsonFileName,json:JsonDict
		sh ' echo "writing json file is done" '
	   }
	 }
   }


timeout(20){
	
 node('slave-ui'){
  try {
  
	deleteDir()
				
	stage('Checkout') {
	    checkout([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'svap-ui']], submoduleCfg: [], userRemoteConfigs: [[url: 'git@github.deere.com:service-operations/svap-ui.git']]])
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'svap-devops']], submoduleCfg: [], userRemoteConfigs: [[url: 'git@github.deere.com:service-operations/svap-devops.git']]]
	 }
				  
	stage('Build-UI') {
			  sh '''
				cd $WORKSPACE/svap-ui
				export version=`git rev-parse --short HEAD`
				echo "final version :$version"
				cd $WORKSPACE/
				echo $WORKSPACE
				chmod 775 $WORKSPACE/svap-devops/svap-UI-build.sh && dos2unix $WORKSPACE/svap-devops/svap-UI-build.sh 
				svap-devops/svap-UI-build.sh
				'''
			}
  
	stage('Create repository URL') {
	     def version = sh returnStdout: true, script: 'git ls-remote  git@github.deere.com:service-operations/svap-ui.git  --short HEAD|cut -c1-7'
	     def VERSION = version.replaceAll("\\s","")
	     echo VERSION
	     repositoryURL = "https://repository.deere.com/artifactory/svap-snapshot/com/deere/svap/svap-ui-test/"+VERSION+"/"+"svapui-"+VERSION+".zip"
		 echo repositoryURL
		}
		  
    stage('Deploy to Devl') {
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'svap-devops']], submoduleCfg: [], userRemoteConfigs: [[url: 'git@github.deere.com:service-operations/svap-devops.git']]]
		properties([[$class: 'RebuildSettings', autoRebuild: false, rebuildDisabled: false], parameters([string(defaultValue: 'svap2-spa', description: '', name: 'siteID', trim: false), string(defaultValue: 'svap', description: '', name: 'programArea', trim: false)]), [$class: 'ThrottleJobProperty', categories: [], limitOneJobWithMatchingParams: false, maxConcurrentPerNode: 0, maxConcurrentTotal: 0, paramsToUseForLimit: '', throttleEnabled: false, throttleOption: 'project']])
		sh 'git clone git://channel.jdnet.deere.com/channel-deployer.git'
		
		dir('channel-deployer') {
		   updateJson("devl")
		}
		
		sh 'cp -avr channel-deployer/config/svap*.json svap-devops/src'
	    
	    dir('svap-devops/src') {
		sh '''
		pwd
		export envlvl="devl"
        python ipn-deploy.py
        cd tmp
        echo $siteID
        ls -l 
        sh master_$siteID-exec.sh 
        '''
        }
    }
    
    stage('Deploy to Qual') {
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'svap-devops']], submoduleCfg: [], userRemoteConfigs: [[url: 'git@github.deere.com:service-operations/svap-devops.git']]]
		properties([[$class: 'RebuildSettings', autoRebuild: false, rebuildDisabled: false], parameters([string(defaultValue: 'svap2-spa', description: '', name: 'siteID', trim: false), string(defaultValue: 'svap', description: '', name: 'programArea', trim: false)]), [$class: 'ThrottleJobProperty', categories: [], limitOneJobWithMatchingParams: false, maxConcurrentPerNode: 0, maxConcurrentTotal: 0, paramsToUseForLimit: '', throttleEnabled: false, throttleOption: 'project']])
		
		dir('channel-deployer') {
		   updateJson("qual")
		}
		
		sh 'cp -avr channel-deployer/config/svap*.json svap-devops/src'
	    
	    dir('svap-devops/src') {
		sh '''
		pwd
		export envlvl="qual"
        python ipn-deploy.py
        cd tmp
        echo $siteID
        ls -l 
        sh master_$siteID-exec.sh 
        '''
        }
    }

		  currentBuild.result = 'SUCCESS'
		  echo "Present SVAP-UI-Pipeline Build ${currentBuild.number} is ${currentBuild.result}"
 }
	   
 catch (Exception err) {
  currentBuild.result = 'FAILURE'
  }
	  
 finally{
  echo " ***************** "
  if(currentBuild.getPreviousBuild().result!=currentBuild.result){
             stage('Email Publishing'){
              def CnslURL= BUILD_URL + "console"
	          echo CnslURL
	     	  mail to: "MehtaAkshay@johndeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@johndeere.com",
	          subject: "status for the project: ${currentBuild.result} ",
	          body:"${currentBuild.result} SVAP-UI-Pipeline Build #${currentBuild.number} is ${currentBuild.result} and Can see the result of the 			build execution at ${CnslURL}"
	          echo "${currentBuild.result} SVAP-UI-Pipeline Build ${currentBuild.number} is ${currentBuild.result}"
	          }
         }
        else{
         println "Build State has not changed hence no mail publishing is required."
        }
    }				 
	  
 }
}