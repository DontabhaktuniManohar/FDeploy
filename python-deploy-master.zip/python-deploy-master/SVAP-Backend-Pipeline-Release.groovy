def updateJson(level){
 sh 'pwd'
  JsonFileName = "src/svap-" + level +".json"
  JsonDict = readJSON file: JsonFileName
  JsonDict.each {
    if ( it.siteId== "svap2" ){
      def JavaProcesses = it.javaProcesses
	  JavaProcesses.each{
		 def elements = it
		 it."artifact" = repositoryURL
       }
     writeJSON file: JsonFileName,json:JsonDict
     sh ' echo "writing json file is done" '
    }
  }
}

timeout(30){
  node('master'){
    try {
        
	def jdk8 = 'jdk1.8.0_121'
	echo "Build success!!"
    	stage('Build Release Branch'){
    	checkout([$class: 'GitSCM', branches: [[name: '*/release']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'svap-backend']], submoduleCfg: [], userRemoteConfigs: [[url: 'git@github.deere.com:service-operations/svap-backend.git']]])
        build 'svap-backend_build-releaseBranch'
    }
    stage('Wipe-out') {
		deleteDir()
	  }

    stage('Create repository URL') {
	 git branch: 'release', url: 'git@github.deere.com:service-operations/svap-backend.git'
         def t = readMavenPom file: 'svap-ui/pom.xml'
         def ARTIFACT_ID =  t.artifactId
         echo ARTIFACT_ID
         def VERSION = t.version
         echo VERSION
         def GRP_ID = t.parent.groupId
         def GROUP_ID = GRP_ID.replace(".","/")
         echo GROUP_ID
         repositoryURL = "https://repository.deere.com/artifactory/svap-snapshot/" + GROUP_ID + "/" + ARTIFACT_ID + "/" + VERSION +"/" + ARTIFACT_ID +"-" 	+VERSION +".jar"
         echo repositoryURL

		}
 
    def file = readFile '/var/lib/jenkins/InjVar/variables.properties'
        props=[:]
        file.eachLine{ line ->
        l=line.split("=")
         props[l[0]]=l[1]
        }
    
    withEnv(['ARTIFACTORY_ENCRYPTED_PASSWORD='+props["ARTIFACTORY_ENCRYPTED_PASSWORD"]]) {
		stage('Deploy to Cert') {
 		git branch: 'master', url: 'git@github.deere.com:service-operations/svap-devops.git'
 		updateJson("cert")
 		sh '''cd src
 		    export siteID='svap2'
 		    export envlvl='cert'
 		    export programArea='svap'
                     python ipn-deploy.py
                     cd tmp
                     sh master_$siteID-exec.sh''' 
 		 }
         }
        currentBuild.result = 'SUCCESS'
		echo "Present SVAP-Backend-Pipeline Build ${currentBuild.number} is ${currentBuild.result}"
    }
    
    catch (Exception err) {
        currentBuild.result = 'FAILURE'
    }
    
     finally{
        echo " ***************** "
        if(currentBuild.getPreviousBuild().result!=currentBuild.result){
             stage('publish'){
              def CnslURL= BUILD_URL + "console"
	          echo CnslURL
	     	  mail to: "MehtaAkshay@johndeere.com,MaheshwariPurvesh@johndeere.com,gangapuramsrinivas@johndeere.com",
	          subject: "status for the project: ${currentBuild.result} ",
	          body:"${currentBuild.result} SVAP-Backend-Pipeline Build #${currentBuild.number} is ${currentBuild.result} and Can see the result of the 			build execution at ${CnslURL}"
	          echo "${currentBuild.result} SVAP-Backend-Pipeline Build ${currentBuild.number} is ${currentBuild.result}"
	          }
         }
        else{
         println "Build State has not changed hence no mail publishing is required."
        }
	} 	
  }
}