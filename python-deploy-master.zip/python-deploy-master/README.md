# svap-devops

## jenkins-jobs-dsl
[View the online documentation](https://jenkinsci.github.io/job-dsl-plugin/)

### Jenkins Documentation

[Details of jenkins starts here](https://jenkins.io/doc/)


<sub>*DSL is the first thing here for svap jenkins.<sub>

## Developing DSL script
1. Define what are the views and the jobs inside the views here we have like build, deploy, sonar, pipeline.
2. Define the Permissions and accesses that users can have on job level, folder level and overall.
3. Define the tools being used for building application like Java, Maven. 
4. Define viewColumns such as status() , weather() ,name(), lastSuccess(), lastFailure().
5. Define build jobs with scmurls, branches and other options.
6. Define deploy jobs with properties such as siteID, environment, programArea which are parameters to those jobs.

```
def jobFolderName = 'ServiceAdminPortal'
def viewColumnsDef 
def getDeployerScript 
folder(jobFolderName)
listView()
class BuildJob
class DeployJob
```



## SVAP UI Build and Deployment
		

```
 nvm install 8.10.0 64
 nvm use 8.10.0
 npm install
 npm install -g yarn
 yarn
 yarn build or npm run build 
```
 
## Installing and Running Locally

SVAP UI build documentation can be found here. [dev-wiki](http://devwiki.deere.com/wiki/Svap:ui:how-to-setup-environment) 

Note, [nvm](https://github.com/creationix/nvm) is not required. If you do not have it installed, just be sure you to use the correct node version as specified in [.nvmrc](./.nvmrc).
```
git clone git@github.deere.com:service-operations/svap-ui.git
cd svap-ui
nvm use
yarn
npm install
npm run dev
```
<sub>*See it on local server.<sub>

The start command is configured to automatically open your default browser to http://localhost:3000

## UI Pipeline

UI Pipeline will build the latest changes from the [svap-ui git code base](https://github.deere.com/service-operations/svap-ui)and builds it.
Once the build is ready jenkins will push that to Artifactory for future deployments.
Successful build will trigger the deploy job that for Devl Environment.
If the above is Successful will trigger the deploy job that for Qual Environment.
This job will automatically update and push `package.json` with the new version number. **Do not** push to master while this job is running, otherwise it will fail when it attempts to update `package.json`.



## Backend Pipeline

Backend Pipeline has 

##### Steps
 - Svap-Backend_build-Master
 - Triggers Pipeline job
 - Read the pom artifact
 - SonarJob Executes
 - Read Deployer Json(Devl)
 - Get artifact from Jfrog
 - Deploy on Devl env
 - Read Deployer Json(Qual)
 - Get artifact from Jfrog
 - Deploy on Qual env
 

This pipeline is for making the build and deployment process continuous on the svap-backend under the service admin portal by using Jenkins DSL and Pipeline Scripts.

Uses the same properties files and permissions as the base Jenkins Seed job and Jenkins-dsl-jobs.

It gets the projects Pom.xml into the Jenkins workspace and it reads the project properties from there and uses it for getting the right artifact from the Jfrog repository by reading the JSON file in Gitblit.

Flow of the pipeline execution starts from the successful execution of the svap-backend master or release branch build jobs. Once the build job executes successfully, downstream pipeline job is triggered.

Pipeline job triggers the execution of Sonar-Job based on respective branch(master/release). It propagates the results and triggers reads the Gitblit JSON file into the Workspace which is used for deployment of the artifact onto the openstack instances.

The proper artifact which is read from pom.xml file of the project and which is stored on jfrog repo will be deployed onto the instances running on openstack in Devl environment first.

If the Deployment on the Devl environment is successful then it triggers the next stage of deployment in Qual environment.

**Plugins Used**

- Github Integration

- Pipeline Utility steps

- Jenkins Pipeline

- Jenkins Job DSL 


**URLs**

Github Project: (https://github.deere.com/service-operations/svap-backend)

DSL Project: (https://github.deere.com/service-operations/jenkins-svap-jobs-dsl)

Jfrog Artifactory: (https://repository.deere.com/artifactory/webapp/#/home)


## Python-Deployer

- Python deployer basically used for creating the Scripts that are essential for deploying the build artifacts.
- Based on the Parameters we pass to the deployer script it will create the scripts that are specific to the deployment servers.
- Basically we have 3 Scripts which are written in shell.
- stop.sh will stop the existing process thats running on the server, deploy.sh will get the latest build from the artifact store.
- start.sh is the script that will start the new process with the new Manifest.MF Application Jar.  

## Links to Jenkins

- Jenkins Master on the ESF- (http://master.svapjenkins.ic-esf.deere.com:8080)
- Jenkins Master on the 19st- (http://master.svapjenkins.ic.deere.com:8080) 
- Hope you must be familiar with CI Build Server (https://cibuild.deere.com/Channel/job/ServiceAdminPortal/)
