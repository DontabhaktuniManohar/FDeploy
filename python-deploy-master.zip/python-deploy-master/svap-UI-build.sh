. $HOME/.nvm/nvm.sh
nvm --version
export CI_APP=SVAP
export CI_NPM_VERSION=8.10.0
export CI_NPM_ARGS="build  --max-old-space-size=2048"
export CI_BUILD_DIR_NAME=svap-ui
export CI_GIT_SERVER_REPO=git@github.deere.com:service-operations/svap-ui.git

export CI_CHANGE_TO_BUILD=$1
if ["$1" -eq ""]
then
export CI_CHANGE_TO_BUILD=master
fi

export CI_ROOT=`pwd`
export CI_CHANGESET_DIR=${CI_ROOT}/builds
export CI_LOG_DIR=${CI_CHANGESET_DIR}/logs
export CI_POLL_FILE=${CI_LOG_DIR}/${CI_APP}-poll-${CI_CHANGE_TO_BUILD}.log
export CI_NPM_PATH="npm"
export CI_NVM_PATH="nvm"
export CI_YARN_PATH="yarn"
export CI_BUILD_CMD="${CI_YARN_PATH} ${CI_NPM_ARGS} --ignore-engines"
export CI_FINAL_DEST=${CI_ROOT}/spa
mkdir -pv ${CI_LOG_DIR}
date "+%d-%m-%Y" | tee ${CI_POLL_FILE}
date +"%H:%M" | tee -a ${CI_POLL_FILE}
cd ${CI_BUILD_DIR_NAME}
export CI_CHANGESET_OLD=`git rev-parse --short HEAD`
git fetch
git checkout ${CI_CHANGESET_TO_BUILD}
git pull
export CI_CHANGESET=`git rev-parse --short HEAD`
export MSG="`pwd` was ${CI_CHANGESET_OLD} - now ${CI_CHANGESET}"
echo ${MSFG}
echo ${MSFG} | tee -a ${CI_POLL_FILE}
export CI_CHANGESET_DEST=${CI_CHANGESET_DIR}/${CI_APP}-${CI_CHANGESET}
export CI_LOG_FILE=${CI_LOG_DIR}/${CI_APP}-${CI_CHANGESET}.log
export MSG="skipping build $CI_CHANGESET_TO_BUILD : ${CI_CHANGESET}, already built at $CI_CHANGESET_DEST"
echo "---------------------------------"
echo $version
echo "----------------------------------"
if  [ -d ${CI_CHANGESET_DEST} ]
then
        echo $MSG
        echo $MSG | tee -a ${CI_POLL_FILE}
        if  [ ! -d "${CI_FINAL_DEST}" ]
        then
                export MSG="$MSG , but ${CI_FINAL_DEST} doesn't exist... going to re-deploy there"
                echo $MSG
                echo $MSG | tee -a ${CI_POLL_FILE}
                md ${CI_FINAL_DEST}
                yes|cp -avr  ${CI_CHANGESET_DEST}/*.* ${CI_FINAL_DEST}

        fi
fi

date "+%d-%m-%Y" | tee -a ${CI_POLL_FILE}
date +"%H:%M" | tee -a ${CI_POLL_FILE}
export MSG="building $CI_CHANGESET_TO_BUILD : $CI_APP:$CI_CHANGESET to $CI_CHANGESET_DEST"
echo ${MSFG}
echo ${MSFG} | tee -a ${CI_POLL_FILE}
echo ${MSFG} | tee -a ${CI_POLL_FILE}
mkdir -p  $CI_CHANGESET_DIR

$CI_NVM_PATH use $CI_NPM_VERSION | tee -a ${CI_POLL_FILE}
export NPM_VERSION=`${CI_NPM_PATH} --version`
echo " npm version = $NPM_VERSION "| tee -a ${CI_POLL_FILE}
yarn --version
pwd
${CI_YARN_PATH} | tee -a ${CI_POLL_FILE}
$CI_BUILD_CMD | tee -a ${CI_POLL_FILE}
git log --all --pretty=format:"* [%h] %s (%ad) <%aN>" --date=short >dist/changelog.txt
mkdir -p  ${CI_CHANGESET_DEST}
cp -avrf dist/*.* $CI_CHANGESET_DEST
cd dist
archivefname="svapui-$version.zip"
echo $archivefname
zip -r $archivefname *
curl -H "x-api-key:AKCp5ZjpnvzTDDvexXnW5Fy6GrJYaT4n9Dq93W1q7wA4fuWkQs8M6TkM1LBkUdejB9J6pP771" -T $archivefname -X PUT "http://ldxx90jfrog2.dx.deere.com:8081/artifactory/svap-snapshot/com/deere/svap/svap-ui-test/$version/$archivefname"