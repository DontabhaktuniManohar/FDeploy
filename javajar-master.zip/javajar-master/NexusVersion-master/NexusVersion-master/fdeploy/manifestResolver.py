# -*- coding: utf-8 -*-

import os
import os.path
import sys
import re
import fdeploy
import ConfigParser


class manifestResolver:

    __manifest__ = None
    __metadata__ = None
    isLoaded = False
    manifestFile = None
    manifestdir = None
    debug = False
    manifestLookup = {}

    def __init__(self, basedir, level):
        self.__manifest__ = ConfigParser.RawConfigParser()
        self.__metadata__ = ConfigParser.RawConfigParser()
        self.manifestdir = basedir + "/" + level
        self.__readManifest()

    def __readManifest(self):
        self.manifestFile = os.path.normpath(
            os.path.abspath(self.manifestdir + '/RELEASE_MANIFEST.MF'))
        metadataManifest = self.manifestdir + '/../RELEASE.metadata'
        if os.path.exists(self.manifestFile):
            retList = self.__manifest__.read(self.manifestFile)
            fdeploy.info( " < read manifest " + self.manifestFile )
            self.isLoaded = True
            fdeploy.trace( str(self.__manifest__.items('RELEASE_MANIFEST')))
            #print str(self.__manifest__.items('RELEASE_MANIFEST'))
            for artifactId in self.__manifest__.items('RELEASE_MANIFEST'):
                #print "-> %s" % (str(artifactId))
                if artifactId[1] is not None: # and artifactId[1].endswith("*"):
                    # remove astrix
                    version= artifactId[1].replace('*','')
                    self.manifestLookup[artifactId[0]]=version
                else:
                    fdeploy.debug("  --> %s is omitted by manifest" % (artifactId[0]))
        else:
            fdeploy.warn( " ! no release_manifest found for " + str(self.manifestFile))
        #print str(self.manifestLookup)
        if os.path.exists(metadataManifest):
            retList = self.__metadata__.read(metadataManifest)
            fdeploy.debug( " < read metadata" + metadataManifest )
            fdeploy.trace( str(self.__metadata__.items('RELEASE_METADATA')))
            self.releaseName = self.__metadata__.get(
                'RELEASE_METADATA', 'name')
            self.releaseVersion = self.__metadata__.get(
                'RELEASE_METADATA', 'version')
            fdeploy.debug( "metadata = %s / %s" % (self.releaseName, self.releaseVersion))

    def lookup(self, key):
        try:
            return self.manifestLookup[key]
        except KeyError:
            fdeploy.warn("key %s not found, registered %s." % (key, self.manifestLookup.keys()))
            return None

# manifest.get(
#     'RELEASE_MANIFEST', gav.artifactId)
