import fdeploy
import re

# SEE TESTCASES UNDER fdeploy NEXUS RESOLVER

class CloudBees(object):

    nexusURL = fdeploy.nexusVersionResolver.nexusURL
    nexusRepo = fdeploy.nexusVersionResolver.nexusRepo
    nexusVersionResolver = None
    echo = None

    def __init__(self, _nexusURL='https://nexus.prod.cloud.fedex.com:8443', _repoName='public'):
        if _nexusURL is not None:
            self.nexusURL = _nexusURL
        if _repoName is not None:
            self.nexusRepo = _repoName
        self.nexusVersionResolver = fdeploy.nexusVersionResolver({ 'nexusurl' : self.nexusURL, 'silent' : 'True'})

    def nextVersion(self,pom_dir='.',pom_file='pom.xml'):
        pom=fdeploy.pomResolver(pom_dir,pom_file)
        if self.echo:
            print "pom=%s " % (pom.version)
        gav=self.increment_major_minor_version({'groupId':pom.groupId, 'artifactId' : pom.artifactId}, pom.version,self.nexusRepo)
        if self.echo:
            print "gav=%s " % (gav)
        return gav.version

    def increment_major_minor_version(self, gav, versionNumber, repoName=None):
        gavresult=self.latest_major_minor_version(gav,versionNumber, repoName)
        newVersion = re.sub( r'-SNAPSHOT$', '', gavresult.version)
        if "-SNAPSHOT" not in gavresult.version:
            newVersion = self.increment_version(newVersion)
        gavresult.version = newVersion
        return gavresult

    def __getLatest_major_minor_version(self, gav, majorMinorVersion, repoName=None):
        if 'groupId' not in gav:
            raise AttributeError('missing groupId in gav dictionary %s' % (gav))
        if 'artifactId' not in gav:
            raise AttributeError('missing artifactId in gav dictionary %s' % (gav))
        if repoName is None:
            repoName = self.nexusRepo

        gavString = "%s:%s:jar" % (gav['groupId'], gav['artifactId'])
        if self.echo:
            print "gavstring=%s [[[[[%s]]]]]" % (gavString,majorMinorVersion)
        gavObject = fdeploy.gavClass({'gav' : gavString, 'saveArchiveName' : 'temp.zip', 'repoName' : repoName })
        if self.echo:
            print "gav obje=%s -> %s" % (gavObject, majorMinorVersion)
        return self.nexusVersionResolver.resolve(gavObject, majorMinorVersion)

    def latest_major_minor_version(self, gav, versionNumber, repoName=None):
        if 'groupId' not in gav:
            raise AttributeError('missing groupId in gav dictionary %s' % (gav))
        if 'artifactId' not in gav:
            raise AttributeError('missing artifactId in gav dictionary %s' % (gav))
        return self.__getLatest_major_minor_version(gav,self.getMajorMinorVersion(versionNumber), repoName)

    def getMajorMinorVersion(self,versionNumber):
        if versionNumber is None:
            return None
        if "-SNAPSHOT" in versionNumber:
            versionNumber = re.sub( r'-SNAPSHOT$', '', versionNumber)
        if re.match( r'^R-', versionNumber):
            versionNumber = re.sub(r'^R-','', versionNumber)
        try:
            nrs=versionNumber.split('.')[0:2]
            return "%s.%s" % (nrs[0],nrs[1])
        except (IndexError):
            return versionNumber

    def increment_version(self, versionNumber):
        buildId=0
        if versionNumber is None:
            raise AttributeError("must supply semantic version number as argument")
        if "-SNAPSHOT" in versionNumber:
            versionNumber = re.sub( r'-SNAPSHOT$', '', versionNumber)
        try:
            items=versionNumber.split('.')
            buildId = -1
            cursor=len(items)-1
            # find the first digit from the right
            words=[]
            nrs=[]
            _semantic=list(reversed(items))
            for idx, item in enumerate(_semantic):
                try:
                    buildId=int(item)
                    nrs.append(item)
                except ValueError:
                    words.append(item)
            if len(nrs) == 2:
                nrs = list(reversed(nrs))
                nrs.append('0')
            else:
                buildId=int(nrs[0])
                nrs[0] = str(buildId + 1)
                nrs = list(reversed(nrs))
            if len(words) > 0:
                words = list(reversed(words))
            nrs.extend(words)
            return '.'.join(nrs)
        except (IndexError):
            return "%s.0" % (versionNumber)
