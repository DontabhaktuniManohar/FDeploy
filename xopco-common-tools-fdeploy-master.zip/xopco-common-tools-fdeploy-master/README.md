RELEASE NOTES:

```shell
bash <(curl -s http://sefsmvn.ute.fedex.com/fdeploy-install.sh) -v 7.1.0 "FXE:com.fedex.sefs.core:fdeploy_FXE_CORE:1.0.55" "FXF:com.fedex.fxf.core:fdeploy_FXF:3.0.15-SNAPSHOT"
bash <(curl -s http://sefsmvn.ute.fedex.com/fdeploy-install.sh) -v 7.1.0 git@gitlab.prod.fedex.com:APPxxxx/deployment_items.git
```


### 7.1.0 - adding PAM support (Wed Oct 24 17:11 MDT)
| issue | description |
|----|----|
| pcf-pam | integrating PAM into the pcf module with PAM_ID as mandatory item in json |
| pcf-ldd | ablitiy to push pcf information to LDD |
| firewall | adding firewall request generator logic |
| hooks | externalizing hooks like mattermost or ldd from main logic |
| pcf-cups | user provider services integration with fdeploy |
| calculator | fixed order of version calc in right order v3 and then v2 |


### 7.0.11 - fixing snapshot downloads across multiple repos (Fri Oct 19 13:44 MDT)
| issue | description |
|----|----|
| install | scan Nexusv3 and NexusV2 for snapshot version and take creation date for calculation |

### 7.0.10 - fixing early break in exact versioning (Thu Oct 18 17:48 MDT)
| issue | description |
|----|----|
| nexusresolver | scan Nexusv3 and NexusV2 for exact version calculation and not returning None |


### 7.0.9 - fixing incrementor (Wed Oct 17 13:50:58 MDT)
| issue | description |
|----|----|
| cloudbees.py | scan Nexusv3 and NexusV2 for next version calculation |


### 7.0.7 - fixing incrementor (Mon Oct 15 14:47:58 MDT)
| issue | description |
|----|----|
| cloudbees.py | changing the order to retrieve last version for incrementor starting with Nexusv3 |


### 7.0.4 - fixing the mavenmetadata xml  (Sat Oct 13 16:58 MDT)
| issue | description |
|----|----|
| metadata | fixing the Nexus v3 url for snapshot meta data retrieval  |


### 7.0.3 - install.py failure to unpack (Tue Sep 14 10:58 MDT)
| issue | description |
|----|----|
| unpack deployment items | install.py failure to unpack deployment items from nexus after successful download  |



### 7.0.2 - cloudbees.py numbering defect (Fri Sep 14 18:52 MDT)
| issue | description |
|----|----|
| cloudbees | problem with virgin installs getting back the base number |


### 7.0.1 - Nexus v2 and v3 auto-detect
| issue | description |
|----|----|
| auto-detect | Enabling artifact resolving from two or more repositories v2 and v3 |


### 7.0.0 - Nexus v2 and v3 extended / Silver Retirement
| issue | description |
|----|----|
|install | Addressed changes in the installation process for Nexus v3 to work |
| retire | Retiring all silver scripts components and renaming the package to standard CM naming |

### 6.2.5 - Nexus v2 and v3
| issue | description |
|----|----|
|nexusv3 | After migration of corporate nexus to v3.x PRO the download urls by means of REST are not working, refactored nexusresolver. |


### 6.2.4 - Analytics Integration

| issue | description |
|-----|-----|
| analytics | integration hooks with Google Analytics  |
| BW | multiple issues resolved related to `tibco_bw` and `tibco_bw2`. |


### 6.2.3 - Refactored Calculation and added more testing


| issue | description |
|-----|-----|
| incrementor | the calculation rules would be distorted based on the type of resolving that was done. Splitted it up in an next version track and manifest track. |
| fixed FXG publishing | addressed issue in lddpublisher to make the opco dynamic based on the configuration loaded. |
| snapshot resolving | fixed the snapshot resolving of meta data |
| LDD BW registration | improved the BW way to look up the ps signature to pickup BW processes. |
| smoketests | added remote invocation of smoke and regression tests from the pipeline to integrate with fdeploy |

### 6.2.2 - Tangosol Java_Auto Fix

| issue | description |
|-----|-----|
| tangasol | `java_auto` TANGASOL not starting up, or not seeing the TANGASOL parameters on the startup footprint of the java process.   |

### 6.2.1 -

| issue | description |
|-----|-----|
| number increments | aligned the cloudbees numbering incrementor and resolver + test cases |
| manifest resolving | fixes manifest resolve issue and fixed the bulk test on Jenkins  |


### 6.2.0 -

| issue | description |
|-----|-----|
| bw_level_fix | removed escaping level variable in the root remote shells to prevent problems with level specific operations |
| PCF | added blue green deployment |


### 6.1.104 - PCF routing, BW naming, Java_auto tangasol (May 31st, 2018)

| issue | description |
|-----|-----|
| 6.1.43 | Issue with log4j.xml replacement in suStop BE engine |
| 6.1.24 |  adding target selection when doing deploy -> deploy |
| 6.1.41 | 41-pcf-routing-host-naming-has-wip-in-the-naming-and-should-be-removed |
| 6.1.34 | 34-adding-corporate-load-environments-to-all-options-in-silvercontrol |
| 6.1.36 | 36-bw-engine-is-getting-over-ridden-while-deployment-on-l3-and-is-running-on-new-tlms-as-per-cl3 |
| 6.1.44 | 44-java_auto-hostname-replacement-takes-the-build-host-not-the-runtime-host |

### 6.1.103 - release MTP Java_auto release (May 16th,2018)

| issue | description |
|-----|-----|
| 6.1.26 | 26-deploy-wipeout-option-not-working-with-f-deploy'  |
| adhoc | fixing java_auto snippet EAINUMBER to EAI_NUMBER |
| 6.1.37 | 37-pcf-fdeploy-all-applications-in-a-space-are-getting-deleted-when-we-use-deploy-clean |
| 6.1.38 | 38-pcf-fdeploy-deploy-install-of-an-application-also-starts-the-apps-replicating-the-functionality-of-deploy-deploy |
| 6.1.39 | 39-to-capture-user-information-while-deployments-in-deployment-history-table |
| 6.1.40 | 40-pcf-fdeploy-redeploying-an-existing-application-on-pcf the-newly-deployed-application-gets-deployed by-a-different-name-from-the-json-defined-app_nm |

### 6.1.102 - release (May 11th, 2018)

Includes:

| issue/feature | description |
|-----|-----|
| 6.1.31 | https://gitlab.prod.fedex.com/bananaman/fdeploy/issues/31 : filecopy type for BW log4j.xml distribution |
| 6.1.36 | BW in stacked environment cannot be artifactId but must be unique for each instance. |
| patch-1 | filecoyp fix |
| 6.1.33 | java_auto-changes-for-rely-jvm-controls + deploy:properties command introduction |
| pcf    | pcf generator introduction |
| 6.1.8  | fdeploy-relink-option-not-working-for-bash-deploys-since-at-before-6-0-21 |
| 6.1.18 | remove 18-adding-a-previous-link-when-relinking-and-application |
| 6.1.29 | 29-unable-to-create-stdout-log-and-stderr-log-while-starting-up-be-applications-in-l2-for-fxf |
| 6.1.27 | Unable to pass this ENGINE_USERNAME in case of AS member name in the RTV section of the JSON file for L4 level onwards |
