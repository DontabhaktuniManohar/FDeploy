# -*- coding: utf-8 -*-

import xmltodict
import os

class pomResolver:

    version=None
    groupId=None
    artifactId=None
    #classifier=None

    def __init__(self, pom_dir=".",pom_file='pom.xml'):
        path_ = os.path.abspath(os.path.expanduser(os.path.normpath("%s/%s" % (pom_dir,pom_file))))
        if os.path.isfile(path_) == True:
            with open(path_) as fd:
                doc = xmltodict.parse(fd.read())
            if doc is None:
                return 1
            self.artifactId= doc['project']['artifactId']
            if 'groupId' in doc['project'].keys():
                self.groupId= doc['project']['groupId']
            elif 'parent' in doc['project'].keys() and 'groupId' in doc['project']['parent'].keys():
                self.groupId= doc['project']['parent']['groupId']
            # resolve version
            if 'version' in doc['project'].keys():
                self.version= doc['project']['version']
            elif 'parent' in doc['project'].keys() and 'version' in doc['project']['parent'].keys():
                self.version= doc['project']['parent']['version']
            else:
                raise Exception("illegal pom structure %s" % (path_))
        else:
            raise Exception("%s not found" % (path_))
