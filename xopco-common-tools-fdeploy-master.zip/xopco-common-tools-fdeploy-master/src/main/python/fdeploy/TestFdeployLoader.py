import unittest2
import os
import fdeploy
import cloudbees
from fdeploy.fdeployLoader import split
from fdeploy import level2code


REQUIRED_RTVS = []
REGISTERED_ACTIONS = ['clean', 'wipeout', 'start', 'stop', 'install', 'stage', 'ml', 'machine_list',
                      'deploy', 'publish', 'unpublish', 'restart', 'report', 'ssh', 'inspect', 'ps', 'cloudenv', 'status']
# ls -lrt ../../test/resources/FXE_fdeploy/*.json | wc -l
JAVA_COUNT = 42
BW_COUNT = 6
REST_COUNT = 17

class testGenerator(fdeploy.platform.baseGenerator):

    def __init__(self, component, cli_options):
        self.REGISTERED_ACTIONS = fdeploy.TestFdeployLoader.REGISTERED_ACTIONS
        self.REQUIRED_RTVS = fdeploy.TestFdeployLoader.REQUIRED_RTVS
        super(testGenerator, self).__init__(
            component, cli_options)


test_component = fdeploy.fdeployComponent({
    'id': 'componentId',
    'platform': 'bash_generator',
    'type': 'tibco_bw2',
    'filter':
        {"var1": "value1", "var2": "value2"},
    'content':  [{
        "gav": "com.fedex.sefs.core:sefs_suCLEARANCEFeed:zip",
        "relativePath": "${level}/${var1}.sh",
        "saveArchiveName": "sefs_suCLEARANCEFeed.zip"
    }],
    'name_format': 'format',
    'levels':
    [{
        'level': 'L1',
        'rtv' : [ { 'name' : 'JMX_PORT', 'value' : '40313'}],
        'targets': ['a@fedex.com', 'b@fedex.com', 'c@fedex.com', 'd@fedex.com', 'e@fedex.com']
    }, {
        'level': 'L2',
        'targets': ['a@fedex.com', 'b@fedex.com', 'c@fedex.com', 'd@fedex.com', 'e@fedex.com', 'f@fedex.com', 'g@fedex.com', 'h@fedex.com', 'i@fedex.com', 'j@fedex.com']
    }, {
        'level': 'L3',
        'targets': ['a@fedex.com']
    }],
    'rtv': [
            {'name': 'JAVA_HOME',
             'value': '/opt/java/hotspot'
             },
         { 'name' : 'JMX_PORT', 'value' : 'ABCDEF'},
            { 'name' : "APPMANAGE_XML", 'value' : "/var/tmp/${level}/appmanage.xml"}
        ]

}, 'inline.json')


class TestFdeployLoader(unittest2.TestCase):

    options = {'nexusURL': 'http://sefsmvn.ute.fedex.com:9999'}
    REQUIRED_RTVS = ['F_HOME','G_HOME']

    def setUp(self):
        self.options = {'nexusURL': 'http://sefsmvn.ute.fedex.com:9999'}
        pass

    def test_level2code(self):
        self.assertEquals('u',level2code('L1'))
        self.assertEquals('?',level2code('LB'))

    def test_read_descriptor_not_exist(self):
        fdl = fdeploy.fdeployLoader(self.options)
        with self.assertRaises(Exception):
            fdl.readDescriptors(['../../test/resources/does-not-exist.json'])

    def test_cups_types(self):
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(['../../test/resources/pcf-config/pcf-cups-config.json'])


    def test_read_descriptor_filter_id(self):
        self.options['id'] = 'bw'
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(['../../test/resources/FXE_fdeploy/*.json'])
        self.assertEquals(fdeploy.TestFdeployLoader.REST_COUNT, len(fdl.components))
        bw = len(fdl.components)
        self.options['id'] = None
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(['../../test/resources/FXE_fdeploy/*.json'])
        self.assertEquals(fdeploy.TestFdeployLoader.JAVA_COUNT, len(fdl.components))
        neg = len(fdl.components) - bw
        self.options['id'] = '!bw'
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(['../../test/resources/FXE_fdeploy/*.json'])
        self.assertEquals(neg, len(fdl.components))

    def test_read_descriptor_filter_type(self):
        self.options['id'] = '#java'
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(['../../test/resources/FXE_fdeploy/*.json'])
        self.assertEquals(6, len(fdl.components))
        bw = len(fdl.components)
        self.options['id'] = None
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(['../../test/resources/FXE_fdeploy/*.json'])
        self.assertEquals(fdeploy.TestFdeployLoader.JAVA_COUNT, len(fdl.components))
        neg = len(fdl.components) - bw
        self.options['id'] = '!#java'
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(['../../test/resources/FXE_fdeploy/*.json'])
        self.assertEquals(neg, len(fdl.components))

    def test_read_descriptor(self):
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(['../../test/resources/java-cache-mixin.json'])
        self.assertEquals(1, len(fdl.components))
        comp = fdl.components[0]
        self.assertEquals('sefs-fxs-java-probes', comp.id)
        self.assertEquals(2, len(comp.rtv))
        self.assertEquals("F_HOME", comp.rtv[1]["name"])
        self.assertEquals("/opt/home/fbs", comp.rtv[1]["value"])

    def test_get_env_vars(self):
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(['../../test/resources/java-cache-mixin.json'])
        self.assertEquals(1, len(fdl.components))
        comp = fdl.components[0]
        _map = {}
        env,envvar_list = comp.get_env_vars(self.options,'L1',[])
        self.assertIsNotNone(env)
        self.assertEquals('/opt/delta/DL2180/Lihue', env['F_HOME'])
        self.assertEquals('/opt/home/gbs', env['G_HOME'])
        env,envvar_list = comp.get_env_vars(self.options, 'L2',[])
        self.assertEquals('/opt/home/fbs', env['F_HOME'])
        self.assertEquals('/opt/home/gbs', env['G_HOME'])
        self.assertEquals('probe-client', env['ARTIFACTID'])
        self.assertEquals('com.fedex.sefs.dashboard', env['GROUPID'])

    def test_get_env_vars_exterenal_overwrite(self):
        self.options['rtv'] = ["JAVA_HOME=/opt/java/hotspot/9/latest"]
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(['../../test/resources/java-cache-mixin.json'])
        self.assertEquals(1, len(fdl.components))
        comp = fdl.components[0]
        _map = {}
        env,envvar_list = comp.get_env_vars( self.options, 'L1',REQUIRED_RTVS)
        self.assertIsNotNone(env)
        self.assertEquals('/opt/java/hotspot/9/latest', env['JAVA_HOME'])

        # format error rtv specification
        self.options['rtv'] = ["JAVA_HOME"]
        fdl = fdeploy.fdeployLoader(self.options)
        with self.assertRaises(IndexError):
            comp.get_env_vars(self.options, 'L1',[])

    def test_get_env_vars_missing_required_RTV(self):
        self.options['rtv'] = ["JAVA_HOME=/opt/java/hotspot/9/latest"]
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(['../../test/resources/java-cache-mixin-missing.json'])
        self.assertEquals(1, len(fdl.components))
        comp = fdl.components[0]
        _map = {}
        env,envvar_list = comp.get_env_vars( self.options, 'L1',REQUIRED_RTVS)
        self.assertIsNotNone(env)
        self.assertEquals('/opt/java/hotspot/9/latest', env['JAVA_HOME'])

        # format error rtv specification
        self.options['rtv'] = ["JAVA_HOME"]
        fdl = fdeploy.fdeployLoader(self.options)
        with self.assertRaises(IndexError):
            comp.get_env_vars(self.options, 'L1',[])

    def test_read_FXE(self):
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(
            ['../../test/resources/FXE_fdeploy/fxe-be-sefsShipment_ClearancePU.json'])
        self.assertEquals(1, len(fdl.components))
        #print "\n\t\t%s\n" % (fdl.components)
        _map = {}
        env, envvar_list = fdl.components[0].get_env_vars(self.options, 'L1',REQUIRED_RTVS)
        self.assertIsNotNone(env)
        self.assertEquals('urh00606.FXE_SEFS_SHIPMENT_CLEARANCE_1',
                          env['sefs_suShipment_AS_MEMBER_NAME'])

    def test_level_replacement_in_rtv(self):
        os.environ['level']='L1'

        loader = fdeploy.fdeployLoader(
            self.options, importComponents=[test_component])
        self.assertEquals(1, len(loader.components))
        comp = loader.components[0]
        self.assertIsNotNone(comp.rtv[0]['name'])
        rtv_map,envvar_list = comp.get_env_vars(self.options,'L1',[])
        self.assertIsNotNone(rtv_map['APPMANAGE_XML'])
        self.assertEquals("/var/tmp/L1/appmanage.xml", rtv_map['APPMANAGE_XML'])
        self.assertEquals("40313", rtv_map['JMX_PORT'])

        rtv_map,envvar_list = comp.get_env_vars(self.options,'L2',[])
        self.assertIsNotNone(rtv_map['APPMANAGE_XML'])
        self.assertEquals("/var/tmp/L1/appmanage.xml", rtv_map['APPMANAGE_XML'])
        self.assertEquals("ABCDEF", rtv_map['JMX_PORT'])

    def test_get_env_vars_2in1(self):
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(
            ['../../test/resources/java-cache-mixin-multiple-comps-1file.json'])
        self.assertEquals(2, len(fdl.components))
        _map = {}
        # take second component
        env,envvar_list = fdl.components[1].get_env_vars(self.options, 'L1',REQUIRED_RTVS)
        self.assertIsNotNone(env)
        with self.assertRaises(KeyError):
            self.assertEquals('/opt/delta/DL2180/Lihue', env['F_HOME'])
        self.assertEquals('/opt/linux/level1_z', env['Z_HOME'])
        env,envvar_list = fdl.components[1].get_env_vars(self.options, 'L2',REQUIRED_RTVS)
        self.assertEquals('/opt/linux/src/global_z', env['Z_HOME'])
        self.assertEquals('probe-client', env['ARTIFACTID'])
        self.assertEquals('com.fedex.sefs.dashboard', env['GROUPID'])

    def test_read_descriptor_2in1(self):
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(
            ['../../test/resources/java-cache-mixin-multiple-comps-1file.json'])
        self.assertEquals(2, len(fdl.components))
        # validating structure
        comp = fdl.components[0]
        self.assertEquals('sefs-fxs-java-probes', comp.id)
        self.assertEquals(2, len(comp.rtv))
        self.assertEquals("F_HOME", comp.rtv[1]["name"])
        self.assertEquals("/opt/home/fbs", comp.rtv[1]["value"])
        comp = fdl.components[1]
        self.assertEquals('sefs-fxs-java-probes2', comp.id)
        self.assertEquals(2, len(comp.rtv))
        self.assertEquals("Z_HOME", comp.rtv[1]["name"])
        self.assertEquals("/opt/linux/src/global_z", comp.rtv[1]["value"])
        # first level(0) is
        self.assertEquals("/opt/linux/level1_z",
                          comp.levels[0]['rtv'][0]["value"])

    def test_find_level(self):
        loader = fdeploy.fdeployLoader(
            self.options, importComponents=[test_component])
        self.assertEquals(1, len(loader.components))
        self.assertEquals(3, len(loader.components[0].levels))
        self.assertIsNotNone(loader.find_level(loader.components[0], 'L1'))
        self.assertIsNone(loader.find_level(loader.components[0], 'ZERO'))

    def test_find_targets(self):
        loader = fdeploy.fdeployLoader(
            self.options, importComponents=[test_component])
        self.assertEquals(1, len(loader.components))
        fdeploy.LOGGER.debug(loader.components[0].__dict__.keys())
        self.assertTrue('levels' in loader.components[0].__dict__.keys())
        comp = loader.components[0]
        self.assertEquals(3, len(comp.levels))
        fdeploy.LOGGER.debug(comp.levels[0]['level'])
        self.assertEquals('L1', comp.levels[0]['level'])
        self.assertEquals(5, len(comp.levels[0]['targets']))
        loader.find_targets_in_level(test_component, level='L1')
        self.assertEquals(
            5, len(loader.find_targets_in_level(test_component, 'L1')))
        self.assertEquals(
            10, len(loader.find_targets_in_level(test_component, 'L2')))
        self.assertEquals(
            1, len(loader.find_targets_in_level(test_component, 'L3')))

    def test_split(self):
        a = ['a', 'b', 'c', 'd', 'e']
        aa = split(a, 2)
        self.assertEquals(3, len(aa))
        self.assertEquals('e', aa[2][0])

    def test_get_generator_class(self):
        self.options['action'] = 'properties'
        loader = fdeploy.fdeployLoader(
            self.options, importComponents=[test_component])
        test_component.type = 'java'
        clz,name=test_component.get_generator_class(self.options,".")
        self.assertEquals("javaGenerator", name)
        test_component.type = 'bla'
        with self.assertRaises(AttributeError):
            clz,name=loader.get_generator_class(test_component)

    def test_find_targets_by_groupsize(self):
        loader = fdeploy.fdeployLoader(
            self.options, importComponents=[test_component])
        groups = loader.find_targets_in_level(
            test_component, level='L1', groupSize=2)
        self.assertEquals(
            5, len(loader.find_targets_in_level(test_component, 'L1')))
        self.assertEquals(
            10, len(loader.find_targets_in_level(test_component, 'L2')))
        self.assertEquals(
            1, len(loader.find_targets_in_level(test_component, 'L3')))

    def test_get_targets_all(self):
        self.assertEquals(3, len(test_component.levels))
        loader = fdeploy.fdeployLoader(
            self.options, importComponents=[test_component])
        base = testGenerator(test_component, {'action': 'status'})
        level = loader.find_level(test_component, 'L1')
        __targets = fdeploy.flatten_level_targets(level['targets'])
        self.assertEquals(5, len(__targets))
        with self.assertRaises(Exception):
            loader.find_targets_in_level(test_component, 'L11')

    def test_get_target_group(self):
        loader = fdeploy.fdeployLoader(
            self.options, importComponents=[test_component])
        base = testGenerator(test_component, {'action': 'status'})
        level = loader.find_level(test_component, 'L1')
        __targets = fdeploy.flatten_level_targets(level['targets'])
        self.assertEquals(5, len(__targets))
        __grouped = loader.find_targets_in_level(test_component, 'L1', 3)
        self.assertEquals(3, len(__grouped))
        self.assertEquals('a@fedex.com', __grouped[0])
        with self.assertRaises(KeyError):
            __grouped = loader.find_targets_in_level(
                test_component, 'L1', 3, 2)
        __grouped = loader.find_targets_in_level(test_component, 'L1', 3, 1)
        self.assertEquals(2, len(__grouped))
        self.assertEquals('d@fedex.com', __grouped[0])
        __grouped = loader.find_targets_in_level(test_component, 'L1', 3, -1)
        self.assertEquals(3, len(__grouped))
        self.assertEquals('b@fedex.com', __grouped[1])


if __name__ == '__main__':
    unittest.main()
