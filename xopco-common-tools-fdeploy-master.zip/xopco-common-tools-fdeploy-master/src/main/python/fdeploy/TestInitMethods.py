# -*- coding: utf-8 -*-
import unittest2
import fdeploy.deployer
from fdeploy.nexusVersionResolver import absolute_repository_path
from fdeploy import resolve_filter
import os
from fdeploy import Options



class TestInitMethods(unittest2.TestCase):

    source_file =  '''   # Generating the current properties for this version
   cat <<EOF > "${_target_path}/${_archive_version}.properties"
#!/bin/bash
# Generated property file for application.
EOF
'''

    filter = {'_target_path' : 'mypath', '_archive_version' : '2.503'}


    maxDiff = None

    @classmethod
    def setUpClass(clz):
        pass

    def test_filtering_script(self):
        result = self.source_file
        try:
            result.index('$')
        except:
            self.assertTrue(False)
        result = resolve_filter(result, self.filter)
        try:
            result.index('$')
            self.assertTrue(False)
        except:
            pass
        self.assertEquals(72,result.index('mypath'))
        self.assertEquals(79,result.index('2.503'))

    def test_file_filitering(self):
        asstring = fdeploy.platform.load_file('../../test/resources/bw5/FXFShipFeed_template_l2.xml')
        result = resolve_filter(asstring,{ 'maxHeapSize' : '4096', '_archive_version' : '1.0-SNAPSHOT',
        'JMS_conn_External_Reject_JNDIPassword' : 'secret99',
        'JMS_conn_External_Reject_JNDIUser' : 'secret99', 'JMS_conn_External_Reject_QueueConnectionFactory' : 'reject',
        'JMS_conn_External_Reject_Queue' : 'value',
        '_target_path' : 'PATHTOTARGET', 'maxLogFileSize' : '20000', 'maxLogFileCount' : '5', 'threadCount' : '10'})
        self.assertEquals(type(result), str)
        ii=1
        for i in result.split('\n'):
            self.assertEquals(False, "${" in i, 'line %s : %s' % (ii, i))
            ii+=1
        pass

    def test_load_rc(self):
        options = Options(defaults={})
        apath = os.path.abspath('../../test/resources/')
        path = absolute_repository_path('../../test/resources/')
        self.assertTrue(os.path.exists(path), "path=%s" % (path))
        self.assertEqual(apath, path)
        with self.assertRaises(Exception):
            fdeploy.load_rc('../../test/resources/.fdeployrc',options)
        fdeploy.load_rc('../../test/resources/FXE_fdeploy/.fdeployrc',options)
        self.assertFalse('nexusURL' in options.defaults)
        self.assertFalse('snapshotsRepo' in options.defaults)
        self.assertFalse('releasesRepo' in options.defaults) 
        #self.assertEqual('file://%s/local' % (apath),options.defaults['nexusURL'])

if __name__ == '__main__':
    unittest.main()
