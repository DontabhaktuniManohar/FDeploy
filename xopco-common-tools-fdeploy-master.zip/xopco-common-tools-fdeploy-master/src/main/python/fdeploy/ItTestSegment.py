import unittest2
import fdeploy
import cloudbees
import os
import analytics

# Google: analytics.write_key = 'UA-125042736-3'
analytics.write_key = 'UA-125042736-3'
analytics.client = 'analytics.GA'



class ItTestSegment(unittest2.TestCase):

    def test_post_product(self):
        gav=fdeploy.gavClass({'gav' : 'com.fedex.test:prod-register:3.8.1:jar', 'saveArchiveName' : 'prod-register.zip' })
        analytics.upload(gav)



if __name__ == '__main__':
    unittest.main()
