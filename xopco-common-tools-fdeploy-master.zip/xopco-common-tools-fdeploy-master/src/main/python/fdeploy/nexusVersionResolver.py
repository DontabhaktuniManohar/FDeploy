# -*- coding: utf-8 -*-
import json
import os
import pprint
import sys
import time
import re
import traceback
import requests  # http://docs.python-requests.org/en/latest/
import requests.packages.urllib3
import xmltodict
import fdeploy
import tempfile
import itertools
import analytics
from requests_file import FileAdapter
from fdeploy.segment import track_download
import xml.etree.ElementTree as ET

#//https://nexus.prod.cloud.fedex.com:8443/nexus/repository/7207-FXF-SPI/devlib_SPI/SEFS/dom_to_java/7.6.3/dom_to_java-7.6.3.jar.sha1
NEXUSv3='https://nexus.prod.cloud.fedex.com:8443'
NEXUSv3EndPoint="nexus/repository/SEFS-6270"
NEXUSv2='http://sefsmvn.ute.fedex.com:9999'
NEXUSv2EndPoint='nexus/service/local/repo_groups/public/content'

NEXUS_MAP = { NEXUSv3 : NEXUSv3EndPoint,  NEXUSv2 : NEXUSv2EndPoint }


def _needs_manifest_resolving(action):
    return action in fdeploy.ACTIONS_WITH_MANIFEST_HANDLING

def uniq(sequence):
    return (x[0] for x in itertools.groupby(sequence))

def semantic_compare(v1,v2):
    fdeploy.log()
    l1=v1.split('.')
    l2=v2.split('.')
    if len(l1) < len(l2):
        l3 = l1
        l1 = l2
        l2 = l3
    i=0
    match = False
    for digit in l1:
        try:
            a="%s" %(l2[i])
        except (IndexError):
            return v2
        if l2[i] > digit:
            if match:
                return v2
            return v1
        elif l2[i] < digit:
            return v1
        elif l2[i] == digit:
            match = True
        i+=1
    return v1

def resolve_reponame(u, snapshots=False):
    if NEXUSv3 == u and snapshots == True:
        return 'nexus/repository/SEFS-6270'
    if NEXUSv2 == u and snapshots == True:
        #return 'nexus/service/local/repositories/snapshots/content'
        return 'nexus/service/local/repo_groups/public/content'
    elif u in NEXUS_MAP:
        return NEXUS_MAP[u]
    return NEXUSv2EndPoint


def absolute_repository_path(path, asURL=False):
    if path.startswith('.') or path.startswith('/') or path.startswith('file://'):
        protocol = 'file://' if asURL else ''
        path = re.sub( r'file://','', path)
        _path = os.path.abspath(path)
        return "%s%s" % (protocol, _path)
    else:
        return path

class nexusVersionResolver:

    archiveDir = 'archives'
    useCache = False
    nexusRepo = 'releases'
    releasesRepo = 'releases'
    snapshotsRepo = 'snapshots'
    nexusURL = 'http://sefsmvn.ute.fedex.com:9999'
    nexusOriginalArchiveNames = {}
    nexusResolvedNames = {}
    nexusUrlPulls = {}
    tmpDir = None
    echo = os.getenv('FDEBUG')
    __manifest_resolver__ = None

    def __init__(self, options, _useCache=True, base_dir="tmp", manifestResolver=None):
        self.__manifest_resolver__ = manifestResolver

        self.useCache = _useCache
        self.tmpDir = base_dir + "/" + self.archiveDir
        self.applyOptions(options)

    def applyOptions(self, options):
        if self.echo:
            fdeploy.LOGGER.debug("applying configuration options %s." % (options))
        if 'silent' in options and not self.echo:
            self.echo = None
        if 'nexusURL' in options:
             if self.echo:
                 fdeploy.LOGGER.info("override nexusURL with defaults has been deprecated")
        if 'snapshotsRepo' in options:
            self.snapshotsRepo = options['snapshotsRepo']
            if self.echo:
                fdeploy.LOGGER.info("override snapshotsRepo with defaults %s" % (options['snapshotsRepo']))
        if 'releasesRepo' in options:
            self.releasesRepo = options['releasesRepo']
            self.nexusRepo = self.releasesRepo
            fdeploy.LOGGER.debug("override releasesRepo with defaults %s" % (options['releasesRepo']))

    def set_manifest_resolver(self, manifestResolver):
        self.__manifest_resolver__ = manifestResolver

    def resolveGavs(self, comp, downloadRequired=False, testing=False, manifestRequired=False):
        found = None
        if self.echo:
            fdeploy.LOGGER.debug("\t %s", comp.dict)
        for gav in comp.contents:
            if comp.isNexusArtifact(gav):
                fdeploy.LOGGER.debug("resolving %s:%s, downloading required %s",gav.groupId, gav.artifactId, downloadRequired)
                fdeploy.LOGGER.debug("resolving %s:%s, manifest resolving required %s",gav.groupId, gav.artifactId, manifestRequired)
                if manifestRequired == True:
                    gav.version = self.get_artifact_version_from_manifest(gav.artifactId)
                if downloadRequired == True and testing == False:
                    fdeploy.LOGGER.debug("resolving : %s" % (gav) )
                    if self.resolve(gav) is None:
                        fdeploy.trace("gav %s:%s is not found" % (gav.groupId, gav.artifactId))
                        return None
                    else:
                        fdeploy.LOGGER.debug("resolved : %s" % (gav) )
                if downloadRequired == True:
                    self.download(gav)
                found = gav
        return found

    def get_artifact_version_from_manifest(self,artifactId):
        # lookup the version in the manifest
        manifest = None
        try:
            manifest = self.__manifest_resolver__.__manifest__
        except:
            pass
        fdeploy.LOGGER.debug("\n\n get_version:%s\n" % (artifactId))
        if (manifest is None or self.__manifest_resolver__.isLoaded == False):
            raise Exception("FATAL : manifest not found for %s [manifest=%s,loaded=%s]!" % (artifactId, manifest,self.__manifest_resolver__.isLoaded))
        if (manifest and manifest.has_option('RELEASE_MANIFEST', artifactId)):
            # found alternate version
            fdeploy.LOGGER.debug("artifact=%s, manifest_version=%s", artifactId, manifest.get('RELEASE_MANIFEST', artifactId))
            return manifest.get('RELEASE_MANIFEST', artifactId)
        else:
            if manifest.has_section('RELEASE_MANIFEST'):
                fdeploy.warn("WARNING : Unresolved version for %s thus skipping.\nWARNING : Please check your RELEASE_MANIFEST.MF, currently contains:" % (artifactId))
                for item in manifest.items('RELEASE_MANIFEST'):
                    fdeploy.LOGGER.debug("\t %s looking for %s", item, artifactId)
                return None
            else:
                fdeploy.LOGGER.debug("\nFATAL : No Release Manifest section in RELEASE_MANIFEST.MF for %s.\n",artifactId)
                return None
        return None


    ''' Main Resolving Interface Method '''
    def resolve(self, gav, org_majorMinorVersion=None):
        groupId = gav.groupId
        majorMinorVersion = None
        if not org_majorMinorVersion:
            if not gav.version:
                gav = self.resolve_from_manifest(gav)
            else:
                fdeploy.LOGGER.debug("resolve:\thardcoded version %s ", gav)
        else:
            gav = self.what_is_the_next_version_base(gav, org_majorMinorVersion)
        return gav

    def does_version_exist_in_nexus(self, gav, version):
        return self.__resolve_next_version_base(gav,version,'version_exists')
    def what_is_the_next_version_base(self, gav, majorMinorVersion):
        return self.__resolve_next_version_base(gav,majorMinorVersion)
    def what_is_the_closest_base(self, gav, majorMinorVersion):
        return self.__resolve_next_version_base(gav,majorMinorVersion,'find_closest_version')

    def is_calculation(self, found_match, method, has_no_releases, majorMinorVersion):
        if method == 'find_next_base_for_calculation':
            if found_match is None and '-SNAPSHOT' in org_gav_version:
                found_match = gav.has_no_releases
            elif found_match is None:
                found_match = majorMinorVersion
        return found_match

    def __resolve_next_version_base(self, gav, majorMinorVersion,method='find_next_base_for_calculation'):
        found_match = None
        if gav.version:
            gav.buildId = gav.version
            fdeploy.LOGGER.warn(" ! version hardcoded supplied for " + gav.artifactId + " --> " + gav.version )
        else:
            gav.version = org_gav_version = str(majorMinorVersion).replace('*','')
            defaultrepo = self.nexusRepo
            org_gav_version=gav.version
            nexusMetadataUrls = self.get_download_url_metadata(gav,defaultrepo,self.nexusURL)
            fdeploy.LOGGER.debug("metadata urls: %s" % (nexusMetadataUrls))
            resolved_req=[]
            resolved_match = None
            for nexusMetadataUrl in nexusMetadataUrls:
                fdeploy.LOGGER.debug("\tretrieving : %s, repo=%s, %s=" ,nexusMetadataUrl, defaultrepo, majorMinorVersion)
                ret = self.getWithRetry(nexusMetadataUrl,gav)
                if ret.ok in [200, 201] or ret.ok == True:
                    tree = ET.fromstring(ret.content)
                    found_match = getattr(self, method)( tree.findall('.//version'), majorMinorVersion, gav)
                    fdeploy.LOGGER.info("%s: found_match=%s has_no_releases=%s (org=%s)", method, found_match, gav.has_no_releases, org_gav_version)
                    found_match = self.is_calculation(found_match,gav.has_no_releases, method,majorMinorVersion)
                    fdeploy.LOGGER.info("resolved requested version %s to %s - %s [match=%s]" %(org_gav_version, gav.version, gav.has_no_releases, found_match))
                    if found_match:
                        gav.repo_url = nexusMetadataUrl
                        if resolved_match:
                            # compare previous found match resolved with current and which is greater
                            pass
                        resolved_match = [nexusMetadataUrl, found_match]
                elif ret.ok in [404]:
                    found_match = None
                    continue
                else:
                    if 'find_next_base_for_calculation' not in method:
                        fdeploy.LOGGER.error("%s: failed to load metadata %s", method, nexusMetadataUrl)
                    gav.version = majorMinorVersion
                    continue
            fdeploy.LOGGER.debug("resolved_req: %s", resolved_req)
            found_match = self.is_calculation(found_match,gav.has_no_releases, method,majorMinorVersion)
            gav.version = gav.buildId = found_match
        return gav

    def version_exists(self,metadata, version_query,gav):
        return self._traverse_versions(metadata, version_query,gav, True, False)
    def find_closest_version(self,metadata, version_query,gav):
        return self._traverse_versions(metadata, version_query,gav, True, False)
    def find_next_base_for_calculation(self,metadata, version_query,gav):
        return self._traverse_versions(metadata, version_query,gav, False, False)
    def _traverse_versions(self,metadata, version_query,gav, exact_match_only=False, base_calculation=True):
        only_one_version = None
        found_match = None
        found_exact_match = None
        snapshot_found = None
        for data in metadata:
            if isinstance(data,basestring):
                row = data
            else:
                row = data.text
            fdeploy.LOGGER.debug("%-15s majmin=%-3s snapfound=%-7s found_match=%s (exact_match_only=%s, use_for_base=%s)",row, version_query, snapshot_found, found_match, exact_match_only, base_calculation)
            if row == version_query:
                found_match = found_exact_match = row
                if '-SNAPSHOT' in row:
                    snapshot_found= row
                return row
            elif row.startswith(version_query):
                fdeploy.LOGGER.debug("match %s majmin=%s snapfound=%s found_match=%s", row, version_query, snapshot_found, found_match)
                if row.endswith('-SNAPSHOT'):
                    if snapshot_found is None and found_match is None:
                        snapshot_found = row
                        if exact_match_only == False:
                            found_match = re.sub( r'-SNAPSHOT', '', row)
                else:
                    found_match = row
                    #if exact_match_only and row == version_query:
                    found_exact_match = row

        fdeploy.LOGGER.debug("found_match=%s snapshot_found=%s exact=%s\n", found_match, snapshot_found, found_exact_match )
        if not found_match and not found_exact_match and not snapshot_found:
            # when no metadata was found at all default to majmin.0
            if exact_match_only ==False and base_calculation ==False:
                version_query = re.sub( r'-SNAPSHOT', '', version_query)
                return self.get_base_number(version_query,True)[0]
            return None
        if not found_match:
            # when no metadata was found at all default to majmin.0
            gav.has_no_releases = "%s" % (version_query)
        elif not found_exact_match and found_match:
            gav.has_no_releases = found_match
        elif not found_match and not found_exact_match and not snapshot_found:
            # when no metadata was found at all default to majmin.0
            found_match = None
        elif not found_match and not found_exact_match and snapshot_found:
            gav.has_no_releases = "%s.0" % (version_query)

        if only_one_version and found_match:
            fdeploy.LOGGER.warn( ">>>> only one revision available: %s" % (found_match))
        return found_match


    def resolve_from_manifest(self, gav, nexus_compliance=False):
        version_argument = gav.version
        if gav.version is None or nexus_compliance == True:
            fdeploy.LOGGER.debug('reading from manifest %s' % (gav))
            gav.version = self.get_artifact_version_from_manifest(gav.artifactId)
            if gav.version is None:
                raise Exception('No artifactId version for %s' % (gav.artifactId))
            # validate against meta data
            defaultrepo = self.nexusRepo
            # setting the repository based on the snapshot notation at the end
            if gav.version and gav.version.endswith('-SNAPSHOT'):
                self.nexusRepo = self.snapshotsRepo
                defaultrepo = self.snapshotsRepo
            if gav.repoName:
                self.nexusRepo = gav.repoName
                defaultrepo = gav.repoName
            fdeploy.LOGGER.debug("nvr: %s %s <<<<<<<<<<<<<<<<-- " % (defaultrepo, gav.version))
            org_gav_version=gav.version
            if gav.version:
                gav.version = str(gav.version).replace('*', '')
            # metadata for calculation
            found_match = None
            nexusMetadataUrls = self.get_download_url_metadata(gav, defaultrepo, self.nexusURL)
            for nexusMetadataUrl in nexusMetadataUrls:
                # if there is no majorMinor provided it means we calculate it
                # based on the version hardcoded or from release manifest.
                fdeploy.LOGGER.debug("\tretrieving : %s", nexusMetadataUrl)
                ret = self.getWithRetry(nexusMetadataUrl,gav)
                if ret.ok in [404]:
                    continue
                elif ret.ok in [200, 201] or ret.ok == True:
                    tree = ET.fromstring(ret.content)
                    if (tree.findall('.//version')):
                        found_match = self.version_exists( tree.findall('.//version'),gav.version, gav)
                        if (found_match is not None):
                            gav.version = found_match = gav.buildId =  found_match
                            fdeploy.LOGGER.info("resolved version from %s to %s - has_no_releases=%s", org_gav_version, gav.version, gav.has_no_releases)
                            if nexus_compliance == True and gav.version != version_argument:
                                found_match = None
                    else:
                        found_match = None
                else:
                    fdeploy.LOGGER.error("failed to load metadata %s", nexusMetadataUrl)
                    found_match = None
            if found_match is None:
                gav.version = None
            elif nexus_compliance == True and gav.version != version_argument:
                fdeploy.LOGGER.error('Strict Compliance Enforced %s was not found in Nexus (found_match=%s)' % (version_argument, found_match))
                gav.version = None
            fdeploy.LOGGER.info("resolved '%s' version from %s to %s - has_no_releases=%s" % (gav.artifactId,org_gav_version, gav.version, gav.has_no_releases))
        else:
            gav.buildId = gav.version
            fdeploy.LOGGER.warn(" ! version hardcoded supplied for " + gav.artifactId + " --> " + gav.version )
        return gav

    def get_base_number(self,versionNumber, majorMinor=True):
        # strip identifiers
        if "-SNAPSHOT" in versionNumber:
            versionNumber = re.sub( r'-SNAPSHOT$', '', versionNumber)
            wasSnapshot = True
        if re.match( r'^R-', versionNumber):
            versionNumber = re.sub(r'^R-','', versionNumber)
        # count all digits from left
        # 7.0.1.MASTER-SNAPSHOT = would return 7.0
        # 2.1.1.5-SNAPSHOT would return 2.1.1
        i=[]
        rest=[]
        for item in versionNumber.split('.'):
            try:
                if len(rest) == 0:
                    n = int(item)
                    i.append(item)
                else:
                    rest.append(item)
            except:
                rest.append(item)
        if len(i) == 0:
            # exampel ABD.2 should return ABD.2
            return versionNumber, rest
        if majorMinor == True:
            if len(i) < 2:
                return "%s.%s" % (i[0], 0), rest
            if len(i) <= 3 and majorMinor == True:
                return "%s.%s" % (i[0], i[1]), rest
        else:
            if len(i) < 2:
                return "%s.%s.%s" % (i[0], 0, 0), rest
            if len(i) <= 3:
                return "%s.%s.%s" % (i[0], i[1], i[2] if len(i) == 3 else 0), rest
        fmt = ""
        if majorMinor == True: #and  == False:
            ii = len(i)-1
        else:
            ii = len(i)
        fdeploy.LOGGER.debug("requested version=%s (majmin=%s), after processing=%s %s %s %s", versionNumber, majorMinor, rest, i, ii, majorMinor)
        for item in range(0,ii,1):
            if fmt == "":
                fmt = i[item]
            else:
                fmt = fmt + "." + i[item]
        return fmt , ".".join(rest)

    def _storeDownloadInfo(self, _nexusURL, gav, archiveFileName, ret=None):
        # Save a cache of the URL to local file name so we don't have to repull from nexus over and over
        self.nexusResolvedNames[gav.saveArchiveName] = gav.version
        self.nexusUrlPulls[_nexusURL] = archiveFileName
        gav.archiveFileName = archiveFileName
        # Save the original name of the archive so we can fdeploy.LOGGER.debug(a list of what we pulled when done
        if ret is not None:
            nexusOriginalArchiveFilename = ret.url[ret.url.rfind("/") + 1:]
            self.nexusOriginalArchiveNames[_nexusURL] = nexusOriginalArchiveFilename

    def download(self, gav):
        if gav.version is None:
            print("╔═╗╦═╗╔╦╗╦╔═╗╔═╗╔═╗╔═╗╔╦╗  ╔╗╔╔═╗╔╦╗  ╔═╗╔═╗╦ ╦╔╗╔╔╦╗")
            print("╠═╣╠╦╝ ║ ║║  ╠╣ ╠═╣║   ║   ║║║║ ║ ║   ╠╣ ║ ║║ ║║║║ ║║")
            print("╩ ╩╩╚═ ╩ ╩╚═╝╚  ╩ ╩╚═╝ ╩   ╝╚╝╚═╝ ╩   ╚  ╚═╝╚═╝╝╚╝═╩╝")
            raise Exception("no artifact found for %s" % (gav))

        fdeploy.LOGGER.info( " > downloading: " + str(gav) )
        nexusVersion = gav.version
        if nexusVersion is None:
            raise
        tmpDir = self._getTempDir()
        self.nexusRepo = self.releasesRepo
        if nexusVersion.endswith('SNAPSHOT'):
            self.nexusRepo = self.snapshotsRepo
        if gav.repoName:
            self.nexusRepo = gav.repoName
            #
        _nexusURLs = self.get_download_url_artifact(gav, self.nexusRepo, self.nexusURL)
        archiveFileName = os.path.abspath(os.path.normpath(
            os.path.join(tmpDir, gav.saveArchiveName)))
        fdeploy.LOGGER.debug( " < archive storing: %s ", archiveFileName)
        gav.archiveFileName = archiveFileName
        # Check if we've already pulled this exact Nexus URL and saved as this exact archiveFilename, if so just use that
        for _nexusURL in _nexusURLs:
            fdeploy.LOGGER.debug( " < url = %s" , _nexusURL )
            if _nexusURL in self.nexusUrlPulls and self.nexusUrlPulls[_nexusURL] == archiveFileName:
                fdeploy.LOGGER.debug( " > nexus: using existing archive from dynamic cache: %s" + archiveFileName )
                # update dictionary for each component that shows all archives attached to it
                nexusOriginalArchiveFilename = self.nexusOriginalArchiveNames[_nexusURL]
                break
            elif self.useCache == True and os.path.isfile(archiveFileName) == True:
                fdeploy.LOGGER.debug( " > nexus: using existing archive from permanent cache: %s" + archiveFileName )
                self._storeDownloadInfo(_nexusURL, gav, archiveFileName)
                break
            else:
                fdeploy.LOGGER.debug( " < connecting: %s", _nexusURL )
                ret = self.getWithRetry(_nexusURL,gav)
                if ret.ok:
                    #spinner = itertools.cycle(['◢','◣','◤','◥'])
                    spinner = itertools.cycle(['▁', '▂', '▃','▄','▅' ,'▆' ,'▇', '█' ,'▇', '▆', '▅', '▄', '▃', '▁'])
                    archiveFile = None
                    try:
                        fdeploy.LOGGER.debug( " < connected %s", ret.url )
                        fdeploy.LOGGER.debug( " > storing %s", archiveFileName )
                        i=0
                        with open(archiveFileName, 'wb+') as archiveFile:
                            for block in ret.iter_content(1024):
                                if block:
                                    if sys.stdin.isatty():
                                        sys.stdout.write(spinner.next())  # write the next character
                                        sys.stdout.write('\b')
                                        sys.stdout.flush()                # flush stdout buffer (actual character display)
                                    archiveFile.write(block)
                                    i+=1
                                else:
                                    break

                        # Save a cache of the URL to local file name so we don't have to repull from nexus over and over
                        self._storeDownloadInfo(
                            _nexusURL, gav, archiveFileName, ret)
                    finally:
                        if archiveFile != None:
                            archiveFile.close()
                    break
                else:
                    fdeploy.LOGGER.error(
                        "\nERROR - failed to obtain archive from %s error[%s]",_nexusURL,ret)
        fdeploy.LOGGER.debug( " > after download: " + str(gav) )
        return gav

    def _getTempDir(self):
        if self.tmpDir == None:
            # the WORKSPACE variable can be set externally normally
            # this is the CloudBees job workspace, thus relying on cleanup
            # and management thru the job rather than silver control.
            if os.environ.get('WORKSPACE'):
                self.tmpDir = os.environ.get('WORKSPACE') + '/tmp'
                fdeploy.mkdir_p(self.tmpDir)
            elif self.useCache == True:
                self.tmpDir = './tmp'
                fdeploy.mkdir_p(self.tmpDir)
            else:
                self.tmpDir = tempfile.mkdtemp()
            if self.tmpDir == None or self.tmpDir.strip() == "":
                fdeploy.fail("ERROR - Unable to create a valid tmpdir to use.")
            if self.echo:
                fdeploy.LOGGER.debug(" = tmpdir: %s", self.tmpDir)
            try:
                # sometimes get failures on windows
                os.chmod(self.tmpDir, 0777)
            except:
                pass  # nada
        elif os.path.isdir(self.tmpDir) == False:
            # create the structure
            fdeploy.mkdir_p(self.tmpDir)
        return self.tmpDir

    # retry logic when confronted with a connection exception like
    # requests.exceptions.ConnectionError: HTTPConnectionPool(host='internet.proxy.fedex.com', port=3128): Max retries exceeded with url:
    def getWithRetry(self, _nexusURL, gav, retry=3):
        ret = None
        # retry logic when confronted with a connection exception like
        # requests.exceptions.ConnectionError: HTTPConnectionPool(host='internet.proxy.fedex.com', port=3128): Max retries exceeded with url:
        while (retry > 0 and ret is None):
            try:
                if retry != 3:
                    fdeploy.warn( "CONNECT: retries left #" + str(retry) )
                s = requests.Session()
                if 'file://' in _nexusURL:
                    s.mount('file://', FileAdapter())
                fdeploy.LOGGER.debug("downloading %s looking for version %s", _nexusURL, gav.version)
                ret = s.get(_nexusURL, stream=True, proxies=fdeploy.FDX_PROXIES, headers={'Cache-Control': 'no-cache'})
                track_download(gav)
                if not ret.ok and self.echo:
                    fdeploy.LOGGER.debug(str(ret.content))
                break
            except IOError as e:
                fdeploy.LOGGER.error( "I/O error(%s): %s: '%s'",e.errno, e.strerror, _nexusURL)
                track_download(gav, False)
            retry = retry - 1
        return ret


    def get_download_url_artifact(self, gav, repo, url):
        return self.__build_download_url(gav, repo, url, False)

    def get_download_url_metadata(self, gav, repo, url):
        return self.__build_download_url(gav, repo, url, True)

    def __build_download_url(self, gav, repo, url, metadata):
        fdeploy.LOGGER.debug("__build_download_url: %s %s, meta=%s, repo=%s, url=%s", gav.packaging, gav, metadata, repo, url)
        # Nexus v2
        groupId = re.sub( r'\.','/',gav.groupId)
        version=gav.version
        prefix = gav.artifactId
        extension = gav.packaging
        nexusUrlPulls = []
        if metadata:
            URL_PATTERN='%s/%s/%s/%s/maven-metadata.xml'
            if "file://" in url or url.startswith('.') or url.startswith('/'):
                return  ["%s/%s/%s/maven-metadata.xml" %  (absolute_repository_path(url,True) , groupId, gav.artifactId )]
            for u in uniq([NEXUSv3,NEXUSv2,url]):
                nexusUrlPulls.append(URL_PATTERN % (u, resolve_reponame(u) , groupId, gav.artifactId ))
            fdeploy.LOGGER.debug("build download urls: \n\t%s" % ("\n\t".join(nexusUrlPulls)))
            return nexusUrlPulls
        else:
            URL_PATTERN='%s/%s/%s/%s/%s/%s-%s.%s'
            if "file://" in url or url.startswith('.') or url.startswith('/'):
                return ["%s/%s/%s/%s/%s-%s.%s" % (absolute_repository_path(url,True), groupId, gav.artifactId,gav.version, prefix, version, extension )]
            for u in uniq([NEXUSv3,NEXUSv2,url]):
                if gav.isSnapshot() == True:
                    version = self._getSnapShotVersion(gav, resolve_reponame(u),u)
                    fdeploy.LOGGER.info("snapshot %s resolved to %s", gav.version, version)
                    nexusUrlPulls.append(URL_PATTERN % (u,  resolve_reponame(u) , groupId, gav.artifactId
                        ,gav.version, prefix, version, extension ))
                    #break
                else:
                    nexusUrlPulls.append(URL_PATTERN % (u,  resolve_reponame(u) , groupId, gav.artifactId
                        ,gav.version, prefix, version, extension ))
            fdeploy.LOGGER.debug("build download urls: %s" % (nexusUrlPulls))
            return nexusUrlPulls

    def _getSnapShotVersion(self, gav, repository, url):
        nexusMetadataUrls = [self._get_meta_data_snapshot_url(gav,repository,url)]
        resolved = None
        for nexusMetadataUrl in nexusMetadataUrls:
            #fdeploy.LOGGER.debug("loading metadata from %s", nexusMetadataUrl)
            res = self.getWithRetry(nexusMetadataUrl,gav)
            if res is None or res.ok == False:
                continue
            fdeploy.LOGGER.debug("retrieved content: success=%s for %s",res.ok, nexusMetadataUrl)
            tree = ET.fromstring(res.content)
            resolved = gav.version
            for versions in tree.findall('.//snapshotVersion' ):
                __version = versions.find('value').text
                __pack = versions.find('extension').text
                fdeploy.LOGGER.debug("pa k: %s / %s -- eq = %s", __pack, gav.packaging, __pack  == gav.packaging)
                fdeploy.LOGGER.debug("+v=%s r=%s p=%s p+=%s", __version, resolved,  __pack  ,gav.packaging)
                if __pack  == gav.packaging:
                    resolved = __version
                    fdeploy.LOGGER.info("retrieved meta data packaging [%s]: version=%s from %s", gav.packaging,resolved, nexusMetadataUrl)
                    return resolved
        return resolved

    def _get_meta_data_snapshot_url(self,gav,repository,url):
        groupId = str(gav.groupId).replace('.', '/')
        if gav.isSnapshot():
            fdeploy.LOGGER.debug("getting snapshot based on ,gav=%s,repository%s,url=%s",gav,repository,url)
            if url.startswith('file://'):
                return "%s/%s/%s/%s/maven-metadata.xml" % (url,groupId, gav.artifactId, gav.version )
            else:

                return "%s/%s/%s/%s/%s/maven-metadata.xml" % (url,resolve_reponame(url,True),groupId, gav.artifactId, gav.version)
        else:
            raise Exception("_get_meta_data_snapshot_url cannot be used on %s" %(gav.version))


    # def _get_meta_data_url(self, gav, repository, url=None):
    #     if not url:
    #         url = self.nexusURL
    #     groupId = str(gav.groupId).replace('.', '/')
    #     nexusMetadataUrl = "%s/nexus/content/repositories/%s/%s/%s/maven-metadata.xml" % (url,repository,groupId, gav.artifactId )
    #     if "file://" in nexusMetadataUrl or nexusMetadataUrl.startswith('.') or nexusMetadataUrl.startswith('/'):
    #         nexusMetadataUrl = "%s/%s/%s/maven-metadata.xml" % (url,groupId, gav.artifactId )
    #     nexusMetadataUrl = absolute_repository_path(nexusMetadataUrl,True)
    #     # use the metadata xml in the SNAPSHOT directory, instead of the root of the artifact, to get buildnumber and timestamp
    #     if gav.version.endswith('SNAPSHOT'):
    #         if nexusMetadataUrl.startswith('file://'):
    #             nexusMetadataUrl = "%s/%s/%s/maven-metadata.xml" % (url,groupId, gav.artifactId )
    #         else:
    #             nexusMetadataUrl = "%s/nexus/content/repositories/%s/%s/%s/maven-metadata.xml" % (url,repository,groupId, gav.artifactId )
    #     if self.echo:
    #         fdeploy.LOGGER.debug("\tloading metadata from %s" %(nexusMetadataUrl)
    #     return nexusMetadataUrl
