# -*- coding: utf-8 -*-
from fdeploy.content.gavClass import gavClass
from fdeploy.content.contentClass import contentClass
from fdeploy.platform.pcf import cupsAppdClass, cupsCredentialsClass, cupsJmsProviderClass,\
        cupsConfigVariableClass, cupsDatabaseServiceClass, cupsGitConfigServerClass,\
        cupsConfigVariableClass, cupsUriClass, cupsSplunkClass
import fdeploy

'''
CONTENT FACTORY
'''
def content_factory(content):
    if content is None:
        raise Exception("No content specified!")
    if 'gav' in content:
        return gavClass(content)
    elif 'directory' in content:
        return contentClass(content)
    else:
        raise Exception("ContentException: " + str(content))

'''
SERVICE FACTORY
'''
def service_factory(content):
    if content is None:
        raise Exception("No service specified!")
    if 'class' in content and content['class'] == 'cups' and 'type' in content:
        if content['type'] == 'Credentials':
            return cupsCredentialsClass(content)
        elif content['type'] == 'JmsProvider':
            return cupsJmsProviderClass(content)
        elif content['type'] == 'GitConfigService':
            return cupsGitConfigServerClass(content)
        elif content['type'] == 'ConfigVariable':
            return cupsConfigVariableClass(content)
        elif content['type'] == 'Appd':
            return cupsAppdClass(content)
        elif content['type'] == 'Splunk':
            return cupsSplunkClass(content)
        elif content['type'] == 'DatabaseService':
            return cupsDatabaseServiceClass(content)
        elif content['type'] == 'Uri':
            return cupsUriClass(content)
        else:
            raise Exception('%s is unregistered service type.' % (content['type']))
    else:
        raise Exception("ServiceException: " + str(content))
