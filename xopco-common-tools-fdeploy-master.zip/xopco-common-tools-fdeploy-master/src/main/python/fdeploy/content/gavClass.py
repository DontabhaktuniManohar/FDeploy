# -*- coding: utf-8 -*-
import fdeploy
import re

class gavClass(object):

    archiveFileName = None
    saveArchiveName = None

    def __init__(self, content):
        if 'gav' not in content.keys():
            raise
        gavString = content['gav']
        if gavString is None:
            raise
        gav = gavString.strip().split(':')
        retValue = {}
        self.artifactId = gav[1]
        self.groupId = gav[0]
        self.version = None
        self.saveArchiveName = content['saveArchiveName']
        self.relativePath = None
        self.classifier = None
        self.repoName = None
        self.has_no_releases = None
        self.buildId = None
        self.isResolved = None
        self.repo_url = None
        #self.packaging = 'zip'

        if 'relativePath' in content:
            self.relativePath = content['relativePath']
        if 'repoName' in content:
            self.repoName = content['repoName']
        if 'buildId' in content:
            self.buildId = content['buildId']
        self.archiveFileName = None

        # have to figure out these
        # group:artifact:packaging
        # group:artifact:version:packaging
        # group:artifact:packaging:classifier
        # group:artifact:version:packaging:classifier
        if len(gav) > 4:
            self.classifier = gav[4]
            self.version = gav[2]
            self.packaging = gav[3]
        elif len(gav) > 3:
            if re.match("^[0-9]+\.", gav[2]):
                self.version = gav[2]
                self.packaging = gav[3]
            else:
                self.packaging = gav[2]
                self.classifier = gav[3]
        else:
            self.version = None
            self.packaging = gav[2]
        if self.buildId is None:
            self.buildId = self.version
        fdeploy.LOGGER.debug(str(self.__dict__))

    def isSnapshot(self):
        return '-SNAPSHOT' in self.version

    def isRelative(self):
        if self.relativePath is None:
            return True
        return not self.relativePath.startswith('/')

    def __str__(self):
        return "gav@" + str(self.groupId) + ":" + str(self.artifactId) + \
            ":" + str(self.version) + ":" + str(self.packaging) + \
            ": no_releases:" + str(self.has_no_releases) + \
            ":archive=" + str(self.archiveFileName)
