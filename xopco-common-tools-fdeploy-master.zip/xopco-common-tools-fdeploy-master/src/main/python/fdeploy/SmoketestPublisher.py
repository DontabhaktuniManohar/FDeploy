# -*- coding: utf-8 -*-

import os
import os.path
import sys
import re
import fdeploy
import ldd
import requests
import subprocess


class SmoketestPublisher(object):

    options = None
    level = None


    def __init__(self,options):
        self.options = options
        self.smoke_url = 'https://jenkins-shipment.web.fedex.com:8443/jenkins/job/TEST_AUTOMATION-6268/job/REGRESSION_TEST'
        defaults=None
        if type(self.options) == dict:
            if 'defaults' in self.options:
                defaults = self.options['defaults']
        elif ('defaults' in self.options.__dict__):
            defaults = self.options.defaults
        if defaults is not None:
            if 'smoke_url' in defaults:
                self.smoke_url = defaults['smoke_url']

    def callingsmoketest(self,level,smokesuite,Regressionsuite,artifact_id,version):
        req_url = self.smoke_url
        fdeploy.debug("calling smoketest")
        smokeurl = req_url+"/buildWithParameters?token=SMOKETEST&LEVEL="+ level +"&SUITE="+smokesuite+"&COMPONENT_NAME="+artifact_id+"&COMPONENT_VERSION="+version+"&access_token=3b153999-2cf3-48d7-8199-db2f6b3eb691&cause=deployment_action"
        regressionurl = req_url+"/buildWithParameters?token=SMOKETEST&LEVEL="+ level +"&SUITE="+Regressionsuite+"&COMPONENT_NAME="+artifact_id+"&COMPONENT_VERSION="+version+"&access_token=3b153999-2cf3-48d7-8199-db2f6b3eb691&cause=deployment_action"
        ret = requests.put(smokeurl,proxies=fdeploy.FDX_PROXIES)
        fdeploy.LOGGER.info(smokeurl)
        response1 = 'successful' if ret.ok in [200, 201] or ret.ok == True else "failed: code %s" % (ret.ok)
        fdeploy.debug("sent request for smoketest & status is  %s" % (response1))
        subprocess.call(['sleep', "10"])
        fdeploy.debug("calling regressiontest")
        fdeploy.LOGGER.info(regressionurl)
        ret1 = requests.put(regressionurl,proxies=fdeploy.FDX_PROXIES)
        response2 = 'successful' if ret1.ok in [200, 201] or ret1.ok == True else "failed: code %s" % (ret1.ok)
        fdeploy.debug("sent request for regression & status is  %s" % (response2))
        fdeploy.info("Sucesfully trigrred Smoke test and regression test")
