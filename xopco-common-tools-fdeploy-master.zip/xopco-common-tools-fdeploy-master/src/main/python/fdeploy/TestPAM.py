import unittest2
from fdeploy.pam import pamAuth
import os


class TestPAM(unittest2.TestCase):

    def test_getpwd(self):
        pam = pamAuth()
        uid,pwd = pam.get_passwd(18409)
        self.assertIsNotNone(pwd)
        self.assertTrue('FXS_app3534642', uid)

if __name__ == '__main__':
    unittest2.main()
