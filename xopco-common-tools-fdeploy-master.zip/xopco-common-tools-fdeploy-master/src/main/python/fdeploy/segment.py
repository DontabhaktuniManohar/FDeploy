# -*- coding: utf-8 -*-
import codecs
import sys
import os
import analytics
import datetime
import fdeploy
import traceback
USE_ANALYTICS=False
INITIALIZED=False
# Segement:
#analytics.write_key = 'QDujMBQsUavCKoRUpQpPnTeGcwoobbTR'
#analytics.request_class = 'analytics.segment'
# Google: analytics.write_key = 'UA-125042736-3'
#analytics.write_key = 'UA-125042736-3' - set in fdeploy.py main
analytics.client = 'analytics.GA'

#
def is_enabled():
    return USE_ANALYTICS == True and analytics.write_key is not None

# see event mapping to track() - https://segment.com/docs/destinations/google-analytics/
def init():
    if fdeploy.segment.INITIALIZED == False and analytics.write_key is not None:
        analytics.debug = False
        def on_error(error, items):
            exc_type, exc_value, exc_traceback = sys.exc_info()
            print('\n\t-->Failure: %s / %s' % (error,items))
            traceback.print_tb(exc_traceback, limit=5, file=sys.stdout)
        analytics.on_error = on_error
        analytics.identify(os.environ['USER'], {
            'email': '%s@fedex.com' % (os.environ['USER']),
            'name': 'fdeploy'
        })
        fdeploy.segment.INITIALIZED = True
    return "%s@%s" % (os.environ['USER'], datetime.datetime.now().isoformat())

def track_download(gav, success=True):
    if is_enabled():
        user=init()
        analytics.track(
            user,
            'Download Nexus', {
                'class' : 'nexus_class',
                'category' : 'nexus',
                'label' : '%s:%s:%s' % (gav.artifactId, gav.version, gav.groupId),
                'value' : '%s' % (success)
            }, timestamp=datetime.datetime.now() )

    pass
def track_actions(action, level):
    if is_enabled():
        #print "\n\n\t\t%s -> %s\n\n" % (USE_ANALYTICS,action)
        user=init()
        eventname='Perform Action' # %s' % (action)
        analytics.track(
            user,
            eventname, {
                'category' : 'actions',
                'label' : level,
                'value' : action
            }, timestamp=datetime.datetime.now() )
        #analytics.flush()
    pass

def track_statistics(queue, message):
    if is_enabled():
        user=init()
        for q in queue:
            eventname='Perform %s %s' % (message, q['level'])
            analytics.track(
                user_id=user,
                event=eventname,
                properties={
                    'category' : 'statistics',
                    'label' : q['opco'],
                    'value' : "%s %s %s" % (q['artifactId'], q['version'])
                }, timestamp=datetime.datetime.now() )
    pass
def register_product(gav):
    if is_enabled():
        analytics.upload(groupId=gav.groupId, artifactId=gav.artifactId, version=gav.version)
#  build_data['status'], "${env.CHANGE_AUTHOR}", build_data['failedAt'], "${env.BUILD_NUMBER}")
def build_report(name, status, author, statusMessage, buildNumber ):
    if is_enabled():
        user=init()
        if author is None or author == 'null':
            author = "%s" % (os.environ['USER'])
        analytics.track(
            user_id=user,
            event='BuildResult %s' % (name),
            properties= {
                'category' : 'builds',
                'label' : status,
                'value' : statusMessage
            }, timestamp=datetime.datetime.now() )
    pass
