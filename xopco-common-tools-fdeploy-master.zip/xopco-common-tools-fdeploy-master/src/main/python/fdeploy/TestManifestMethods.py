import unittest2
import fdeploy
import cloudbees



class TestManifestResolver(unittest2.TestCase):

    options={'nexusURL' : 'http://sefsmvn.ute.fedex.com:9999'}
    resolver = fdeploy.nexusVersionResolver(options)

    @classmethod
    def setUpClass(clz):
        #fdeploy.setLogLevel('DEBUG', 4)
        pass

    def test_manifest_init(self):
        mani = fdeploy.manifestResolver('../../test/resources','L1')
        self.assertEquals(10 , len(mani.manifestLookup.keys()))
        self.assertIsNotNone(mani.lookup('probe-client'))
        self.assertEquals('1.3.0-SNAPSHOT',mani.lookup('probe-client'))
        self.assertIsNone(None,mani.lookup('probxxe-client'))

    def test_manifest_with_version_suffix(self):
        # resolving com.fedex.sefs.core:sefs_CoreParent:5.13.1.Peak
        mani = fdeploy.manifestResolver('../../test/resources','L2')
        self.assertEquals(3, len(mani.manifestLookup.keys()))
        self.assertIsNotNone(mani.lookup('sefs_conveyance'))
        self.assertEquals('5.13.1.Peak',mani.lookup('sefs_conveyance'))


    def test_manifest_with_version_wildcarded(self):
        # resolving com.fedex.sefs.core:sefs_CoreParent:5.13.1.Peak
        mani = fdeploy.manifestResolver('../../test/resources','L2')
        self.assertEquals(3, len(mani.manifestLookup.keys()))
        self.assertIsNotNone(mani.lookup('dashboard-web'))
        self.assertEquals('4.0',mani.lookup('dashboard-web'))


if __name__ == '__main__':
    unittest.main()
