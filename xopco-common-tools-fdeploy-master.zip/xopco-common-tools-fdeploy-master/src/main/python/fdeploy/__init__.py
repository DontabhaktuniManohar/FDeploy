# -*- coding: utf-8 -*-

from fdeployLoader import fdeployLoader
from nexusVersionResolver import nexusVersionResolver, absolute_repository_path
from pomResolver import pomResolver
from manifestResolver import manifestResolver
from artifactArchiveCreator import artifactArchiveCreator
import fdeploy.platform.bash_generator
import fdeploy.platform.airflow
from fdeploy.content import content_factory, service_factory
import fdeploy.menu
import fdeploy.menu.creator
from SmoketestPublisher import SmoketestPublisher
from apphelathcheckinfo import apphelathcheckinfo
from fdeploy.content.gavClass import gavClass
from fdeploy.content.contentClass import contentClass

import os
import signal
import sys
import errno
import glob
import logging
import json
import inspect
import contextlib
import zipfile
import re
import shutil
import ConfigParser
import requests
import argparse


LOG_FORMAT = "%(asctime)-15s [%(levelname)-5s](%(filename)s:%(module)s:%(lineno)d) - %(funcName)s: %(message)s"
LOGGER = logging.getLogger('fdeploy')
logging.basicConfig(format=LOG_FORMAT)

def log():
    import logging
    fdeploy.LOGGER.setLevel(logging.DEBUG)


ACTIONS_WITH_COMPONENT_HANDLING = ['deploy','install','stage','publish','unpublish']
ACTIONS_WITH_NO_DOWNLOAD = ['relink','start','stop','restart','run','publish','unpublish']
ACTIONS_WITH_MANIFEST_HANDLING = ['deploy','install','inspect','stage','relink','publish','unpublish']
ACTIONS_APP_USER_REQUIRED = ['start','stop','status','restart','run','deploy']
ACTIONS_HOSTS_ONLY = ['ssh','cloudenv']
ACTIONS_WITH_COMPONENT_MENU = ['deploy','install','relink','start','stop','status','wipeout',
    'restart','stage','publish','unpublish','ssh','ps','inspect','clean']
ACTIONS_WITH_SMOKKETEST = ['deploy']

FDX_PROXIES = {
  'http': 'http://internet.proxy.fedex.com:3128',
  'https': 'https://internet.proxy.fedex.com:3128',
}

# Global Variable for setting version of fdeploy
version=None
MUTE_ALL=False

class Options:
    def __init__(self, **entries):
        self.__dict__.update(entries)

class DumpEncoder(json.JSONEncoder):
    def default(self, o):
        try:
            return {'__{}__'.format(o.__class__.__name__): o.__dict__}
        except:
            return ''
            pass
# log level priority assignments
class Enumeration(set):
    def __getattr__(self, name):
        if name in self:
            return name
        if name is None or name == 'None':
            return 'MUTE'
        raise AttributeError("name!=%s / %s" %(name, type(name)))

    def __setattr__(self, name, value):
        raise RuntimeError("Cannot override values")

    def __delattr__(self, name):
        raise RuntimeError("Cannot delete values")


Priority = Enumeration(["FATAL", "ERROR", "WARN", "INFO", "DEBUG", "TRACE", "MUTE"])

useCache = False
suppressReporting = False
verbose = False
trace_flag = 0
logLevel = Priority.DEBUG


class LevelAction(argparse.Action):

    CHOICES = ['L0', 'L1', 'L2', 'L3', 'L4', 'L6', 'L5', 'PROD', 'PRD']
    CODES = ['d', 'u', 'i', 's', 'v', 't', 'e', 'p', 'p']

    def __init__(self,
                 option_strings,
                 dest,
                 nargs=None,
                 const=None,
                 default=None,
                 type=None,
                 choices=None,
                 required=False,
                 help=None,
                 metavar=None):
        help = "Environment level prefix " + ",".join(self.CHOICES)
        argparse.Action.__init__(self,
                                 option_strings=option_strings,
                                 dest=dest,
                                 nargs=nargs,
                                 const=const,
                                 default=default,
                                 type=type,
                                 choices=choices,
                                 required=required,
                                 help=help,
                                 metavar=metavar,
                                 )

        return

    def __call__(self, parser, namespace, values, option_string=None):
        debug('Processing levelAction for "%s" with "%s"' %
              (self.dest, values))
        upval = values.upper()
        valid = False
        for prefix in self.CHOICES:
            if upval.startswith(prefix):
                valid = True
                break

        if valid == False:
            raise KeyError("Level %s not a valid identified prefix." % (upval))
        # Save the results in the namespace using the destination
        # variable given to our constructor.
        setattr(namespace, self.dest, values)

def level2code(level):
    if level in LevelAction.CHOICES:
        return LevelAction.CODES[LevelAction.CHOICES.index(level)]
    return '?'

def fail(message=''):
   print >> sys.stderr, " ! " + str(message)
   os._exit(1)

def mkdir_p(path):
	try:
		os.makedirs(path)
	except OSError as exc:  # Python >2.5
		if exc.errno == errno.EEXIST and os.path.isdir(path):
			pass
		else:
			raise

def flatten_level_targets(targets, search=None, regex=None):
    if targets is None or len(targets) == 0:
        return []
    items = []
    # if it is already a flattened structure
    if not 'items' in targets[0]:
        items = targets
    else:
        items = []
        for _t in targets:
            if search is None or search == _t['group']:
                fdeploy.trace("collecting targets from " + str(_t['group']))
                items.extend(_t['items'])
    if not regex is None:
        _targets = []
        # prog = re.compile(regex)
        for _t in items:
            for _rx in regex:
                if _rx in _t:
                    _targets.append(_t)
        items = _targets
    return items

''' class reference cache '''
CLASSREF = {}


class fdeployComponent(object):

    def __init__(self, dict, source):
        if dict is None:
            return None
        self.id = None
        self.dict = dict
        self.levels = dict['levels']
        if 'rtv' in dict:
            self.rtv = dict['rtv']
        else:
            self.rtv = []
        self.id = dict['id']
        self.platform = dict['platform']
        self.type = dict['type']
        self.lddtype = re.sub(r'tibco_', '', dict['type'])
        self.lddtype = re.sub(r'tibco', '', self.type)
        self.lddtype = re.sub(r'leech', '', self.type)

        self.files = []
        self.source = source
        self.execute = dict['execute'] if 'execute' in dict else None
        self.name_format = dict['name_format'] if 'name_format' in dict else None
        self.content = dict['content'] if 'content' in dict else []
        self.service = dict['service'] if 'service' in dict else []
        self.filter = dict['filter'] if 'filter' in dict else {}
        self.loader = sys.modules["fdeploy.platform." + self.platform]
        self.services = []
        self.contents = []
        self.rtvMapping = {}
        for item in self.rtv:
            name = str(item['name'])
            self.rtvMapping[name] = str(item['value'])

        self.archivePath = None
        fdeploy.trace(self.dict)
        if self.content:
            for _cont in self.content:
                self.contents.append(content_factory(_cont))
        if self.service:
            for _serv in self.service:
                self.services.append(service_factory(_serv))
        # validate if there are duplicate level names in the descriptor
        dups = []
        for _lvl in self.levels:
            if _lvl['level'] not in dups:
                dups.append(_lvl['level'])
            else:
                raise Exception("Duplicate level assignment in descriptor for %s at level %s" % (
                    self.id, _lvl['level']))
        fdeploy.trace(self.__dict__)

    def isNexusArtifact(self, _content):
        var_ = isinstance(_content, gavClass)
        fdeploy.trace("isNexusArtifact: content = " +
                      str(type(_content)) + " : " + str(_content) + str(var_))
        return var_

    def isAssembledArtifact(self, _content):
        var_ = isinstance(_content, contentClass)
        fdeploy.trace("isAssembledArtifact: content = " +
                      str(type(_content)) + " : " + str(_content) + str(var_))
        return var_

    def hasExecution(self):
        return False if self.execute is None else self.execute

    def prettyprint(self):
        return "%s(%s) - %s" % (self.id, self.type, self.platform)

    def dump(self):
        #LOGGER.debug(json.dumps(self.dict, sort_keys=True, indent=4, separators=(',', ': '))
        pass

    def get_generator_class(self,options,base_dir):
        ref = "%s%s" % (self.type, 'Generator')
        #self.set_target_list(classref,target_refs,machines)
        if options and type(options) == dict and len(options.keys()) == 0:
            fdeploy.warn("options supplied is empty.")
        fdeploy.trace(" module: %s, class=%s" % (self.loader.__name__, ref))
        _class = getattr(self.loader, ref)
        #print " resolved to class: %s" % (_class)
        fdeploy.trace(" resolved to class: %s" % (_class) )
        #print dir(sys.modules[_class.__module__])
        #print dir(fdeploy.platform.bash_tibcobe_generator)
        #print "%s %s %s %s" % (self, options, base_dir, sys.modules[_class.__module__].TARGET_URL_SPEC)
        #CLASSREF[ref] = getattr(self.loader, ref)(self, options, base_dir)
        _class = getattr(self.loader, ref)(self, options, base_dir, sys.modules[_class.__module__].TARGET_URL_SPEC)
        #print str(CLASSREF[ref].__module__)
        return _class,ref

    def get_level(self,lword):
        for l in self.levels:
            if l['level'] == lword:
                return l
        raise KeyError("%s not present in json" % (lword))

    def get_levels(self):
        leev=[]
        for l in self.levels:
            leev.append(l['level'])
        return leev

    def get_rtvs(self, basemap, comp_sources):
        for sources in comp_sources:
            _value = os.path.expandvars(sources['value'].strip())
            basemap[str(sources['name'].strip())]=str(_value)

    def get_env_vars(self, options, levelStruct, REQUIRED_RTVS, propertyVersion=None, init=None):
        fdeploy.trace("current_raw_rtvs=%s" % (self.rtv))
        for item in self.rtv:
            name = str(item['name'])
            self.rtvMapping[name] = str(item['value'])
            #print "%15s = %s" % (name, str(item['value']))

        if init:
            self.rtvMapping.update(init)
        envvar_list=""
        #print "\n--%s - \n-MAAPING" % (level)
        #print str(self.rtvMapping)
        #print str(self.rtv)
        #print "--MAAPING\n"
        if propertyVersion is not None:
            self.rtvMapping['VERSION'] = propertyVersion
        if 'gav' in self.content[0]:
            contentObject = fdeploy.content_factory(self.content[0])
            self.rtvMapping['ARTIFACTID'] = str(contentObject.artifactId)
            self.rtvMapping['GROUPID'] = str(contentObject.groupId)
            try:
                if contentObject.version is not None:
                    self.rtvMapping['VERSION'] = str(contentObject.version)
            except:
                pass
            if propertyVersion is not None:
                self.rtvMapping['VERSION'] = str(propertyVersion)
                try:
                    if contentObject.version is None:
                        contentObject.version = str(propertyVersion)
                except:
                    contentObject.version = str(propertyVersion)

        #print "\n  self.rtvMapping:", str(  self.rtvMapping)
        if levelStruct:
            self.rtvMapping['LEVEL'] = levelStruct
            for _lvl_ in self.levels:
                #print "\n\n_lvl_ %s" % (_lvl_)
                #print "level= %s\n\n" % (level)
                if 'rtv' in _lvl_.keys() and 'level' in _lvl_.keys() and str(_lvl_['level']) == levelStruct:
                    self.get_rtvs(self.rtvMapping, _lvl_['rtv'])
                    #print ("\n\nEel lvlrtvs=%s\n" % (_lvl_['rtv']))
            # setup mandatory runtimevariables
        else:
            raise Exception("No level defined")

        # apply external overwrites
        #print type(options), str(options), str(type(options) == dict)
        if options and type(options) == dict and 'rtv' in options.keys():
            for rtv in options['rtv']:
                name = rtv.split("=")[0]
                value = rtv.split("=")[1]
                if value is None or name is None:
                    raise Exception(
                        "malformed --rtv value supplied %s needs corrected." % (rtv))
                self.rtvMapping[name]=value

        # check if the required rtvs are supplied
        missing_rtvs = []
        for required in REQUIRED_RTVS:
            checked = False
            for key in self.rtvMapping.keys():
                if key == required:
                    checked = True
            if checked == False:
                missing_rtvs.append(required)
        if len(missing_rtvs) > 0:
            raise Exception("Following required keys are missing %s" % (missing_rtvs))
        # assemble

        # resolve variables level and systemlevel
        fdeploy.trace( str(self.rtvMapping.keys()))
        for vars in ['level','systemlevel']:
            for rtvkey in self.rtvMapping.keys():
                text = self.rtvMapping[rtvkey]
                fdeploy.trace("name=%s, value=%s" % (rtvkey, text))
                if vars in self.rtvMapping[rtvkey] and vars in os.environ:
                    #print "\n\n\t\tfound %s key='%s' in %s (%s)\n" % (vars,rtvkey, text, self.rtvMapping[rtvkey])
                    try:
                        text = text.replace('${%s}' % vars, os.environ[vars])
                    except KeyError:
                        pass
                self.rtvMapping[rtvkey]=text

        envvar_list = self.as_envvars()
        # try:
        #     for baskey in sorted(self.rtvMapping.keys()):
        #         fdeploy.debug("%10s = %s" % (baskey,self.rtvMapping[baskey]))
        #         envvar_list = envvar_list + \
        #             "export %s=\"%s\"\n" % (baskey.strip(), self.rtvMapping[baskey].strip())
        # except KeyError as err:
        #     print "MAPPING: %s" % (self.rtvMapping)
        #     print "OPTIONS: %s" % (options)
        #     raise err
        return self.rtvMapping, envvar_list

    def as_envvars(self,rtvs=None):
        envvar_list = ''
        rtvs = self.rtvMapping if rtvs is None else rtvs
        #print "\n \t %s \n " % (rtvs)
        try:
            for baskey in sorted(rtvs.keys()):
                fdeploy.debug("%25s = %s" % (baskey,rtvs[baskey]))
                #print "\t %25s - %-20s " % (baskey, rtvs[baskey])
                envvar_list = envvar_list + \
                    "export %s=\"%s\"\n" % (baskey.strip(), rtvs[baskey].strip())
        except KeyError as err:
            print "KEY_MAPPING: %s" % (rtvs)
            print "KEY_OPTIONS: %s" % (options)
            raise err
        except AttributeError as err:
            print "ATTR_MAPPING: %s" % (rtvs)
            try:
                print "ATTR_OPTIONS: %s" % (options)
            except NameError as err2:
                pass
            raise err
        return envvar_list

def setLogLevel(verbosecount):
    sys.tracebacklimit = 0
    LOGGER.setLevel(logging.WARN)
    level = 'WARN'
    if MUTE_ALL == True:
        return
    if verbosecount == 1:
        sys.tracebacklimit = 1
        LOGGER.setLevel(logging.ERROR)
        level = 'ERROR'
    if verbosecount == 2:
        LOGGER.setLevel(logging.INFO)
        sys.tracebacklimit = 5
        level = 'INFO'
    if verbosecount == 3:
        LOGGER.setLevel(logging.DEBUG)
        sys.tracebacklimit = 9
        level = 'DEBUG'
    if verbosecount > 3:
        LOGGER.setLevel(logging.DEBUG)
        level = 'TRACE'
        sys.tracebacklimit = 10
        # These two lines enable debugging at httplib level (requests->urllib3->http.client)
        # You will see the REQUEST, including HEADERS and DATA, and RESPONSE with HEADERS but without DATA.
        # The only thing missing will be the response.body which is not logged.
        try:
            import http.client as http_client
        except ImportError:
            # Python 2
            import httplib as http_client
        http_client.HTTPConnection.debuglevel = 1

        # You must initialize logging, otherwise you'll not see debug output.
        logging.getLogger().setLevel(logging.DEBUG)
        requests_log = logging.getLogger("requests.packages.urllib3")
        requests_log.setLevel(logging.DEBUG)
        requests_log.propagate = True
    reload(sys)
    print "Log Level = %s" % (level)
    return eval('Priority.%s' % (level))
    return eval('Priority.%s' % (level_as_string))


def __print(method='', message='', priority=Priority.WARN):
    if MUTE_ALL == True:
        return
    messageformat = " %s "
    # if trace_flag > 0:
    #     messageformat = "[%-5s] (%s):\n[ ... ]\t\t%s "
    # else:
    #     method = ''
    if (logLevel == priority):
        if logLevel == Priority.DEBUG:
            LOGGER.debug(messageformat ,str(message))
            return
        if logLevel == Priority.INFO:
            LOGGER.info(messageformat , str(message))
            return
        LOGGER.info(messageformat ,  str(message))
        return
    if (priority == Priority.FATAL):
        print messageformat % (str(message))
        return
    if (priority == Priority.ERROR):
        LOGGER.error(messageformat , message)
        raise Exception(message)
        return
    if (logLevel == Priority.WARN and
            (priority == Priority.ERROR)):
        LOGGER.warn(messageformat , str(message))
        return
    if (logLevel == Priority.INFO and
            (priority == Priority.WARN or priority == Priority.ERROR)):
        LOGGER.info(messageformat , str(message))
        return
    if (logLevel == Priority.DEBUG and (priority == Priority.INFO or priority == Priority.WARN or priority == Priority.ERROR)):
        if logLevel == Priority.DEBUG:
            LOGGER.debug(messageformat , str(message))
            return
        if logLevel == Priority.INFO:
            LOGGER.info(messageformat , str(message))
            return
        return
    if (logLevel == Priority.TRACE and
        (priority == Priority.DEBUG or priority == Priority.INFO
         or priority == Priority.WARN or priority == Priority.ERROR)):
        if logLevel == Priority.DEBUG:
            LOGGER.debug(messageformat , str(message))
            return
        if logLevel == Priority.INFO:
            LOGGER.info(messageformat , str(message))
            return
        return
    else:
        return

def dump(_object):
    json.dumps(_object, sort_keys=True, indent=4, separators=(',', ': '))

def bash_array():
    if (logLevel == Priority.WARN or
            (logLevel == Priority.ERROR)):
        return ['', '#', '#', '']
    if (logLevel == Priority.INFO or
            logLevel == Priority.WARN or logLevel == Priority.ERROR):
        return ['', '', '#', '']
    if (logLevel == Priority.DEBUG or
        logLevel == Priority.INFO or logLevel == Priority.WARN
            or logLevel == Priority.ERROR):
        return ['', '', '', '']
    return ['', '', '', '']

def load_rc(rcfile, options):
    defaults={}
    __config__ = ConfigParser.RawConfigParser()
    __config__.optionxform = str # disable lowercasing keys
    rcfile = absolute_repository_path(rcfile)
    if os.path.exists(rcfile) == False:
        raise Exception('rcfile %s does not exist.' % (rcfile))
    warn('loading %s for defaults.' % (rcfile))
    __config__.read(rcfile)
    try:
        for item in __config__.items('DEFAULTS'):
            (a,b) = item
            if 'snapshotsRepo' in a or 'releasesRepo' in a or 'nexusURL' in a:
                continue
            defaults[a] = b
    except:
        raise Exception('rcfile %s is missing [DEFAULTS] section' %(rcfile))
    options.defaults=defaults
    LOGGER.error("defaults = %s" % (options.defaults))


def cleanup(user):
    if os.path.isdir("/proc"):
        pids = [pid for pid in os.listdir('/proc') if pid.isdigit()]
        for pid in pids:
            try:
                path = os.path.join('/proc', pid, 'cmdline')
                uid = os.stat(path).st_uid
                if uid == user and uid != 'jenkins':
                    cmd = open(os.path.join('/proc', pid, 'cmdline'), 'rb').read()
                    if cmd.find('=================') != -1:
                        print "PID: %s; Command: %s" % (pid, cmd)
                        os.kill(pid,signal.SIGKILL)
            # process has already terminated
            except (IOError, OSError):
                continue


def error(message=''):
    funct = __trace__(inspect.getframeinfo(inspect.currentframe().f_back))
    __print(funct, message, Priority.ERROR)


def fatal(message=''):
    funct = __trace__(inspect.getframeinfo(inspect.currentframe().f_back))
    __print(funct, message, Priority.FATAL)

def warn(message=''):
    funct = __trace__(inspect.getframeinfo(inspect.currentframe().f_back))
    __print(funct, message, Priority.WARN)


def info(message=''):
    funct = __trace__(inspect.getframeinfo(inspect.currentframe().f_back))
    __print(funct, message, Priority.INFO)

def debug(message=''):
    funct = __trace__(inspect.getframeinfo(inspect.currentframe().f_back))
    __print(funct, message, Priority.DEBUG)

def echo(message=''):
    method = __trace__(inspect.getframeinfo(inspect.currentframe().f_back))
    messageformat = "[  >  ]%s : %s "
    if trace_flag > 0:
        messageformat = "[  >  ] (%s): %s "
    else:
        method = ''
    print messageformat % (str(method), str(message))

def trace(message=''):
    funct = __trace__(inspect.getframeinfo(inspect.currentframe().f_back))
    __print(funct, message, Priority.TRACE)

def __trace__(frame):
    ins = frame
    ll = ins.filename.split('/')
    if ll:
        l = ll[::-1]
        file = str(l[0])
        if len(l) > 1:
            file = str(l[1]) + "." + file
    else:
        file = ll
    if trace_flag > 1:
        return str(file) + "/" + str(frame.function) + ":" + str(frame.lineno)
    elif trace_flag > 0:
        return str(frame.function) + ":" + str(frame.lineno)
    return ""


def unpack(member,source,vfilename):
	if not os.path.exists(os.path.dirname(vfilename)):
		try:
			os.makedirs(os.path.dirname(vfilename))
		except OSError as exc:  # Guard against race condition
			if exc.errno != errno.EEXIST:
				raise
	fdeploy.LOGGER.debug("   %s -> %s",member,vfilename)
	target = open(vfilename, "wb+")
	with target:
		shutil.copyfileobj(source, target)
	try:
		target.close()
	except:
		pass
	try:
		source.close()
	except:
		pass
	return vfilename

def resolve_filter(content, filter={}):
    _file = content
    for key in filter.keys():
        _file = _file.replace('${%s}' % key, filter[key])
    return _file

def load_properties(filepath, sep='=', comment_char='#', filter={}):
	"""
	Read the file passed as parameter as a properties file.
	"""
	props = {}
	with open(filepath, "rt") as f:
		for line in f:
			l = line.strip()
			if l and not l.startswith(comment_char):
				key_value = l.split(sep)
				key = key_value[0].strip()
				value = sep.join(key_value[1:]).strip().strip('"')
				props[key] = resolve_filter(value, filter)
	return props

def extract_deployment_xml(level, archiveFileName, targetdir, artifactId=None):
	level_path="%s/" % (level)
	file_list = []
	tibcoxml = None
	fdeploy.LOGGER.info("Extracting Deployments for: %s (%s)\n",archiveFileName, artifactId)
	if archiveFileName.endswith(".zip"):
		with contextlib.closing(zipfile.ZipFile(archiveFileName)) as zfile:
			for member in zfile.namelist():
				if member.endswith(".ear"):
					# print "archive=%s, member=%s" % (archiveFileName,member)
					vfilename = "%s/%s" % (targetdir, member)
					earFile = unpack(member,zfile.open(member),vfilename)
					# print "unpacked %s" % (earFile)
					with contextlib.closing(zipfile.ZipFile(earFile)) as vfile:
						for vmember in vfile.namelist():
							if "TIBCO.xml" in vmember:
								# print "analyzing: %s" % (vmember)
								source = vfile.open(vmember)
								vfilename = "%s/%s-TIBCO.xml" % (targetdir, artifactId)
								tibcoxml=unpack(vmember,source,vfilename)
				elif member.endswith(".xml") and not 'log4j' in member and level_path in member:
					# print "member: " + str(member) + ", target=" + str(targetdir), ", artifactIdv=" + str(artifactId)
					if artifactId in member:
						source = zfile.open(member)
						filename = "%s/%s" % (targetdir, member)
						filename =unpack(member,source,filename)
						file_list.append(filename)
	else:
		fail("ERROR - can only extract a file from a zip archive")
	return [file_list,tibcoxml]
