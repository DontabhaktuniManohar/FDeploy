# -*- coding: utf-8 -*-

import unittest2
from fdeploy.hooks import mattermost, ldd_post_request
import requests
import fdeploy
import logging
from MockHttpServer import get_free_port, start_mock_server

TEST_HTTP_PORT=get_free_port()

fdeploy.LOGGER.setLevel(logging.DEBUG)

class TestHooks(unittest2.TestCase):

    @classmethod
    def setUpClass(cls):
        start_mock_server(TEST_HTTP_PORT)

    def xest_hook_web(self):
        options = {'ldd_url' : 'http://127.0.0.1:%s/' % (TEST_HTTP_PORT)}
        reqitems = {'loggedInUser' : 'akaan', 'applicationNm': 'A','applicationVersion' : 'v1', 'level' : 'PRD', 'opco' : 'xopv'}
        ret,res = ldd_post_request([reqitems], options, noproxy=True)
        fdeploy.LOGGER.info( "ret=%s" %(res.__dict__))
        self.assertEquals('successful',ret)
        self.assertEquals('["cool"]', res.content)
        mattermost('hello from fdeploy unit test')

    def test_hook_fail(self):
        options = {'ldd_url' : 'http://127.0.0.1:%s/' % (TEST_HTTP_PORT)}
        reqitems = {'loggedInUser' : 'akaan'}
        with self.assertRaises(KeyError):
            ret = ldd_post_request([reqitems], options)
