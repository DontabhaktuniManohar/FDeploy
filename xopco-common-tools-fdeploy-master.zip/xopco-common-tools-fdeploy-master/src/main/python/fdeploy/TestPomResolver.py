import unittest2
import fdeploy
import cloudbees
import os


class TestPomResolver(unittest2.TestCase):

    options={'nexusURL' : 'http://sefsmvn.ute.fedex.com:9999'}
    resolver = fdeploy.nexusVersionResolver(options)

    @classmethod
    def setUpClass(clz):
        cdw = os.path.abspath("%s/../../test/resources" % (os.getcwd()))
        clz.options['nexusURL'] = 'file://%s/local' % (cdw)
        #fdeploy.setLogLevel('DEBUG', 3)


    def test_nexus_init(self):
        self.assertNotEqual(self.options['nexusURL'], self.resolver.nexusURL)
        with self.assertRaises(AttributeError):
            self.resolver.resolve(None)


    def test_pom_resolver(self):
        pom=fdeploy.pomResolver('../../test/resources')
        self.assertIsNotNone(pom)
        self.assertEqual(pom.groupId,'com.fedex.sefs.common')
        self.assertEqual(pom.artifactId,'sefs_silverControl')
        self.assertEqual(pom.version,'6.1.19-SNAPSHOT')

    def test_pom_resolverParentGroup_resolve(self):
        pom=fdeploy.pomResolver('../../../src/test/resources','pom-parent.xml')
        self.assertIsNotNone(pom)
        self.assertEqual(pom.groupId,'com.fedex.ground.sefs')
        self.assertEqual(pom.artifactId,'ShipmentGatewayFXG')
        self.assertEqual(pom.version,'3.3.0-SNAPSHOT')

    def test_pom_resolverParentGroupAndVersion_resolve(self):
        pom=fdeploy.pomResolver('../../../src/test/resources','pom-parent-noversion.xml')
        self.assertIsNotNone(pom)
        self.assertEqual(pom.groupId,'a')
        self.assertEqual(pom.artifactId,'i')
        self.assertEqual(pom.version,'1.0.7')

if __name__ == '__main__':
    unittest.main()
