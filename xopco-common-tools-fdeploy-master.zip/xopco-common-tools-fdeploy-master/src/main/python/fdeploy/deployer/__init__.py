from SilverFabric import SilverFabricDeployer
from TibcoBW5Configurer import TibcoBW5Configurer


def prettyprint(message=''):
    print
    print str(message)
