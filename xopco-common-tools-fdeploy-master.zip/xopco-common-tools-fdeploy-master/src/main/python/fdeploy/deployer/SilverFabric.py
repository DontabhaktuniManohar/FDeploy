
import os

class SilverFabricDeployer:

   def __init__(self,level,filelist):
      print "init" + str(type)
      self.fdxcfg = fedex.silverConfig(False) #True turns on config debugging output
      for _a in ['broker.properties','*.common.properties']:
         resolved_props = fedex.reapPropertyFiles(_a,os.getcwd(),level,False)
      filelist.extend(resolved_props)
      fdxcfg.readConfig(filelist)


