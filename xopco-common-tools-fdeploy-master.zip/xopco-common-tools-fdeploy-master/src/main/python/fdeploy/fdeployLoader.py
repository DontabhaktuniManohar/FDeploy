# -*- coding: utf-8 -*-

import json
import os
import re
import sys
import pprint
import fdeploy
import glob
import fdeploy.nexusVersionResolver
import fdeploy.manifestResolver
import fdeploy.artifactArchiveCreator
import codecs
import subprocess
import requests
import fdeploy.platform
from ldd.lddPublisher import lddPublisher
from fdeploy.segment import track_actions
from fdeploy.hooks import ldd_post_request

DEFAULT_TARGET_SPEC = re.compile('(\S+)\@([a-z0-9-\._]+)')
def loggedinuser():
        loggedasuser = os.getlogin()
        loggeduser = re.sub('[A-Za-z]','', loggedasuser)
        return loggeduser
def split(a, n):
    t=[]
    s=[]
    for i in range(0,len(a)):
        if i%n == 0:
            s=[]
            t.append(s)
        s.append(a[i])
    return t

def _needs_nexus_resolving(action, no_download):
    if no_download == True:
        return False
    return action in fdeploy.ACTIONS_WITH_COMPONENT_HANDLING

def _needs_manifest_resolving(action):
    return action in fdeploy.ACTIONS_WITH_MANIFEST_HANDLING

# classes
class fdeployLoader:
    components = None
    targets = None
    deployable_items = None
    action = None
    verboseFlag = False
    loadingDirectory = None
    options = None
    id_filter = None
    resolver = None

    def __init__(self, cli_options, importComponents=None):
        self.options = cli_options

        if type(cli_options) == dict:
            if "action" in cli_options:
                self.action = cli_options['action']
            if "X" in cli_options:
                self.verboseFlag = cli_options['X']
            if "id" in cli_options:
                self.id_filter = cli_options['id']
        elif isinstance(cli_options, object) and cli_options.command != 'menu':
            self.action = cli_options.action
            self.verboseFlag = cli_options.X
            self.id_filter = cli_options.id
        self.components = [] if importComponents is None else importComponents
        self.base_dir = 'tmp'
        if os.path.isdir(self.base_dir) == False:
            os.makedirs(self.base_dir, 0755)
        fdeploy.LOGGER.debug(" < init fdeployLoader @ " + str(self.base_dir))

        # create artifact resovler with caching features.
        self.resolver = fdeploy.nexusVersionResolver(self.options,
                                                fdeploy.useCache, self.base_dir)
        if 'defaults' in self.options and 'nexusURL' in self.options.defaults:
            self.resolver.applyOptions(self.options.defaults)

    def readDescriptors(self, argv):
        cfg_files = []
        for argvJSON in argv[:]:
            # might have embedded ${ENV} vars that need resolved and might have wildcard(s) passed in that need expansion
            cfg_descriptors = glob.glob(os.path.expandvars(argvJSON))
            cfg_files.extend(cfg_descriptors)
        fdeploy.LOGGER.debug(" > found %s descriptor files." %
                      (len(cfg_files)))
        # filter by id
        id = None
        try:
            id = self.options['id'] if isinstance(self.options,dict) else self.options.id;
            if id is not None and '#' not in id:
                if '!' in id:
                    id=id.replace('!','')
                    cfg_files = [x for x in cfg_files if id not in x]
                else:
                    cfg_files = [x for x in cfg_files if id in x]
                id = None
        except:
            pass
        if len(cfg_files) == 0:
            raise Exception("No files found with %s " % (argv))
        for cfgProp in cfg_files[:]:
            cfg_descriptorsFile = os.path.normpath(cfgProp)
            fdeploy.LOGGER.info("processing '%s'", cfg_descriptorsFile)
            assert os.path.isfile(
                cfg_descriptorsFile), "Properties file: " + cfg_descriptorsFile + " NOT FOUND!"
            cfg_descriptorsFileBasename = os.path.basename(
                cfg_descriptorsFile)
            fdeploy.LOGGER.debug(" < reading descriptor file: " +
                          cfg_descriptorsFile)
            self.digest(cfg_descriptorsFile,id)

    def digest(self, jsonfile, id):
        loadingFile = os.path.abspath(jsonfile)
        self.loadingDirectory = os.path.dirname(os.path.abspath(loadingFile))
        deploy_descr = []
        with open(loadingFile) as descriptor:
            try:
                deploy_descr = json.loads(descriptor.read())
            except Exception, e:
                ##print "loading %s failed." % (loadingFile)
                raise Exception("loading %s failed.: reason: %s" % (loadingFile, e))
        comps = []
        for component in deploy_descr:
            #fdeploy.trace(component)
            comp = fdeploy.fdeployComponent(component, loadingFile)
            fdeploy.LOGGER.info("adding %s" % (comp.prettyprint()))
            if id is None:
                self.components.append(comp)
            else:
                if '#' in id:
                    id=id.replace('#','') if id else id;
                    if '!' in id:
                        id=id.replace('!','')
                        if id not in comp.type:
                            self.components.append(comp)
                    else:
                        if id in comp.type:
                            self.components.append(comp)

    def set_targets(self, _targets):
        self.targets = _targets

    def set_components(self, _comp_):
        __components = self.components
        _filtered_list = []
        for _c in __components:
            for __c in _comp_:
                _s, _i = __c
                if _s == '--all--':
                    fdeploy.LOGGER.info("selected all components.")
                    return
                if _c.id == _s:
                    _filtered_list.append(_c)
        self.components = _filtered_list

    def find_level(self,comp,level):
        for _level in comp.levels:
            if _level['level'] == level:
                return _level
        return None

    def find_targets_in_level(self,comp,level, groupSize=-1,groupNumber=-1,target_key='targets'):
        if type(level) != dict:
            _level = self.find_level(comp, level)
            if _level is None:
                leev = ", ".join(comp.get_levels())
                raise Exception("no level '%s' found [available=%s]" % (level,leev))
            level = _level

        if level:
            try:
                _group = self.options.group if type(self.options) != dict else self.options['group']
            except:
                _group = None
            try:
                _regex = self.options.regex if type(self.options) != dict else self.options['regex']
            except:
                _regex = None
            try:
                _groupSize = self.options.group_size if type(self.options) != dict else self.options['group_size']
                _groupSize = groupSize if _groupSize is None else _groupSize
            except:
                _groupSize = groupSize
            try:
                _groupNumber = self.options.group_number if type(self.options) != dict else self.options['group_number']
                _groupNumber = groupNumber if _groupNumber is None else _groupNumber
            except:
                _groupNumber = groupNumber
            targets = fdeploy.flatten_level_targets(level[target_key], _group, _regex)
            if _groupSize > 0:
                _groupNumber = 0 if _groupNumber < 0 else _groupNumber
                groups = split(targets,_groupSize)
                #fdeploy.LOGGER.debug(groups)
                fdeploy.LOGGER.info("targets grouped by %s in size, and selected group number %s" % (_groupSize, _groupNumber))
                if _groupNumber < len(groups):
                    return groups[_groupNumber]
                else:
                    raise KeyError("illegal group number %s must be >0 and <=%s for groupsize %s" % (_groupNumber, len(groups),_groupSize))
            else:
                return targets

        return []

    def generate_level(self, level):
        # using manifest resolver for nexus versions
        filelist = []
        manifest_resolver = None
        resolver = None
        ##print "OPTIONS_GENERATE: %s" %( self.options )
        _loaddir_ = '.' if self.loadingDirectory is None else self.loadingDirectory
        fdeploy.LOGGER.info(" > generating level %s for action %s from %s with %s components." %
                     (level, self.action, _loaddir_, len(self.components)))
        fdeploy.LOGGER.info(" > generating level %s for action %s with %s components." %
                     (level, self.action, len(self.components)))
        if len(self.components) < 1:
            print "╔╗╔╔═╗  ╔═╗╔═╗╔╦╗╔═╗╔═╗╔╗╔╔═╗╔╗╔╦╗╔═╗  ╔═╗╔═╗╦ ╦╔╗╔╔╦╗"
            print "║║║║ ║  ║  ║ ║║║║╠═╝║ ║║║║║╣ ║║║║ ╚═╗  ╠╣ ║ ║║ ║║║║ ║║"
            print "╝╚╝╚═╝  ╚═╝╚═╝╩ ╩╩  ╚═╝╝╚╝╚═╝╝╚╝╩ ╚═╝  ╚  ╚═╝╚═╝╝╚╝═╩╝"
            sys.exit(1)

        manifest_resolver = fdeploy.manifestResolver(_loaddir_, level)
        # create artifact resovler with caching features.
        self.resolver.set_manifest_resolver(manifest_resolver)
        resolver = self.resolver
        # some actions are not intented for by component level but by
        #   target level
        track_actions(self.action, level)

        if not self.action in fdeploy.ACTIONS_HOSTS_ONLY:
            # - - - -
            # bailout=None
            j = 0
            for comp in self.components:
                j += 1
                fdeploy.LOGGER.info("processing component: %s of %s : %s of type %s" %
                             (j, len(self.components), comp, comp.type))
                _level = self.find_level(comp,level)
                bailout = None
                # loop thru all the content types and execute the appropriate
                # resolving or creation of these artifacts.
                i = 0
                for content in comp.contents:
                    i += 1
                    fdeploy.LOGGER.info("processing content: %s of %s : %s" %
                                 (i, len(comp.contents), content))
                    # execution loop
                    if self.action == 'run':
                        # execution of command does not need any resolving.
                        fdeploy.LOGGER.debug("execute(): %s" % (self.action))
                        self.___generate_content_by_component_targets(
                            self.options.output, comp, _level, target_key='execute')
                    else:
                        if comp.isNexusArtifact(content) == True:
                            # resolving contents for the component
                            #  = lookup versions in the manifest and resolve against Nexus
                            #  = downloading archives from specified in the content
                            fdeploy.trace("deterimator download: %s %s action_required? %s %s" % (comp, content, self.action in fdeploy.ACTIONS_WITH_NO_DOWNLOAD,
                                                                                                  self.options.dry_run or self.options.no_download))
                            no_download_flag = self.action in fdeploy.ACTIONS_WITH_NO_DOWNLOAD \
                                or self.options.dry_run or self.options.no_download
                            # special case where we need the query information from the deployment config
                            if (comp.lddtype == "tibco_bw" or comp.lddtype == "tibco_bw2") and self.action == 'publish':
                                fdeploy.LOGGER.info("downloading BW app for publishing")
                                no_download_flag = False
                            fdeploy.LOGGER.debug(" > action=%s, download flag = %s" % (
                                self.action, no_download_flag))
                            found = resolver.resolveGavs(
                                comp, _needs_nexus_resolving(self.action, no_download_flag), self.options.dry_run, _needs_manifest_resolving(self.action))
                            fdeploy.trace("found component: %s" % (found))
                            if found is None:
                                # next component, current comp not in manifest
                                fdeploy.LOGGER.warn(
                                    "skipping %s: no manifest entry." ,comp.id)
                                bailout = comp
                        elif comp.isAssembledArtifact(content) == True:
                            if self.action in fdeploy.ACTIONS_WITH_COMPONENT_HANDLING:
                                fdeploy.LOGGER.info("assembly content artifact %s" % (comp.id))
                                # assemble the artfact for inclusion in upload content
                                # artifact creator instance and feed the filter values
                                rtv_map={}
                                rtv_map,envvar_list=comp.get_env_vars(self.options, level, [])
                                fdeploy.LOGGER.debug("filter values: %s/%s" % (level, rtv_map))
                                creator = fdeploy.artifactArchiveCreator(_loaddir_, True)
                                creator.create(comp, content, rtv_map)
                        else:
                            #print comp
                            raise Exception(
                                'Unable to create or resolve the artfiact content ' + str(content) + ".")
                    if bailout:
                        fdeploy.LOGGER.info("next component")
                        continue
                    else:
                        leev = []
                        for l in comp.levels:
                            leev.append(l['level'])
                        fdeploy.LOGGER.debug(
                            "generating  %s - %s (available %s)",level,  comp.id, ", ".join(leev))
                        self.___generate_content_by_component_targets(
                            self.options.output, comp, _level)
        else:
            # target focused calls only (meaning not component focused but host based)
            classref = {}
            target_refs = {}
            machines = []
            for comp in self.components:
                ref = "%s%s" % (comp.type, 'Generator')
                try:
                    _class = classref[ref]
                except:
                    fdeploy.trace(" module: %s, class=%s" %
                                  (comp.loader.__name__, ref))
                    fdeploy.trace(" resolved to class: %s for level %s" %
                                  (getattr(comp.loader, ref), level))
                    classref[ref] = getattr(comp.loader, ref)(
                        comp, self.options, self.base_dir, DEFAULT_TARGET_SPEC)
                    _class = classref[ref]
                for _level in comp.levels:
                    if _level['level'] == level:
                        # assign empty array fo the target list
                        # of this generator type
                        if not _class in target_refs:
                            target_refs[_class] = []
                        _class.list_machines(
                            _level, target_refs[_class], self.options.group)

            if _class not in target_refs or len(target_refs[_class]) < 1:
                print "╔╗╔╔═╗  ╦  ╔═╗╦  ╦╔═╗╦    ┌─%s─┐  ┌─┐┌─┐┬ ┬┌┐┌┌┬┐" % (level)
                print "║║║║ ║  ║  ║╣ ╚╗╔╝║╣ ║    │ %s │  ├┤ │ ││ ││││ ││" % (level)
                print "╝╚╝╚═╝  ╩═╝╚═╝ ╚╝ ╚═╝╩═╝  └─%s─┘  └  └─┘└─┘┘└┘─┴┘" % (level)
                sys.exit(1)

            # ---
            for _class in target_refs.keys():
                targets = target_refs[_class]
                filename = _class.__class__.__name__ + level + '.' + \
                    _class.extension if self.options.output is None else self.options.output
                full_path = self.base_dir + '/' + filename
                fdeploy.LOGGER.debug(" > writing '%s' for '%s' type in '%s'.",full_path, level, os.getcwd())
                with codecs.open(full_path, 'w', 'utf-8') as outfile:
                    # load dynamically the generator instance
                    # generating deployment script
                    _class.generate(
                        {'contents': None, 'targets': targets,
                            'level': _level, 'uuid': 'all', 'directory' : self.loadingDirectory},
                        outfile, self.action, DEFAULT_TARGET_SPEC)
                outfile.close()
                fdeploy.LOGGER.info(" < wrote '%s' for action '%s'" ,filename, self.action)
                if filename not in comp.files:
                    comp.files.append(filename)
            if len(comp.files) < 1:
                print "╔╗╔╔═╗  ╔═╗╔═╗╔╦╗╔═╗╔═╗╔╗╔╔═╗╔╗╔╦╗╔═╗  ╔═╗╔═╗╦ ╦╔╗╔╔╦╗"
                print "║║║║ ║  ║  ║ ║║║║╠═╝║ ║║║║║╣ ║║║║ ╚═╗  ╠╣ ║ ║║ ║║║║ ║║"
                print "╝╚╝╚═╝  ╚═╝╚═╝╩ ╩╩  ╚═╝╝╚╝╚═╝╝╚╝╩ ╚═╝  ╚  ╚═╝╚═╝╝╚╝═╩╝(level=$level)"
                sys.exit(1)
        return comp.files

    def ___generate_content_by_component_targets(self, filename, comp, levelStruct, target_key='targets'):
        fdeploy.LOGGER.debug(" < found level %s for %s type with id %s writing as %s." ,levelStruct, comp.type,comp.id, filename)
        # if target_key not in level or len(level[target_key]) < 1)
        _level = levelStruct
        ##print str(comp.__dict__)
        for a in comp.__dict__:
            value = comp.__dict__[a]
            if (a == 'file' or a == 'regex') and not value is None:
                value = ",".join(value)
            fdeploy.trace(" %15s = %s " % ( a,value))
        _class,className = comp.get_generator_class(self.options,self.base_dir)
        # _class = getattr(comp.loader, comp.type +
        #                  'Generator')(comp, self.options, self.base_dir)
        filename = comp.id + '.' + _class.extension if filename is None else filename
        full_path = self.base_dir + '/' + filename
        fdeploy.LOGGER.debug(" > ___generate_content_by_component_targets(): writing '%s' for '%s' type in '%s'." ,full_path, comp.id, os.getcwd())
        # target_key = 'targets' or 'execute' to pick targets for installation or execution
        # #print "target_key=%s => %s" % (target_key, _level[target_key])
        targets = self.find_targets_in_level(comp, levelStruct)
        # targets = fdeploy.flatten_level_targets(
        #     _level[target_key], self.options.group, self.options.regex)
        if targets is None or len(targets) == 0:
            raise Exception("no targets selection %s %s " % (levelStruct,comp))
        if self.targets is not None:
            fdeploy.LOGGER.debug("___generate_content_by_component_targets(): using selected targets: %s", targets)
            targets = self.targets
        with open(full_path, 'w') as outfile:
            fdeploy.LOGGER.debug("___generate_content_by_component_targets(): writing %s",full_path)
            # load dynamically the generator instance
            # generating deployment script
            rtvs = _level['rtv'] if 'rtv' in _level else []
            rtvs = comp
            _class.generate(
                {'contents': comp.contents,
                    'targets': targets, 'directory' : self.loadingDirectory,
                    'rtv': rtvs, 'level': levelStruct, 'uuid': comp.id
                 }, outfile, self.action)
        outfile.close()
        if filename not in comp.files:
            comp.files.append(filename)
        fdeploy.LOGGER.info(" < wrote '%s' (%s#) for action '%s' by components ." % (
            filename, len(comp.files), self.action))

    def show_probe_definitions(self, level,search=None):
        if get_machines(level) is not None:
            __targets = get_machines(level)
        # transform the url notation
        for target in __targets:
            _target = target.split(":")[0]
            if self.options.user is not None:
                _target = re.sub(
                    r'^(\S+)\@', self.options.user + str('@'), _target)
            if not _target in target_list:
                target_list.append(_target)

        structure = { 'level' : struct['level'], 'rtv' : [], 'targets' : []}
        for tgt in target_list:
            structure['targets'].append("%s:/opt/fedex/%s/fxs-probe" % (tgt,tgt.split("@")[0]))
        #print json.dump(structure, indent=4)

    def get_machines(self, level):
        for comp in self.components:
            for _level in comp.levels:
                if _level['level'] == level:
                    return {'targets': fdeploy.flatten_level_targets(
                        _level['targets'], self.options.group, self.options.regex)}
        return None

    def list_machines(self, level, report=True):
        machines = []
        for comp in self.components:
            _class = getattr(comp.loader, comp.type +
                             'Generator')(comp, self.options, self.base_dir)
            _tuple_level = self.get_machines(level)
            if _tuple_level is not None:
                ll = _class.list_machines(_tuple_level, machines)
        if report == True:
            for machine in sorted(machines):
                fdeploy.LOGGER.info(machine)
        return sorted(machines)

    def publishing(self, options, level):
        found = None
        lddService = lddPublisher(level, options, self.base_dir,self.resolver)
        fdeploy.LOGGER.info("publishing %s components in %s." ,len(self.components), level)
        for comp in self.components:
            for _level in comp.levels:
                if level.startswith(_level['level']):
                    found = level
                    if (found != "PROD"):
                        if hasattr(comp, 'contents'):
                            for nexusContent in comp.contents:
                                if comp.isNexusArtifact(nexusContent):
                                    break
                            fdeploy.LOGGER.debug("action: %s" ,options.action)
                            #fdeploy.LOGGER.debug("ALL IN THE FAMILY %s %s \n" % (level,nexusContent))
                            if comp.isNexusArtifact(nexusContent) and comp.type != 'pcf':
                                if options.action == 'unpublish' :
                                    lddService.unpublish(level, nexusContent, comp)
                                elif options.action in ['publish','report'] :
                                    lddService.publish(level, nexusContent, comp)
                                else:
                                    raise Exception('illegal use of publishing method')
                            else:
                                fdeploy.LOGGER.warn("component content '%s' does not have publish capabilities." ,comp.type )
                        else:
                            print("publish , unpublish and report actions are disabled for PROD")

        if found and len(lddService.queue) > 0:
            if options.action == 'report':
                lddService.reportRequests()
            elif options.action == 'unpublish':
                lddService.unpublishRequests()
                lddService.refresh(level)
            elif options.action == 'publish':
                lddService.publishRequests()
                lddService.refresh(level)
            else:
                raise Exception('illegal use of publishing method')

    def deploying(self, level, filelist):
        __class = None
        pause = 3
        statistics = []
        log_user = loggedinuser()
        smokesuite = None
        Regressionsuite = None
        for comp in self.components:
            for _level in comp.levels:
                if _level['level'] == level:
                    fdeploy.trace("deploying(): loading %sDeployer from %s" % (comp.type,comp.loader))
                    _class = getattr(comp.loader, comp.type +
                                     'Deployer')(comp, self.options, self.base_dir)
                    if __class is None:
                        __class = _class
                    # only us a longer pause when deploying or installing
                    pause = 6 if _needs_manifest_resolving(
                        self.action) == True else 3
                    # reporting.extend(
                    #fdeploy.trace(str(__class) + str(dir(_class)))
                    fdeploy.trace("comp= %s" % (comp) )
                    if (len(comp.files) != 0):
                        _class.deploying(comp.files, pause)
                    else:
                        if (len(comp.content) == 0):
                            fdeploy.LOGGER.info("> %s",comp.prettyprint())
                            fdeploy.LOGGER.warn("deploying(): no files found for %s", comp.prettyprint())
                        else:
                            _class.deploying(comp.files, pause)

                    # prepare statistics
                    if hasattr(comp, 'contents'):
                        _COM=re.compile('.+\/config\.(\w+)\/.*')
                        m = _COM.match(comp.source)
                        app_group = "NA"
                        if m and len(m.groups()) > 0:
                            app_group = m.group(1)
                            smokesuite = "%ssmokeTest" % (m.group(1))
                            if (m.group(1) == "FXE"):
                                Regressionsuite="ExpressRegression"
                            elif (m.group(1) == "FXF"):
                                Regressionsuite="FreightRegression"
                            elif (m.group(1) == "FXG"):
                                Regressionsuite="GroundRegression"
                        else:
                            fdeploy.LOGGER.warn("no smoketest execution, no group found for %s", comp.source)

                        found = None
                        for nexusContent in comp.contents:
                            if comp.isNexusArtifact(nexusContent):
                                found = nexusContent
                                break
                        if found:
                            statistics.append({'applicationNm': nexusContent.artifactId,
                                           'applicationVersion': nexusContent.version, 'level': level,
                                           'opco': app_group, 'releaseNm': 'NA','loggedInUser':log_user})
        if __class is None:
            print "┌┐┌┌─┐  ┌─┐┌─┐┌┬┐┌─┐┌─┐┌┐┌┌─┐┌┐┌┬┐┌─┐  ┬┌┐┌  ╦  ┌─┐┬  ┬┌─┐┬  "
            print "││││ │  │  │ ││││├─┘│ ││││├┤ ││││ └─┐  ││││  ║  ├┤ └┐┌┘├┤ │  "
            print "┘└┘└─┘  └─┘└─┘┴ ┴┴  └─┘┘└┘└─┘┘└┘┴ └─┘  ┴┘└┘  ╩═╝└─┘ └┘ └─┘┴─┘[%s]" % (level)
            raise Exception("no components found! %s " % (level))
        subprocess.call(['sleep', str(pause)])
        if self.options.no_reporting == False:
            reports = [f for f_ in [glob.glob(e) for e in (str(
                __class.stage_directory) + "/deploy*", str(__class.stage_directory) + "/stdout*")] for f in f_]
            __class.report(reports)
        if self.options.upload == False:
            # send up statistics
            if self.options.action in fdeploy.ACTIONS_WITH_COMPONENT_HANDLING:
                if self.options.no_stats == False:
                    for req in statistics:
                        fdeploy.LOGGER.info("deploying(): sending statistics for %s",req['applicationNm'])
                        fdeploy.LOGGER.info("Deploying request : %s", req.items())
                        ldd_post_request(req,self.options)

                        # ret = requests.post(
                        #     'http://c0009869.test.cloud.fedex.com:8090/sefs-dashboard/api/public/deploy/create', json=req, proxies=fdeploy.FDX_PROXIES)
                        #
                        # response = 'successful' if ret.ok in [
                        #     200, 201] or ret.ok == True else "failed: code %s" % (ret.ok)
                        # fdeploy.LOGGER.debug("upload statistics %s", response)
        if self.options.action in fdeploy.ACTIONS_WITH_SMOKKETEST and smokesuite is not None and Regressionsuite is not None:
            rtv_map={}
            rtv_map,envvar_list=comp.get_env_vars(self.options, level, [])
            targets = None
            for _level in comp.levels:
                if level.startswith(_level['level']):
                    targets = fdeploy.flatten_level_targets(_level['targets'],self.options.group, self.options.regex)
                    appHealthInfo = fdeploy.apphelathcheckinfo()
                    if (appHealthInfo.apphelathCheck(comp.lddtype,targets,rtv_map) == True):
                        SmokeService = fdeploy.SmoketestPublisher(self.options)
                        SmokeService.callingsmoketest(level,smokesuite,Regressionsuite,rtv_map['ARTIFACTID'],rtv_map['VERSION'])
                    else:
                        print "Skipping the Smoke test Integartion"
            #SmokeService = fdeploy.SmoketestPublisher(self.options)
            #SmokeService.callingsmoketest(level,smokesuite,Regressionsuite)
            #smokeurl = "https://jenkins-shipment.web.fedex.com:8443/jenkins/job/TEST_AUTOMATION-6268/job/REGRESSION_TEST/buildWithParameters?token=SMOKETEST&LEVEL="+ level +"&SUITE="+smokesuite+"&access_token=3b153999-2cf3-48d7-8199-db2f6b3eb691&cause=deployment_action"
            #regressionurl = "https://jenkins-shipment.web.fedex.com:8443/jenkins/job/TEST_AUTOMATION-6268/job/REGRESSION_TEST/buildWithParameters?token=SMOKETEST&LEVEL="+ level +"&SUITE="+Regressionsuite+"&access_token=3b153999-2cf3-48d7-8199-db2f6b3eb691&cause=deployment_action"
            #ret = requests.put(smokeurl,proxies=fdeploy.FDX_PROXIES)
            #print(smokeurl)
            #response1 = 'successful' if ret.ok in [200, 201] or ret.ok == True else "failed: code %s" % (ret.ok)
            #fdeploy.LOGGER.debug("sent request for smoketest & status is  %s" % (response1))
            #subprocess.call(['sleep', "10"])
            #fdeploy.LOGGER.debug("calling regressiontest")
            #print(regressionurl)
            #ret1 = requests.put(regressionurl,proxies=fdeploy.FDX_PROXIES)
            #response2 = 'successful' if ret1.ok in [200, 201] or ret1.ok == True else "failed: code %s" % (ret1.ok)
            #fdeploy.LOGGER.debug("sent request for regression & status is  %s" % (response2))
            #fdeploy.LOGGER.info("Sucesfully trigrred Smoke test and regression test")
