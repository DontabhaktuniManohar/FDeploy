import unittest2
import fdeploy
import cloudbees
import os
import logging
from nexusVersionResolver import absolute_repository_path, NEXUSv3, NEXUSv2, semantic_compare
import sys

test_component = fdeploy.fdeployComponent({
    'id': 'componentId',
    'platform': 'bash_generator',
    'type': 'java',
    'filter':
        {"var1": "value1", "var2": "value2"},
    'content':  [{
        "gav": "com.fedex.ground.sefs.pd.domainview.coreshipment:fxg-pd-domainview-coreshipment:zip",
        "relativePath": "L1/rel.sh",
        "saveArchiveName": "sefs_suCLEARANCEFeed.zip"
    }],
    'name_format': 'format',
    'levels':
    [{
        'level': 'L1',
        'rtv' : [ { 'name' : 'JMX_PORT', 'value' : '40313'}],
        'targets': ['a@fedex.com', 'b@fedex.com', 'c@fedex.com', 'd@fedex.com', 'e@fedex.com']
    }],
    'rtv': [
            {'name': 'JAVA_HOME',
             'value': '/opt/java/hotspot'
             },
         { 'name' : 'JMX_PORT', 'value' : 'ABCDEF'},
            { 'name' : "APPMANAGE_XML", 'value' : "/var/tmp/${level}/appmanage.xml"}
        ]

}, 'inline.json')
def reset():
    return fdeploy.gavClass({'gav' : 'a:f:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })

class TestNexusResolver(unittest2.TestCase):

    options={'nexusURL' : 'http://sefsmvn.ute.fedex.com:9999'}
    resolver = fdeploy.nexusVersionResolver(options)
    mani = None
    cwd = None

    @classmethod
    def setUpClass(clz):
        cdw = os.path.abspath("%s/../../test/resources" % (os.getcwd()))
        clz.cwd=cdw
        clz.options['nexusURL'] = 'file://%s/local' % (cdw)
        clz.options['absURL'] = '%s/local' % (cdw)
        clz.resolver.applyOptions(clz.options)
        clz.mani = fdeploy.manifestResolver('../../test/resources','L1')
        clz.resolver.set_manifest_resolver(clz.mani)

    def test_absolute_path(self):
        cwd = os.path.abspath('.')
        self.assertEqual(cwd,absolute_repository_path('.'))
        self.assertEqual("file://" + cwd,absolute_repository_path('.',True))
        cwd = os.path.abspath('../okay')
        self.assertEqual("file://" + cwd,absolute_repository_path('file://../okay',True))
        self.assertEqual(cwd,absolute_repository_path('file://../okay',False))
        self.assertEqual('http://localhost/api', absolute_repository_path('http://localhost/api'))
        self.assertEqual('http://localhost/api', absolute_repository_path('http://localhost/api', True))

    def test_nexus_init(self):
        self.assertEqual(self.options['nexusURL'], self.resolver.nexusURL)
        with self.assertRaises(AttributeError):
            self.resolver.resolve(None)

    def test_gav_class_init(self):
        # resolving junit 3.8.1
        gav=fdeploy.gavClass({'gav' : 'org.junit:junit:3.8.1:jar', 'saveArchiveName' : 'junit.zip' })
        #
        self.assertEqual('org.junit', gav.groupId)
        self.assertEqual('junit', gav.artifactId)
        self.assertEqual('3.8.1', gav.version)
        self.resolver.resolve(gav)
        self.assertEqual('3.8.1', gav.version)

    def test_gav_class_with_classifier_init(self):
        # resolving junit 3.8.1
        gav=fdeploy.gavClass({'gav' : 'com.fedex.ground:TLABroker:1.0.2-SNAPSHOT:zip:bin', 'saveArchiveName' : 'junit.zip' })
        #
        self.assertEqual('com.fedex.ground', gav.groupId)
        self.assertEqual('TLABroker', gav.artifactId)
        self.assertEqual('bin', gav.classifier)
        self.assertEqual('1.0.2-SNAPSHOT', gav.version)
        self.assertEqual('zip', gav.packaging)
        self.resolver.resolve(gav)
        self.assertEqual('1.0.2-SNAPSHOT', gav.version)

    def test_gav_class_with_version_classifier(self):
        # resolving com.fedex.sefs.core:sefs_CoreParent:5.13.1.Peak
        gav=fdeploy.gavClass({'gav' : 'com.fedex.sefs.core:sefs_CoreParent:5.13.1.Peak:zip:bin', 'saveArchiveName' : 'Peak.zip' })
        #
        self.assertEqual('com.fedex.sefs.core', gav.groupId)
        self.assertEqual('sefs_CoreParent', gav.artifactId)
        self.assertEqual('bin', gav.classifier)
        self.assertEqual('5.13.1.Peak', gav.version)
        self.assertEqual('zip', gav.packaging)
        self.resolver.resolve(gav)
        self.assertEqual('5.13.1.Peak', gav.version)

    def test_gav_class_with_classifier_resolve_init(self):
        # resolving junit 3.8.1
        gav=fdeploy.gavClass({'gav' : 'com.fedex.ground:TLABroker:zip:bin', 'saveArchiveName' : 'junit.zip' })
        #
        self.assertEqual('com.fedex.ground', gav.groupId)
        self.assertEqual('TLABroker', gav.artifactId)
        self.assertEqual('bin', gav.classifier)
        self.assertEqual(None, gav.version)
        self.assertEqual('zip', gav.packaging)

    def test_gav_class_resolve_major_minor(self):
        # resolving maven-model 3.2* to 3.2.5
        gav=fdeploy.gavClass({'gav' : 'org.apache.maven:maven-model:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        #
        self.assertEqual('org.apache.maven', gav.groupId)
        self.assertEqual('maven-model', gav.artifactId)
        self.assertEqual(None, gav.version)
        self.resolver.resolve(gav,'3.2')
        self.assertEqual('3.2.5', gav.version)

    def test_get_meta_data_snapshot_url(self):
        # split artifact some in v2 others in v3
        gav = fdeploy.gavClass({'gav' : 'com.fedex.sefs.core.java.jms:itinerary-proxy-service:jar','repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        gav.version = '1.0.0-SNAPSHOT'
        self.assertEqual('http://sefsmvn.ute.fedex.com:9999/nexus/service/local/repo_groups/public/content/com/fedex/sefs/core/java/jms/itinerary-proxy-service/1.0.0-SNAPSHOT/maven-metadata.xml',
            self.resolver._get_meta_data_snapshot_url(gav,'default',NEXUSv2))

        #http://sefsmvn.ute.fedex.com:9999/nexus/service/local/repositories/snapshots/content/com/fedex/sefs/dashboard/probe-client/1.3.0-SNAPSHOT/maven-metadata.xml
        gav = fdeploy.gavClass({'gav' : 'com.fedex.sefs.dashboard:probe-client:zip', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        gav.version = '1.3.0-SNAPSHOT'
        self.assertEqual('http://sefsmvn.ute.fedex.com:9999/nexus/service/local/repo_groups/public/content/com/fedex/sefs/dashboard/probe-client/1.3.0-SNAPSHOT/maven-metadata.xml',
            self.resolver._get_meta_data_snapshot_url(gav,'default',NEXUSv2))

        gav = fdeploy.gavClass({'gav' : 'xopco.common.tools:xopco-common-tools-fdeploy:zip', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        gav.version = '7.0.0-SNAPSHOT'
        #https://nexus.prod.cloud.fedex.com:8443/nexus/repository/SEFS-6270/xopco/common/tools/xopco-common-tools-fdeploy/7.0.0-SNAPSHOT/maven-metadata.xml
        #https://nexus.prod.cloud.fedex.com:8443/nexus/repository/SEFS-6270/xopco/common/tools/xopco-common-tools-fdeploy/7.0.0-SNAPSHOT/maven-metadata.xml
        self.assertEqual('https://nexus.prod.cloud.fedex.com:8443/nexus/repository/SEFS-6270/xopco/common/tools/xopco-common-tools-fdeploy/7.0.0-SNAPSHOT/maven-metadata.xml',
            self.resolver._get_meta_data_snapshot_url(gav,'default',NEXUSv3))
        gav=fdeploy.gavClass({'gav' : 'a:b:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        gav.version = '1.3.0-SNAPSHOT'
        self.assertEqual('http://localhost/nexus/service/local/repo_groups/public/content/a/b/1.3.0-SNAPSHOT/maven-metadata.xml',
            self.resolver._get_meta_data_snapshot_url(gav,'default','http://localhost'))
        self.assertEqual('file:///localhost/a/b/1.3.0-SNAPSHOT/maven-metadata.xml',
            self.resolver._get_meta_data_snapshot_url(gav,'default','file:///localhost'))
        gav.version = '1.3.0'
        # fails since we cannot go out unless local wevbsever is running
        with self.assertRaises(Exception):
            self.assertEqual('http://localhost/nexus/service/local/repo_groups/public/content/a/b/maven-metadata.xml',
                self.resolver._get_meta_data_snapshot_url(gav,'default','http://localhost'))
        # self.assertEqual('file:///localhost/a/b/maven-metadata.xml',
        #     self.resolver._get_meta_data_snapshot_url(gav,'default','file:///localhost'))
        # self.assertEqual('http://nexus.prod.fedex.cloud.com:8443/nexus/service/local/repo_groups/public/content/a/b/maven-metadata.xml',
        #     self.resolver._get_meta_data_snapshot_url(gav,'default','http://nexus.prod.fedex.cloud.com:8443'))


    def test_get_download_url(self):
        #clz.options['nexusURL']
        gav=fdeploy.gavClass({'gav' : 'a:b:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        gav.version = '1.3.0'
        self.assertEqual('https://nexus.prod.cloud.fedex.com:8443/nexus/repository/SEFS-6270/a/b/1.3.0/b-1.3.0.jar',
            self.resolver.get_download_url_artifact(gav,'public','http://nexus.prod.fedex.com:8443')[0])

        gav=fdeploy.gavClass({'gav' : 'a:b:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        gav.version = '1.3.0-SNAPSHOT'

        self.assertEqual('file://%s/local/a/b/1.3.0-SNAPSHOT/b-1.3.0-SNAPSHOT.jar' % (self.cwd)  ,
            self.resolver.get_download_url_artifact(gav,'default', self.options['nexusURL'])[0])

        gav=fdeploy.gavClass({'gav' : 'a:b:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        gav.version = '1.3.0-SNAPSHOT'
        self.assertEqual('file://%s/local/a/b/maven-metadata.xml' % (self.cwd)  ,
            self.resolver.get_download_url_metadata(gav,'default', self.options['absURL'])[0])

        self.assertEqual('file://%s/a/b/maven-metadata.xml' % (self.options['absURL'])  ,
            self.resolver.get_download_url_metadata(gav,'default',self.options['absURL'])[0])

        with self.assertRaises(Exception):
            # should be able to test this withj a local webserver running.
            self.assertEqual('http://localhost/nexus/service/local/repo_groups/public/content/a/b/1.3.0-SNAPSHOT/b-1.3.0-20180727.065118-2.jar',
                self.resolver.get_download_url_artifact(gav,'default','http://localhost')[0])

        gav.version='2.4.0'
        self.assertEqual('%s/nexus/repository/SEFS-6270/a/b/2.4.0/b-2.4.0.jar' % (NEXUSv3),
            self.resolver.get_download_url_artifact(gav,'public',NEXUSv3)[0])
        gav.repoName = None
        self.assertEqual('%s/nexus/repository/SEFS-6270/a/b/maven-metadata.xml' % (NEXUSv3),
            self.resolver.get_download_url_metadata(gav,'default',NEXUSv3)[0])

        gav=fdeploy.gavClass({'gav' : 'xopco.common.tools:sefs-parent-lightweight:1.0.0:pom', 'repoName' : 'SEFS-6270', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('%s/nexus/repository/SEFS-6270/xopco/common/tools/sefs-parent-lightweight/1.0.0/sefs-parent-lightweight-1.0.0.pom' % (NEXUSv3),
            self.resolver.get_download_url_artifact(gav,'SEFS-6270',NEXUSv3)[0])
        self.assertEqual('%s/nexus/repository/SEFS-6270/xopco/common/tools/sefs-parent-lightweight/maven-metadata.xml' %(NEXUSv3),
            self.resolver.get_download_url_metadata(gav,'SEFS-6270',NEXUSv3)[0])

        # SNAPSHOTZ

    def test_resolve_3(self):
        mani = fdeploy.manifestResolver('../../test/resources','LZ')
        self.resolver.set_manifest_resolver(mani)
        gav=fdeploy.gavClass({'gav' : 'a:a:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('a', self.resolver.resolve(gav,None).artifactId)
        self.assertEqual('a', self.resolver.resolve(gav,None).groupId)
        self.assertEqual('1.3.0', self.resolver.resolve(gav,None).version)
        gav=fdeploy.gavClass({'gav' : 'a:b:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.0-SNAPSHOT', self.resolver.resolve(gav,None).version)
        gav=fdeploy.gavClass({'gav' : 'a:c:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.1', self.resolver.resolve(gav,None).version)
        gav=fdeploy.gavClass({'gav' : 'a:e:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.2.MASTER', self.resolver.resolve(gav,None).version)
        #
        gav=fdeploy.gavClass({'gav' : 'a:b:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.0', self.resolver.resolve(gav,'1.3').version)
        # hard coded
        self.assertEqual('1.3.0', self.resolver.resolve(gav,'1.4').version)
        # non existing maj min
        gav=fdeploy.gavClass({'gav' : 'a:b:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.4', self.resolver.resolve(gav,'1.4').version)

    def test_resolve_version(self):
        gav=fdeploy.gavClass({'gav' : 'a:f:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        mani = fdeploy.manifestResolver('../../test/resources','LZ')
        self.resolver.set_manifest_resolver(mani)
        # resolved from manifest but does not exist
        #self.assertEqual(None, self.resolver.resolve(gav).version)
        # resolved from majmir
        gav.version = None
        self.assertEqual('3.3.0', self.resolver.what_is_the_next_version_base(gav,'3.3').version)
        gav.version = None
        self.assertEqual('3.2', self.resolver.what_is_the_next_version_base(gav,'3.2').version)
        gav.version = None
        self.assertEqual('3.4.0', self.resolver.what_is_the_next_version_base(gav,'3.4').version)
        # resolved from majmin not existing in manifest
        gav.version = None
        self.assertEqual('1.4', self.resolver.what_is_the_next_version_base(gav,'1.4').version)
        # resolved from majmin not existing in manifest
        gav.version = None
        self.assertEqual('1.4', self.resolver.what_is_the_next_version_base(gav,'1.4.2.MASTER').version)
        gav.version = '1.4'
        self.assertEqual('1.4', self.resolver.what_is_the_next_version_base(gav,'1.4.2.MASTER').version)

    def test_traverse_versions(self):
        l = ['1.1.1','1.1.5','1.1.6-SNAPSHOT','1.2.0','1.2.0-SNAPSHOT','1.2.1-SNAPSHOT','1.2.1','1.2.2','1.2.3-SNAPSHOT']
        gav=fdeploy.gavClass({'gav' : 'a:f:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEquals('1.2.2', self.resolver._traverse_versions(l,'1.2',gav))
        self.assertEquals(None, self.resolver._traverse_versions(l,'1.3',gav))
        self.assertEquals(None, gav.has_no_releases)

        gav=fdeploy.gavClass({'gav' : 'a:f:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEquals('1.1.5', self.resolver._traverse_versions(l,'1.1',gav))

    #def test_traverse_versions_2(self):
        r = self.resolver
        l = ['1.0.0-SNAPSHOT', '1.0.6', '1.0.7-SNAPSHOT', '1.0.7']
        gav = reset()
        self.assertEquals(None, r.version_exists(l,'1.1-SNAPSHOT',gav))
        gav = reset()
        self.assertEquals(None, r.find_closest_version(l,'1.1-SNAPSHOT',gav))
        gav = reset()
        #self.assertEquals('1.1.0-SNAPSHOT', r.find_next_base_for_calculation(l,'1.1-SNAPSHOT',gav))

        gav = reset()
        self.assertEquals('1.0.0-SNAPSHOT', r.version_exists(l,'1.0.0-SNAPSHOT',gav))
        gav = reset()
        # self.assertEquals('1.0.7', r.find_next_base_for_calculation(l,'1.0.0',gav))
        # gav = reset()
        # self.assertEquals('1.0.7', r.find_next_base_for_calculation(l,'1.0',gav))
        #
        # gav=fdeploy.gavClass({'gav' : 'a:f:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        # gav = reset()
        # gav=fdeploy.gavClass({'gav' : 'a:f:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        # self.assertEquals('1.0.0-SNAPSHOT', r._traverse_versions(l,'1.0.0',gav))
        # gav = self.reset()
        # self.assertEquals('1.0.0-SNAPSHOT', r._traverse_versions(l,'1.0.0',gav, True, True))

    def test_resolve_from_manifest(self):

        # nothing available
        #self.assertEqual('0.0.0', self.resolver.get_artifact_version_from_manifest(None,None))
        mani = fdeploy.manifestResolver('../../test/resources','LZ')
        self.resolver.set_manifest_resolver(mani)
        gav=fdeploy.gavClass({'gav' : 'a:z:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual(None, self.resolver.get_artifact_version_from_manifest(gav.artifactId))
        with self.assertRaises(Exception):
            gav=fdeploy.gavClass({'gav' : 'a:z:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
            self.assertEqual(None, self.resolver.resolve_from_manifest(gav).version)
        #
        gav=fdeploy.gavClass({'gav' : 'a:e:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.2.MASTER', self.resolver.get_artifact_version_from_manifest(gav.artifactId))
        gav=fdeploy.gavClass({'gav' : 'a:e:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.2.MASTER', self.resolver.resolve_from_manifest(gav).version)

        #
        gav=fdeploy.gavClass({'gav' : 'a:a:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.0', self.resolver.get_artifact_version_from_manifest(gav.artifactId))
        gav=fdeploy.gavClass({'gav' : 'a:a:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.0', self.resolver.resolve_from_manifest(gav).version)
        #
        #
        gav=fdeploy.gavClass({'gav' : 'a:b:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.0-SNAPSHOT', self.resolver.get_artifact_version_from_manifest(gav.artifactId))
        gav=fdeploy.gavClass({'gav' : 'a:b:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.0-SNAPSHOT', self.resolver.resolve_from_manifest(gav).version)

        #
        gav=fdeploy.gavClass({'gav' : 'a:c:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.1', self.resolver.get_artifact_version_from_manifest(gav.artifactId))
        gav=fdeploy.gavClass({'gav' : 'a:c:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.1', self.resolver.resolve_from_manifest(gav).version)

        #
        gav=fdeploy.gavClass({'gav' : 'a:d:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.1*', self.resolver.get_artifact_version_from_manifest(gav.artifactId))
        # metadata does not have 1.3.1 only 6.0.0-SNAPSHOT
        gav=fdeploy.gavClass({'gav' : 'a:d:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual(None, self.resolver.resolve_from_manifest(gav).version)
        # resolve base vers
        gav=fdeploy.gavClass({'gav' : 'a:d:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('6.0.0', self.resolver.what_is_the_next_version_base(gav,'6.0').version)

        #
        gav=fdeploy.gavClass({'gav' : 'a:g:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.1*', self.resolver.get_artifact_version_from_manifest(gav.artifactId))
        # metadata does not have 1.3.1 only 6.0.0-SNAPSHOT
        gav=fdeploy.gavClass({'gav' : 'a:g:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.1', self.resolver.resolve_from_manifest(gav).version)

        #
        gav=fdeploy.gavClass({'gav' : 'a:e:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.2.MASTER', self.resolver.get_artifact_version_from_manifest(gav.artifactId))
        gav=fdeploy.gavClass({'gav' : 'a:e:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.3.2.MASTER', self.resolver.resolve_from_manifest(gav).version)


    def test_resolve_from_manifest2(self):
        mani = fdeploy.manifestResolver('../../test/resources','L1')
        self.resolver.set_manifest_resolver(mani)
        #
        gav=fdeploy.gavClass({'gav' : 'a:h:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.5.10.1', self.resolver.get_artifact_version_from_manifest(gav.artifactId))
        gav=fdeploy.gavClass({'gav' : 'a:h:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.5.10.1', self.resolver.resolve_from_manifest(gav).version)
        gav=fdeploy.gavClass({'gav' : 'a:h:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.5.10.1', self.resolver.what_is_the_next_version_base(gav,'1.5.10').version)

        # exact copy of manifest.mf
        gav=fdeploy.gavClass({'gav' : 'a:i:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.0.7-SNAPSHOT', self.resolver.get_artifact_version_from_manifest(gav.artifactId))
        gav=fdeploy.gavClass({'gav' : 'a:i:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        with self.assertRaises(Exception):
            self.assertEqual('1.0.7-SNAPSHOT', self.resolver.get_artifact_version_from_manifest(gav.artifactId+"0"))

        gav=fdeploy.gavClass({'gav' : 'a:i:1.0.7:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.0.7', self.resolver.resolve_from_manifest(gav).version)
        gav=fdeploy.gavClass({'gav' : 'a:i:1.0.5:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEquals('1.0.5', gav.version)
        self.assertEqual('1.0.5', self.resolver.resolve_from_manifest(gav, False).version)
        with self.assertRaises(Exception):
            self.assertEqual('1.0.5', self.resolver.resolve_from_manifest(gav, True).version)
        gav=fdeploy.gavClass({'gav' : 'a:i:1.0.5:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.0.5', self.resolver.what_is_the_next_version_base(gav,'1.0').version)
        gav=fdeploy.gavClass({'gav' : 'a:i:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.0.7', self.resolver.what_is_the_next_version_base(gav,'1.0').version)
        gav=fdeploy.gavClass({'gav' : 'a:i:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.0.7', self.resolver.what_is_the_next_version_base(gav,'1.0').version)

        #fdeploy.log()

        gav=fdeploy.gavClass({'gav' : 'a:i:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual(None, self.resolver.does_version_exist_in_nexus(gav,'1.1-SNAPSHOT').version)
        gav=fdeploy.gavClass({'gav' : 'a:i:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual('1.1', self.resolver.what_is_the_next_version_base(gav,'1.1-SNAPSHOT').version)
        gav=fdeploy.gavClass({'gav' : 'a:i:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        self.assertEqual(None, self.resolver.what_is_the_closest_base(gav,'1.1-SNAPSHOT').version)


    def test_gav_class_resolve_major_minor_x(self):
        # resolving dashboard-web 4.0 to 4.0.0
        gav=fdeploy.gavClass({'gav' : 'com.fedex.sefs.dashboard:dashboard-web:jar', 'repoName' : 'public', 'saveArchiveName' : 'maven-model.zip' })
        #
        self.assertEqual('com.fedex.sefs.dashboard', gav.groupId)
        self.assertEqual('dashboard-web', gav.artifactId)
        self.assertEqual('4.0.0', self.resolver.resolve(gav,'4.0').version)

    def test_gav_class_resolve_snapshot_only(self):
        mani = fdeploy.manifestResolver('../../test/resources','L1')
        self.resolver.set_manifest_resolver(mani)

        # resolving dashboard-web 4.0 to 4.0.0
        gav=fdeploy.gavClass({'gav' : 'com.fedex.ground.sefs:fxg-core-cacheservice-duplicatecheck:zip', 'repoName' : 'public', 'saveArchiveName' : 'model.zip' })
        #
        self.assertEqual('com.fedex.ground.sefs', gav.groupId)
        self.assertEqual('fxg-core-cacheservice-duplicatecheck', gav.artifactId)
        self.resolver.resolve(gav, '3.0')
        # as listed in the manifest
        self.assertEqual('3.0', gav.version)
        gav.version = None
        # find the latest 4.0 (irregardles of the manifest)
        gav.version = None
        self.assertEqual('4.0.7', self.resolver.resolve(gav, '4.0').version )
        # from the maniifest
        gav.version = '4.1.5' # hardcoded
        self.assertEqual('4.1.5', self.resolver.resolve(gav).version )
        gav.version = None
        self.assertEqual('4.0.5', self.resolver.resolve(gav).version )
        # from hardcoded
        gav.version = '4.X.Y.Z'
        self.assertEqual('4.X.Y.Z', self.resolver.resolve(gav).version )
        # preset to majonir
        gav.artifactId = "x%s2" % (gav.artifactId)
        gav.version = None
        self.assertEqual(None, self.resolver.resolve(gav, '4.0').version)
        gav.version = None
        with self.assertRaises(Exception):
            self.assertEqual(None, self.resolver.resolve(gav).version)

    def test_resolve_method(self):
        self.resolver = fdeploy.nexusVersionResolver(self.options, manifestResolver=self.mani)
        gav=fdeploy.gavClass({'gav' : 'com.fedex.sefs.common:sefs-parent:pom', 'repoName' : 'public', 'saveArchiveName' : 'pom-model.zip' })
        #print "reslove:", self.resolver.resolve(gav,'1.1')
        gav.version=None
        self.assertEqual('1.0.5',self.resolver.resolve(gav,'1.0').version)
        gav.version=None
        self.assertEqual('0.0.1',self.resolver.resolve(gav,'0.0').version)
        gav.version=None
        self.assertEqual('1.1.0',self.resolver.resolve(gav,'1.1').version)

    def test_resolve_method_no_released_items_yet(self):
        self.resolver = fdeploy.nexusVersionResolver(self.options, manifestResolver=self.mani)
        gav=fdeploy.gavClass({'gav' : 'com.fedex.sefs.common:sefs-parent:pom', 'repoName' : 'public', 'saveArchiveName' : 'pom-model.zip' })
        self.assertEqual('1.1.0',self.resolver.resolve(gav,'1.1').version)

        self.resolver = fdeploy.nexusVersionResolver(self.options, manifestResolver=self.mani)
        gav=fdeploy.gavClass({'gav' : 'com.fedex.sefs.common:sefs-parent:pom', 'repoName' : 'public', 'saveArchiveName' : 'pom-model.zip' })
        self.assertEqual('0.0.1',self.resolver.resolve(gav,'0.0').version)


    def test_resolve_method_snapshots_metadata(self):
        self.resolver = fdeploy.nexusVersionResolver(self.options, manifestResolver=self.mani)
        gav=fdeploy.gavClass({'gav' : 'com.fedex.ground.sefs.:ShipmentGatewayFXG:pom', 'repoName' : 'public', 'saveArchiveName' : 'bom-model.zip' })
        self.assertEqual('3.3.0',self.resolver.resolve(gav,'3.3').version)


    def test_cloudbees_get_base_number_maj_min(self):
        nexusresolver = fdeploy.nexusVersionResolver(self.options)

        self.assertEquals('2.0',nexusresolver.get_base_number('2')[0])
        self.assertEquals('2.0',nexusresolver.get_base_number('2')[0])
        self.assertEquals('2.1',nexusresolver.get_base_number('2.1')[0])
        self.assertEquals('2.1',nexusresolver.get_base_number('2.1.1')[0])
        self.assertEquals('2.1.1',nexusresolver.get_base_number('2.1.1.2')[0])
        self.assertEquals('ABC.2',nexusresolver.get_base_number('ABC.2')[0])
        self.assertEquals('2.1.1',nexusresolver.get_base_number('2.1.1.2.AND')[0])
        self.assertEquals('3.0',nexusresolver.get_base_number('R-3.0.0.Master')[0])
        self.assertEquals('1.5.10',nexusresolver.get_base_number('1.5.10.0-SNAPSHOT')[0])
        self.assertEquals('2.1',nexusresolver.get_base_number('2.1.0-SNAPSHOT',True)[0])

    def test_cloudbees_get_current_version(self):
        nexusresolver = fdeploy.nexusVersionResolver(self.options)
        self.assertEquals('2.0.0',nexusresolver.get_base_number('2',False)[0])
        self.assertEquals('2.1.0',nexusresolver.get_base_number('2.1',False)[0])
        self.assertEquals('2.1.1',nexusresolver.get_base_number('2.1.1',False)[0])
        self.assertEquals('2.1.1.2',nexusresolver.get_base_number('2.1.1.2',False)[0])
        self.assertEquals('ABC.2',nexusresolver.get_base_number('ABC.2',False)[0])
        self.assertEquals('2.1.1.2',nexusresolver.get_base_number('2.1.1.2.AND',False)[0])
        self.assertEquals('3.0.0',nexusresolver.get_base_number('R-3.0.0.Master',False)[0])
        self.assertEquals('1.5.10.0',nexusresolver.get_base_number('1.5.10.0-SNAPSHOT',False)[0])

    def test_resolveGavs(self):
        resolver = fdeploy.nexusVersionResolver(self.options)
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.digest('../../test/resources/fxg-pd-domainview.json', None)
        resolver.resolveGavs(fdl.components[0])

    # def tst_parse_metadata_release(self):
    #     nexusresolver = fdeploy.nexusVersionResolver(self.options)
    #     mani = fdeploy.manifestResolver('../../test/resources','L1')
    #     nexusresolver.set_manifest_resolver(mani)
    #
    #     with open('../../test/resources/local/com/fedex/ground/sefs/ShipmentGatewayFXG/maven-metadata.xml', 'r') as file:
    #         pom_content = file.read()
    #         gav=fdeploy.gavClass({'gav' : 'com.fedex.ground.sefs.:ShipmentGatewayFXG:pom', 'repoName' : 'public', 'saveArchiveName' : 'bom-model.zip' })
    #         tuple = nexusresolver.version_metadata(pom_content, gav, '3.3')
    #         self.assertEqual('3.3.0', tuple)
    #         gav.version = None
    #         nexusresolver = nexusresolver.resolve(gav)

    def test_parse_metadata_release_refactored(self):
        nexusresolver = fdeploy.nexusVersionResolver(self.options)
        mani = fdeploy.manifestResolver('../../test/resources','L1')
        nexusresolver.set_manifest_resolver(mani)

        with open('../../test/resources/local/com/fedex/ground/sefs/ShipmentGatewayFXG/maven-metadata.xml', 'r') as file:
            pom_content = file.read()
            gav=fdeploy.gavClass({'gav' : 'com.fedex.ground.sefs.:ShipmentGatewayFXG:pom', 'repoName' : 'public', 'saveArchiveName' : 'bom-model.zip' })
            tuple = nexusresolver.what_is_the_next_version_base(gav, '3.3')
            self.assertEqual('3.3.0', tuple.version)
            gav.version = None
            nexusresolver.resolve(gav)

    #
    # def tst_parse_metadata_snapshosts(self):
    #     nexusresolver = fdeploy.nexusVersionResolver(self.options)
    #     mani = fdeploy.manifestResolver('../../test/resources','L1')
    #     nexusresolver.set_manifest_resolver(mani)
    #     gav=f9j k [9p vuv p0[8 -vby5cr98c tvdeploy.gavClass({'gav' : 'com.fedex.sefs.common:sefs-parent:pom', 'repoName' : 'public', 'saveArchiveName' : 'bom-model.pom' })
    #
    #     pom_content =""
    #     with open('../../test/resources/local/com/fedex/sefs/common/sefs-parent/maven-metadata.xml', 'r') as file:
    #         pom_content = file.read()
    #     tuple = nexusresolver.version_metadata(pom_content, gav, '0.0.1')
    #     self.assertEqual('0.0.1', tuple)
    #     gav.version = None
    #     gav = nexusresolver.resolve(gav)
    #
    #     tuple = nexusresolver.version_metadata(pom_content, gav, '1.0')
    #     self.assertEqual('1.0.5', tuple)
    #
    #     tuple = nexusresolver.version_metadata(pom_content, gav, '1.0')
    #     self.assertEqual('1.0.5', tuple)

    def test_parse_metadata_snapshosts_refactored(self):
        nexusresolver = fdeploy.nexusVersionResolver(self.options)
        mani = fdeploy.manifestResolver('../../test/resources','L1')
        nexusresolver.set_manifest_resolver(mani)
        gav=fdeploy.gavClass({'gav' : 'com.fedex.sefs.common:sefs-parent:pom', 'repoName' : 'public', 'saveArchiveName' : 'bom-model.pom' })

        pom_content =""
        with open('../../test/resources/local/com/fedex/sefs/common/sefs-parent/maven-metadata.xml', 'r') as file:
            pom_content = file.read()
        tuple = nexusresolver.what_is_the_next_version_base(gav, '0.0.1')
        self.assertEqual('0.0.1', tuple.version)
        gav.version = None
        gav = nexusresolver.resolve(gav)

        gav.version = None
        tuple = nexusresolver.what_is_the_next_version_base( gav, '1.0')
        self.assertEqual('1.0.5', tuple.version)

        gav.version = None
        tuple = nexusresolver.what_is_the_next_version_base( gav, '1.0')
        self.assertEqual('1.0.5', tuple.version)

    def test_download(self):
        pass

    def test_semantic_compare(self):
        v1 = '1.2.3'
        self.assertEquals(v1, semantic_compare(v1,'0.0.1'))
        self.assertEquals(v1, semantic_compare(v1,'0.0.1.14'))
        self.assertEquals(v1, semantic_compare(v1,'1.1.4'))
        self.assertEquals('1.2.4', semantic_compare(v1,'1.2.4'))
        self.assertEquals('1.2.3', semantic_compare(v1,'1.2.3'))
        self.assertEquals('1.2.3.4', semantic_compare(v1,'1.2.3.4'))
        self.assertEquals('1.2.3.4', semantic_compare(v1,'1.2.3.4'))

if __name__ == '__main__':
    unittest.main()
