import unittest2
import fdeploy
import codecs
from fdeploy import Options
from fdeploy.platform.bash_pcf_generator import pcfGenerator
from fdeploy.UtilsForTesting import AbstractTestCase
import os

component = fdeploy.fdeployComponent({

    "type": "pcf",
    "rtv": [{
        "name": "APP_NM",
        "value": "trip-proxy"
    },
        {
        "name": "EAI_NUMBER",
        "value": "3534546"
    },
        {
        "name": "NUM_INSTANCES",
        "value": "1"
    },
        {
        "name": "SERVICE_INSTANCES",
        "value": "1"
    },
        {
        "name": "APPD_NM",
        "value": "sefs-trip-proxy"
    },
        {
        "name": "LOG_LEVEL",
        "value": "1"
    },
        {
        "name": "SPRING_PROFILES_ACTIVE",
        "value": "L1"
    },
        {
        "name": "PAM_ID",
        "value": "18414"
    },
        {
        "name": "DISCOVERY_SERVICE",
        "value": "trip-discovery-service"
    }
    ],
    "levels": [{
        "rtv": [],
        "level": "L1",
        "targets": [
            "development@api.sys.wtcdev2.paas.fedex.com"
        ]
    }, {
        "rtv": [],
        "level": "L2",
        "targets": [
            "development@api.sys.wtcdev2.paas.fedex.com"
        ]
    },
        {"rtv": [],
         "level": "L3",
         "targets": [
            "release@api.sys.wtcdev2.paas.fedex.com"
        ]
    },
        {
        "rtv": [],
        "level": "PROD",
        "targets": [
            "production@api.sys.edcbo1.paas.fedex.com"
        ]
    }],
    "content": [{
        "gav": "com.fedex.sefs.core.trip:trip-proxy:1.0.3:jar",
        "saveArchiveName": "pmi-web.jar"
    }],
    "id": "trip-proxy",
    "name_format": "PCF_SEFS_TRIP_PROXY_%0d",
    "platform": "bash_generator"

}, 'inline.json')


class TestPlaformPcfGenerator(AbstractTestCase):

    options = None

    rtvs = [
        {'name': 'APP_REF', 'value': '${APPMANAGE_PLAN}.backupt'},
        {'name': 'LEVEL', 'value': 'L1'}]

    def setUp(self):
        self.options = Options(command='deploy', action='stage', identity='.',
                               X=True, id=None, path=".", no_wait=False, level='L1', user='sefs')

    def tearDown(self):
        try:
            fdeploy.logLevel = fdeploy.Priority.ERROR
            pass
        except OSError:
            pass

    def test_generate(self):
        generator = pcfGenerator(component, self.options)
        targets = ["release@api.sys.wtcdev2.paas.fedex.com"]
        fdeploy.logLevel = fdeploy.Priority.TRACE
        struct = {'level': {'level': 'L1', 'rtv': self.rtvs}, 'directory': '.',
                  'contents': component.content, 'targets': targets,  'uuid': 'all'}
        with open("platform-pcf.txt", "w") as fh:
            generator.generate(struct, fh)
        was = self.load_file_as_string("platform-pcf.txt")
        expected = self.load_file_as_string(
            "../../test/resources/pcf/platform-pcf-1.txt")
        self.assertlines(expected, was, False)


if __name__ == '__main__':
    unittest.main()
