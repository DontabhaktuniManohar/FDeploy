# -*- coding: utf-8 -*-
import unittest2
import os
import fdeploy
import re
import sys
from fdeploy.platform.pcf import cupsAppdClass, cupsCredentialsClass, cupsJmsProviderClass,\
    cupsConfigVariableClass, cupsDatabaseServiceClass, cupsGitConfigServerClass,\
    cupsConfigVariableClass, cupsUriClass, cupsSplunkClass
from fdeploy.platform.bash_pcf_cups_generator import pcfCupsGenerator
from fdeploy.platform import assertLines, load_file
import filecmp

class TestPlatformCups(unittest2.TestCase):

    options = {'action': 'install', 'user' : 'pcf'}

    def test_cups_appd(self):
        a = cupsCredentialsClass({'service_name': 'name', 'type': 'Credentials', 'username' : 'uzer', 'password' : 'pazzword'})
        self.assertEqual('cf create-service appdynamics \'name\' \'trip-test\'',
                         a.toCommand(''))

    def test_cups_appd(self):
        a = cupsAppdClass({'service_name': 'name', 'domain': 'trip-test'})
        self.assertEqual('cf create-service appdynamics \'name\' \'trip-test\'',
                         a.toCommand(''))

    def test_cups_splunk(self):
        a = cupsSplunkClass({'service_name': 'name', 'domain': 'trip-test'})
        self.assertEqual('cf create-service splunk \'name\' \'trip-test\'',
                         a.toCommand(''))

    def test_cups_git_config(self):
        a = cupsGitConfigServerClass(
            {'service_name': 'name', 'git-url': 'https://gitlab.prod.fedex.com/APP3534546/trip-config-repo.git', 'access-token': 'fES2CPKJc4mAoD-YUQSL'})
        self.assertEqual('cf cups config-server-details -p \'{"access-token": "fES2CPKJc4mAoD-YUQSL",\
 "git-url": "https://gitlab.prod.fedex.com/APP3534546/trip-config-repo.git"}\'',
                         a.toCommand(''))

    def test_cups_config_var(self):
        a = cupsConfigVariableClass(
            {'service_name': 'name', 'value': 'https://gitlab.prod.fedex.com/APP3534546/trip-config-repo.git'})
        self.assertEqual('cf cups domain-config -p \'{"domain-name": "https://gitlab.prod.fedex.com/APP3534546/trip-config-repo.git"}\'',
                         a.toCommand(''))

    def test_cups_uri(self):
        os.environ['level'] = 'L3'
        a = cupsUriClass({'service_name': '${level}-trip-discovery-service',
                          'uri': 'https://l3-trip-discovery-server.app.wtcdev2.paas.fedex.com/eureka'})
        self.assertEqual('cf cups L3-trip-discovery-service -p \'{"uri": "https://l3-trip-discovery-server.app.wtcdev2.paas.fedex.com/eureka"}\'',
                         a.toCommand(''))

    def test_cups_jms_provider(self):
        os.environ['level'] = 'L3'
        a = cupsJmsProviderClass({'service_name': 'JMS-Outbound', 'type': 'JmsProvider',
                                  'context_factory': 'com.fedex.mi.decorator.jms.FedexTibcoInitialContext',
                                  'connection_factory': 'fxClientUID=S.3534641.FDXSHIPEFS.FXE.INTERNAL.CORE.T.L3',
                                  'username': 'SEFS-ORCHE-3534641',
                                  'password':  'KVE2rejEzabSzwUem4bYQRR9g',
                                  'provider_url': 'ldap://apptstldap.corp.fedex.com:389/ou=messaging,dc=corp,dc=fedex,dc=com'})
        self.assertEqual('cf cups L3-JMS-Outbound -p \'{\
"username": "SEFS-ORCHE-3534641", \
"connection-factory": "fxClientUID=S.3534641.FDXSHIPEFS.FXE.INTERNAL.CORE.T.L3", \
"password": "KVE2rejEzabSzwUem4bYQRR9g", \
"context-factory": "com.fedex.mi.decorator.jms.FedexTibcoInitialContext", \
"provider-url": "ldap://apptstldap.corp.fedex.com:389/ou=messaging,dc=corp,dc=fedex,dc=com"\
}\'', a.toCommand(''))

    def test_cups_database_service(self):
        os.environ['level'] = 'L4'
        a = cupsDatabaseServiceClass({'service_name': 'Database-Details', 'type': 'DatabaseService',
                                    'url': 'jdbc:oracle:thin:@ldap://oid.inf.fedex.com:3060/SEFS_ORCH_SVC1_L1,cn=OracleContext',
                                      'username': 'SEFS_ORCH_SCHEMA',
                                      'password':  'sefsMSpwd0123456789101112',
                                      'driver_class_name': 'oracle.jdbc.driver.OracleDriver'})
        self.assertEqual('cf cups L4-Database-Details -p \'{"url": "jdbc:oracle:thin:@ldap://oid.inf.fedex.com:3060/SEFS_ORCH_SVC1_L1,cn=OracleContext", \
"username": "SEFS_ORCH_SCHEMA", \
"driver-class-name": "oracle.jdbc.driver.OracleDriver", \
"password": "sefsMSpwd0123456789101112"}\'\
', a.toCommand(''))

    def test_integration(self):
        result='''{"UserName": "FXSapp_354105", "Password": "bogus", "Role": "USER"}
cf cups L3-L3_JMS_outbound_staging -p '{"username": "FXSapp_354105", "connection-factory": "fxClientUID=S.L3", "password": "bogus", "context-factory": "com.fedex.jms.", "provider-url": "tcp://"}'
{"UserName": "FXSapp_354105", "Password": "bogus", "Role": "USER"}
cf cups config-server-details -p '{"access-token": "fES2CPKJc4mAoD-YUQSL", "git-url": "https://gitlab.prod.fedex.com/APP3534545/handling-unit-config-repo.git"}'
cf cups domain-config -p '{"domain-name": "Trip"}'
cf cups L3-handling-unit-discovery-service -p '{"uri": "https://L3-handling-unit-discovery-server.app.wtcdev2.paas.fedex.com/eureka"}'
cf create-service appdynamics 'AppD-handling-unit' 'fedex1-test'
cf create-service splunk 'AppD-handling-unit' 'fedex1-test'
cf cups L3-L3-Database-Details -p '{"url": "jdbc:oracle:thin:@ldap://oid.inf.fedex.com:3060/SEFS_ORCH_SVC1_L1,cn=OracleContext", "username": "dbuser", "driver-class-name": "oracle.jdbc.driver.OracleDriver", "password": "!TOKEN"}'
'''
        fdeploy.log()
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(
            ['../../test/resources/pcf-config/pcf-cups-config.json'])
        component = fdl.components[0]
        print "%s" % (component.levels[0]['targets'])
        testcommand = fdeploy.platform.bash_pcf_cups_generator.pcfCupsGenerator(
            component, self.options)
        with open('test.txt','w') as outp:
            testcommand.generate({'level' : component.levels[0], 'targets' : component.levels[0]['targets']},outp)
        self.assertTrue(os.path.exists('test.txt'))
        self.assertTrue(os.path.exists('../../test/resources/pcf/cups.out'))
        #
        l=load_file('./test.txt')
        k=load_file('./../../test/resources/pcf/cups.out')
        #
        # print "l=%s" % (l)
        # print "k=%s" % (k)

        # self.assertEquals(len(l), len(k))
        self.assertTrue(filecmp.cmp('./test.txt', '../../test/resources/pcf/cups.out'))
