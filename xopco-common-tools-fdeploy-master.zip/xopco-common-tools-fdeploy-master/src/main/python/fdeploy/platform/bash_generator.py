# -*- coding: utf-8 -*-

import os
import re
import sys
import glob
import subprocess
import fdeploy
import fdeploy.platform
import itertools
import time
from fdeploy.platform import load_snippet
from fdeploy.platform.bash_java_generator import javaGenerator, javaDeployer
from fdeploy.platform.bash_tibcoas_generator import tibco_asGenerator, tibco_asDeployer
from fdeploy.platform.bash_tibcoasleech_generator import tibco_asleechGenerator, tibco_asleechDeployer
from fdeploy.platform.bash_tibcobe_generator import tibco_beGenerator, tibco_beDeployer
from fdeploy.platform.bash_tibcobw_generator import tibco_bwGenerator, tibco_bwDeployer
from fdeploy.platform.bash_tibcobw2_generator import tibco_bw2Generator, tibco_bw2Deployer
from fdeploy.platform.bash_tomcat_generator import tomcatGenerator, tomcatDeployer
from fdeploy.platform.bash_pcf_generator import pcfGenerator, pcfDeployer
#from fdeploy.platform.bash_java_sudo_generator import java_sudoGenerator, java_sudoDeployer
from fdeploy.platform.bash_java_auto_generator import java_autoGenerator, java_autoDeployer
from fdeploy.platform.bash_filecopy_generator import filecopyGenerator, filecopyDeployer
