import unittest2
import fdeploy
import codecs
import unicodedata
from fdeploy import Options
from fdeploy.platform.bash_tibcobw2_generator import tibco_bw2Generator
import os

component = fdeploy.fdeployComponent({
    'id': 'componentId',
    'platform': 'bash_generator',
    'type': 'tibco_bw2',
    'rtv': [
        {
            "name": "TRA_HOME",
            "value": "tibcosilver@srh00607.ute.fedex.com:/opt/tibco/silver/persistentdata/FXE/apps/CLEARANCEFeed"
        },
        {
            "name": "JMX_PORT",
            "value": "abcdef"
        },
        {
            "name": "PROCESS_NAME",
            "value": "tibcosilver@srh00607.ute.fedex.com:/opt/tibco/silver/persistentdata/FXE/apps/CLEARANCEFeed"
        },
        {
            "name": "ADMIN_TARGET_URL",
            "value": "tibcosilver@srh00607.ute.fedex.com:/opt/tibco/silver/persistentdata/FXE/apps/CLEARANCEFeed"
        },
        {
            "name": "EAINUMBER",
            "value": "#CLEARANCEFeed"
        },
        {
            "name": "APPMANAGE_CREDENTIALS",
            "value": "#CLEARANCEFeed"
        },
        {
            "name": "EAINUMBER",
            "value": "#CLEARANCEFeed"
        },
        {
            "name": "APPMANAGE_XML",
            "value": "../../test/resources/bw5/FXFShipFeed_template_l2.xml"
        },
        {
            "name": "PROPS_FILE_PATH",
            "value": "../../test/resources/bw5/L1-Auto.properties"
        },
        {
            "name": "APPMANAGE_PLAN",
            "value": "../../test/resources/bw5/FXFShipFeed_plan-descriptors.xml"
        }


    ],
    'content':  [{
        "gav": "com.fedex.sefs.core:sefs_suCLEARANCEFeed:1.0.0:zip",
        "relativePath": "apparchives",
        "saveArchiveName": "sefs_suCLEARANCEFeed.zip"
    }],
    'name_format': 'format',
    'levels':
    [{
        'level': 'L1',
        'filter' : { 'maxHeapSize' : 'value2'},
        'targets' : [ 'a@com', 'b@com', 'c@com']
    }]

}, 'inline.json')


def load_file_as_string(sfile, strip=False):
    snippet_text = ''
    #with open ("snippets/" + snippetFile, "r") as snippet:
    with codecs.open (sfile, "r", "UTF-8") as snippet:
        snippet_text=snippet.read()
    return snippet_text

def remove_control_characters(s):
    return "".join(ch for ch in s if unicodedata.category(ch)[0]!="C").strip()

class TestTibcoBW2Generator(unittest2.TestCase):

    options = None

    rtvs =  [
        { 'name': 'APP_REF', 'value' : '${APPMANAGE_PLAN}.backupt'},
        { 'name': 'LEVEL', 'value' : 'L1'}]


    def setUp(self):
        self.options = Options(command='deploy',action='stage',identity='.', X=True, id = None, path=".", no_wait = False, level='L1',user='sefs')

    def tearDown(self):
        try:
            os.remove('platformBW5-2.txt')
        except OSError:
            pass

    def assertlines(self,generated,expected):
        lines1 = generated[0].split('\n')
        lines2 = expected.split('\n')
        #print "%s" % (generated[0])
        i=1
        for l in lines1:
            l = remove_control_characters(l)
            l2 = remove_control_characters(lines2[i-1])
            if l == "":
                continue
            if l2 == "":
                i+=1
                continue
            #print " lines %s: dont match '%s' vs '%s'" % (i,l,l2)
            self.assertEquals(l,l2, " lines %s: dont match '%s' vs '%s'" % (i,l,l2))
            i+=1

    def test_init(self):
        generator = tibco_bw2Generator(component, self.options)

    def test_generate(self):
        generator = tibco_bw2Generator(component, self.options)
        targets = []
        struct = {'level': {'level':'L1','rtv' : self.rtvs }, 'directory': '.', 'contents': component.content, 'targets': targets,  'uuid': 'all'}
        with open("platformBW5-2.txt", "w") as fh:
            generator.generate(struct, fh)

    #def test_filterChaining(self):
    #    generator = tibco_bw2Generator(component, self.options)
    #    print str(component.rtvMapping)
    #    path=os.path.abspath('../../test/resources/bw5/common.properties')
    #    map=generator.readFilters(path)
    #    self.assertEquals('common', map['value'])
    #    self.assertFalse('my_property' in map)
    #    map=generator.readFilters('../../test/resources/bw5/common.properties,../../test/resources/bw5/L1.properties')
    #    self.assertEquals('my_value', map['my_property'])
        # overwrite
    #    self.assertEquals('L1', map['value'])

        # reverse
     #   map=generator.readFilters('../../test/resources/bw5/L1.properties,../../test/resources/bw5/common.properties')
     #   self.assertEquals('my_value', map['my_property'])
        # overwrite
     #   self.assertEquals('common', map['value'])

        # with level variable.
      #  rtvs=component.rtvMapping
     #   for rtv_pair in self.rtvs:
     #       rtvs[rtv_pair['name']]=rtv_pair['value']
     #   map=generator.readFilters('../../test/resources/bw5/common.properties,../../test/resources/bw5/L1.properties',rtvs)
      #  print "\nmap>>>%s\n" % (map)
      #  self.assertEquals('my_value', map['my_property'])
        # overwrite
     #   self.assertEquals('L1', map['value'])
     #   self.assertEquals('L1_NAME', map['Name'])
     #   self.assertEquals('abcdef', map['jmxport'])
     #   self.assertEquals('../../test/resources/bw5/FXFShipFeed_plan-descriptors.xml.backupt', map['File'])

   # def test_tibcobw2_applyExternalizedBindings(self):
    #    generator = tibco_bw2Generator(component, self.options)
     #   path=os.path.abspath('../../test/resources/bw5/bw52-l1.properties')
    #    map=generator.readFilters(path)
     #   base_prop = os.path.abspath("../../test/resources/bw5/L1-Auto.properties")
     #   __targets = ['TLM1@urh01','TLM2@urh02', 'TLM3@urh03']
     #   configurer = fdeploy.deployer.TibcoBW5Configurer(
     #       '../../test/resources/bw5/FXFShipFeed_template_l2.xml')
     #   deployment_config = generator.update_deployment_desciptor(configurer, __targets, map, 'L1',base_prop)
     #   file = load_file_as_string('../../test/resources/bw5/FXFShipFeed_template_l2_externalized.xml')
      #  self.assertlines(deployment_config, file)
    #def test_tibcobw2_creationplan(self):
     #   generator = tibco_bw2Generator(component, self.options)
     #   path=os.path.abspath('../../test/resources/bw5/bw52-l1.properties')
       # map=generator.readFilters(path)
       # __targets = ['FXE_L0_FXE_BW_TLM_VM1','FXE_L0_FXE_BW_TLM_VM2']
     #   configurer = fdeploy.deployer.TibcoBW5Configurer(
     #       '../../test/resources/bw5/plan-descriptor.xml')
      #  deployment_config = generator.update_plan_desciptor(configurer, __targets,map,'L1')
     #   print(str(deployment_config))
      #  file = load_file_as_string('../../test/resources/bw5/plan-descriptor-out.xml')
      #  self.assertlines(deployment_config, file)



if __name__ == '__main__':
    unittest.main()
