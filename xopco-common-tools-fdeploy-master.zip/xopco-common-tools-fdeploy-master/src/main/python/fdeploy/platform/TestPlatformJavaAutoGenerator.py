import unittest2
import fdeploy
import os
from fdeploy.platform import load_file, assertLines, basePlatformTest
from fdeploy import Options


class TestJavaAutoGenerator(basePlatformTest):

    properties =  '''   # Generating the current properties for this version
   cat <<EOF > "${_target_path}/${_archive_version}.properties"
#!/bin/bash
# Generated property file for application.
export APP_ID="pmi-webber"
export ARTIFACTID="pmi-web"
export EAI_NUMBER="102354"
export GROUPID="com.fedex.ground.pmi"
export JAVA_HOME="/opt/java/whatever/"
export LEVEL="L1"
export LOG_ROOT="/opt/fedex/pmi/dev"
export TMP_DIR="/opt/fedex/pmi/dev/"
export VERSION="0.0.1-SNAPSHOT"

EOF
'''
    properties_overwrite =  '''   # Generating the current properties for this version
   cat <<EOF > "${_target_path}/${_archive_version}.properties"
#!/bin/bash
# Generated property file for application.
export APP_ID="pmi-webber"
export ARTIFACTID="pmi-web"
export EAI_NUMBER="102354"
export ARTIFACTID="pmi-web"
export GROUPID="com.fedex.ground.pmi"
export JAVA_HOME="/opt/fedex/java"
export LEVEL="L1"
export LOG_ROOT="/opt/tmp/var/"
export TMP_DIR="/opt/fedex/pmi/dev/"
export VERSION="0.0.1-SNAPSHOT"

EOF
'''

    def test_properties_creation(self):
        options = Options(command='deploy',action='properties',identity='.',
        X=True, id = None, path=".", no_wait = False, level='L1',
        user='sefs')
        self.assertPropertiesGeneration(options,'java_autoGenerator',
            'JAVA_SCM_PMI_BOOT_%0d',
            '../../test/resources/FXE_fdeploy/scm-java-auto.json')

    def test_properties_creation_with_overwrite(self):
        options = Options(command='deploy',action='properties',identity='.',
        X=True, id = None, path=".", no_wait = False, level='L1',
        user='sefs', rtv=["JAVA_HOME=/opt/fedex/java", "LOG_ROOT=/opt/tmp/var/"])
        self.assertPropertiesGeneration(options,'java_autoGenerator',
            'JAVA_SCM_PMI_BOOT_%0d',
            '../../test/resources/FXE_fdeploy/scm-java-auto.json')




if __name__ == '__main__':
    unittest.main()
