# -*- coding: utf-8 -*-
import codecs
import sys
import os
import re
import json
#import os.path.expandvars

class cupsCredentialsClass(object):

    def __init__(self, content):
        self.service_name = content['service_name']
        self.type = content['type']
        try:
            self.user = content['username']
            self.password = content['password'] if 'password' in content else None
            self.role = content['role'] if 'role' in content else None
            self.vault_token = content['vault_token'] if 'vault_token' in content else None
        except KeyError as k:
            raise Exception(content)

    def toCommand(self, action):
        return os.path.expandvars(
            "cf cups Basic-Security -p '%s'" % (json.dumps({'UserName': self.user, 'Password': self.password, 'Role': self.role})) )


class cupsJmsProviderClass(cupsCredentialsClass):

    def __init__(self, content):
        super(cupsJmsProviderClass, self).__init__(content)
        self.service_name = content['service_name']
        self.provider_url = content['provider_url']
        self.context_factory = content['context_factory']
        self.connection_factory = content['connection_factory']

    def toCommand(self, action):
        return  os.path.expandvars(
        "cf cups ${level}-%s -p '%s'" % (self.service_name, json.dumps(
            {'provider-url' : self.provider_url, 'context-factory' : self.context_factory,
            'username' : self.user, 'password' : self.password, 'connection-factory' : self.connection_factory}
        )))


class cupsGitConfigServerClass(object):

    def __init__(self, content):
        #super(cupsGitConfigServerClass, self).__init__(content)
        self.service_name = content['service_name']
        self.git_url = content['git-url']
        self.access_token = content['access-token']

    def toCommand(self, action):
        return  os.path.expandvars("cf cups config-server-details -p '%s'" % (json.dumps({'git-url': self.git_url, 'access-token': self.access_token})))


class cupsConfigVariableClass(object):

    def __init__(self, content):
        #super(cupsConfigVariableClass, self).__init__(content)
        self.service_name = content['service_name']
        self.value = content['value']

    def toCommand(self, action):
        return  os.path.expandvars("cf cups domain-config -p '%s'" % (json.dumps({'domain-name': self.value})))


class cupsUriClass(object):

    def __init__(self, content):
        #super(cupsAppdClass, self).__init__(content)
        self.service_name = content['service_name']
        self.uri = content['uri']

    def toCommand(self, action):
        return  os.path.expandvars("cf cups %s -p '%s'" % (self.service_name, json.dumps({'uri' : self.uri})))


class cupsAppdClass(object):

    def __init__(self, content):
        self.service_name = content['service_name']
        self.marketplace = 'appdynamics'
        self.domain = content['domain']

    def toCommand(self, action):
        return  os.path.expandvars("cf create-service appdynamics '%s' '%s'" % (self.service_name, self.domain))


class cupsSplunkClass(object):

    def __init__(self, content):
        #super(cupsAppdClass, self).__init__(content)
        self.service_name = content['service_name']
        self.marketplace = 'splunk'
        self.domain = content['domain']

    def toCommand(self, action):
        return  os.path.expandvars("cf create-service splunk '%s' '%s'" % (self.service_name, self.domain))


class cupsDatabaseServiceClass(cupsCredentialsClass):

    def __init__(self, content):
        super(cupsDatabaseServiceClass, self).__init__(content)
        self.service_name = content['service_name']
        self.url = content['url']
        self.driverClass = content['driver_class_name']

    def toCommand(self, action):
        return  os.path.expandvars("cf cups ${level}-%s -p '%s'" % (self.service_name, json.dumps({
            'url' : self.url, 'driver-class-name' : self.driverClass, 'username' : self.user, 'password' : self.password
        })))
