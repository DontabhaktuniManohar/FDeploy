import unittest2
import fdeploy
import os
from fdeploy.platform import load_snippet, baseGenerator


REQUIRED_RTVS = []
REGISTERED_ACTIONS = ['clean', 'wipeout', 'start', 'stop', 'install', 'stage', 'ml', 'machine_list',
        'deploy', 'publish', 'unpublish', 'restart', 'report', 'ssh', 'inspect', 'ps', 'cloudenv','status']

class testGenerator(baseGenerator):
    def __init__(self, component, cli_options):
        self.REGISTERED_ACTIONS =  fdeploy.platform.TestBashGeneratorMethods.REGISTERED_ACTIONS
        self.REQUIRED_RTVS = fdeploy.platform.TestBashGeneratorMethods.REQUIRED_RTVS
        super(testGenerator, self).__init__(
            component, cli_options)

test_component = fdeploy.fdeployComponent({
    'id': 'componentId',
    'platform': 'bash_generator',
    'type': 'tibco_bw2',
    'filter' :
        { "var1" : "value1", "var2" : "value2"}
    ,
    'content':  [{
        "gav": "com.fedex.sefs.core:sefs_suCLEARANCEFeed:zip",
        "relativePath": "${level}/${var1}.sh",
        "saveArchiveName": "sefs_suCLEARANCEFeed.zip"
    }],
    'name_format': 'format',
    'levels':
    [{
        'level': 'L1',
        'filter' : { 'var1' : 'value2'},
        'targets' : [ 'a@com', 'b@com', 'c@com', 'd@com', 'e@com']
    },{
        'level': 'L2',
        'filter' : { 'var1' : 'value2'},
        'targets' : [ 'a@com', 'b@com', 'c@com', 'd@com', 'e@com','f@com', 'g@com', 'h@com', 'i@com', 'j@com']
    },{
        'level': 'L3',
        'filter' : { 'var1' : 'value2'},
        'targets' : [ 'a@com']
    }]

}, 'inline.json')


class TestBashGeneratorMethods(unittest2.TestCase):

    options={'action' : 'publish'}
    component={}

    #@method
    #def setUp(self):
    def test_rtv_global_reading(self):
        #fdeploy.setLogLevel('DEBUG', 4)
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(['../../test/resources/java-cache-mixin.json'])
        self.component = fdl.components[0]

#    def test_rtv_global_reading(self):
        base = testGenerator(self.component, self.options )
        rtv_map={}
        self.assertEquals(0, len(rtv_map.keys()))
        self.assertEquals(2,len(self.component.rtv))
        rtvs=self.component.get_rtvs(rtv_map, self.component.rtv)
        #rtvs=base.get_rtvs(rtv_map,self.component.rtv)
        fdeploy.LOGGER.debug(rtv_map.keys())
        self.assertEquals(2, len(rtv_map.keys()))
        self.assertEquals('/opt/home/fbs', rtv_map['F_HOME'])
        self.assertEquals('/opt/home/gbs', rtv_map['G_HOME'])

        # overwrite global RTVs
        rtvs=self.component.get_rtvs(rtv_map,[{"name": "G_HOME", "value" : "/home/f5149900"}])
        self.assertEquals('/home/f5149900', rtv_map['G_HOME'])

    def test_rtv_env_vars_reading(self):
        fdl = fdeploy.fdeployLoader(self.options)
        fdl.readDescriptors(['../../test/resources/java-cache-mixin.json'])
        self.component = fdl.components[0]

#    def test_rtv_global_reading(self):
        base = testGenerator(self.component, self.options )
        fdeploy.LOGGER.debug("\\\->\\\\>>> %s" , self.component.rtv)
        options = {
            'rtv': ["G_HOME=/home/f5149900","JAVA_HOME=/opt/java/hotspot"]
         }
        mapping,envvar_list=self.component.get_env_vars(options,'L1',[],'nexusContent.buildId')
        fdeploy.LOGGER.debug(self.component.rtvMapping)
        self.assertEquals(7, len(self.component.rtvMapping.keys()))
        # taken from the Level L1 rtv's
        self.assertEquals('/opt/delta/DL2180/Lihue', self.component.rtvMapping['F_HOME'])
        self.assertEquals('/home/f5149900', self.component.rtvMapping['G_HOME'])
        self.assertEquals('/opt/java/hotspot', self.component.rtvMapping['JAVA_HOME'])

    def test_no_rtv_env_vars_reading(self):
        base = testGenerator(test_component, self.options )
        struct = {'contents': 'comp.contents',
            'targets': 'targets','level': 'L1', 'uuid': 'comp.id'
         }
        rtv_map={}
        unused,envvar_list=test_component.get_env_vars(
            self.options,'L1',[],'nexusContent.buildId')
        self.assertEquals(0, len(rtv_map.keys()))

    def test_find_first_component(self):
        base = testGenerator(test_component, self.options)
        with self.assertRaises(Exception):
            com = base.get_first_nexus_component_in_content()
        com = base.get_first_nexus_component_in_content(False)
        self.assertEquals(None, com.version)
        self.assertEquals('com.fedex.sefs.core', com.groupId)
        self.assertEquals('sefs_suCLEARANCEFeed', com.artifactId)

        pass

if __name__ == '__main__':
    unittest.main()
