# -*- coding: utf-8 -*-

import os
import re
import sys
import glob
import subprocess
import fdeploy
import fdeploy.platform
import fdeploy.fdeployLoader
import itertools
import time
from fdeploy.platform import load_snippet, baseGenerator
from fdeploy.fdeployLoader import DEFAULT_TARGET_SPEC
from fdeploy.pam import pamAuth

REQUIRED_RTVS = ['NUM_INSTANCES', 'APPD_NM', 'LOG_LEVEL', 'APP_NM', 'SERVICE_INSTANCES','PAM_ID']
REGISTERED_ACTIONS = ['clean', 'wipeout', 'start', 'stop', 'install', 'stage', 'ml', 'machine_list',
                      'deploy', 'publish', 'unpublish', 'restart', 'report', 'ssh', 'inspect', 'ps', 'cloudenv','status','relink']
TARGET_URL_SPEC=DEFAULT_TARGET_SPEC


class pcfDeployer(baseGenerator):
    def __init__(self, component, cli_options, stage_directory):
        self.REGISTERED_ACTIONS =  fdeploy.platform.bash_pcf_generator.REGISTERED_ACTIONS
        super(pcfDeployer, self).__init__(
            component, cli_options, stage_directory)
        fdeploy.debug(
            " < init bash-generator pcfDeployer platform for " + str(self.component))

    def report(self,__reports):
        pass

class pcfGenerator(baseGenerator):

    files = []
    upload_script = load_snippet('pcf/upload_snippet.sh')

    def __init__(self, component, cli_options, stage_directory='.', target_spec = DEFAULT_TARGET_SPEC):
        self.REGISTERED_ACTIONS =  fdeploy.platform.bash_pcf_generator.REGISTERED_ACTIONS
        self.REQUIRED_RTVS =  fdeploy.platform.bash_pcf_generator.REQUIRED_RTVS

        super(pcfGenerator, self).__init__(
            component, cli_options, stage_directory, target_spec)
        fdeploy.debug(
            " < init platform: bash-generator, class: pcfGenerator  for " + str(self.component))
        # overwrite stage snippet begin
        self.data_wrapper_header = load_snippet('pcf/pcf_header_snippet.sh')
        self.data_wrapper_footer = load_snippet('pcf/pcf_footer_snippet.sh')
        self.upload_snippet = load_snippet('pcf/upload_snippet.sh')
        self.status_snippet = load_snippet('pcf/status_snippet.sh')
        self.delete_snippet = load_snippet('pcf/delete_snippet.sh')
        self.start_snippet = load_snippet('pcf/start_snippet.sh')
        self.stop_snippet = load_snippet('pcf/stop_snippet.sh')
        self.restart_snippet = load_snippet('pcf/restart_snippet.sh')

    def needs_nexus_version(self,action):
        #print "%s -> %s" % (action, json.dumps(action,indent=5))
        if 'ssh' in action:
            return False
        return True


    def list_machines(self, struct,target_list,search=None):
        __targets = fdeploy.flatten_level_targets(struct['targets'])
        for target in __targets:
            _target = target.split(":")[0]
            if self.options.user is not None:
                _target = re.sub(
                    r'^(\S+)\@', self.options.user + str('@'), _target)
            if not _target in target_list:
                target_list.append(_target)

    """Generate scripts for the components on the targets in the descriptors."""
    def generate(self, struct, outfile, action='status', target_spec=None, verbose=False):
        level = struct['level']
        # replace values in the snippets
        target_list = ''
        envvar_list = ''
        # pick the first Nexus resolved component artifact.
        nexusContent = self.get_first_nexus_component_in_content(self.needs_nexus_version(action))

        #
        # resolving the runtime variables (rtv), first global then components.
        #
        rtv_map={}
        __targets = fdeploy.flatten_level_targets(struct['targets'])
        fdeploy.debug("hosts : %s spec %s"  % (str(__targets), target_spec))
        target,target_list=self.get_target_list(__targets)
        if len(target_list) < 2:
            raise Exception("targetlist empty? %s" % (struct['targets']))

        rtv_map,envvar=self.component.get_env_vars(self.options,level['level'], self.REQUIRED_RTVS, nexusContent.version, init=rtv_map)
        try:
            rtv_map['SPACE'],rtv_map['DOMAIN']=target.split('@')
            rtv_map['APP_HOST']= "%s" % (struct['uuid'])
            user,pwd = pamAuth().get_passwd(rtv_map['PAM_ID'])
            rtv_map['PCF_USER']=user
            rtv_map['PCF_PASSWORD']=pwd
            if 'PROD' not in level['level']:
                rtv_map['APP_HOST'] = "%s-%s" % (level['level'].upper(), rtv_map['APP_HOST'])
                rtv_map['APP_NM'] = "%s-%s" % (level['level'].upper(), rtv_map['APP_NM'])
        except NameError as err:
            raise Exception("unable to parse target URL %s: %s" % (target,err))
        except Exception as errr:
            raise Exception("err: %s" % (errr))
        if action == 'install':
            rtv_map['PCF_PUSH_OPTIONS']='--no-start'

        fdeploy.trace("target => %s " % (target))

        envvar_list=self.component.as_envvars(rtv_map)

        fdeploy.debug( "-> struct     =%s" % (struct))
        fdeploy.debug( "-> rtv_map    =%s" % (rtv_map))
        fdeploy.debug( "-> envvar_list=%s" % (envvar_list))

        verboseOn = "set -xv"
        verboseOff = "set +xv"
        verboseFlag = verboseOff if verbose == False else verboseOn

        # NO WAIT FLAG
        nowaitflag = '' if self.options.no_wait == False else '#SKIP#'

        log_array = fdeploy.bash_array()
        fdeploy.trace("log_array=" + str(log_array))

        # agregation of steps.
        actions = []
        actions.append(action)


        fdeploy.info( "generating for %s individual actions" % (len(actions)) )
        for _action in actions:
            # only echo the env vars on certain actions.
            echoEnvVars = verboseOff if _action in fdeploy.ACTIONS_WITH_COMPONENT_HANDLING else verboseFlag
            print >> outfile, self.data_wrapper_header % (
                self.options.command,
                _action,
                self.options.level,
                rtv_map['APP_NM'],
                log_array[0], log_array[1], log_array[2], log_array[3],
                struct['uuid'],
                struct['directory'],
                self.stage_directory,
                '20', #timeout
                nexusContent.version,
                nexusContent.saveArchiveName,
                nexusContent.artifactId,
                envvar_list
            )

            data = []
            fdeploy.info("generating for [%s] " % ( _action ))
            if _action == 'stage':
                data.append(self.status_snippet)
                data.append(self.upload_snippet)
            elif _action == 'install':
                data.append(self.status_snippet)
                data.append(self.upload_snippet)
            elif _action == 'deploy':
                data.append(self.status_snippet)
                data.append(self.stop_snippet)
                data.append(self.upload_snippet)
                data.append(self.start_snippet)
            elif _action == 'restart':
                data.append(self.status_snippet)
                data.append(self.restart_snippet)
            elif _action == 'stop':
                data.append(self.status_snippet)
                data.append(self.stop_snippet)
            elif _action == 'start':
                data.append(self.status_snippet)
                data.append(self.start_snippet)
            elif _action == 'run':
                pass
            elif _action == 'relink':
                pass
            elif _action == 'status':
                data.append(self.status_snippet)
            elif _action == 'wipeout' or _action == 'clean':
                data.append(self.status_snippet)
                data.append(self.delete_snippet)
            elif _action == 'ssh':
                pass
            elif _action == 'inspect':
                pass
            elif _action == 'ps':
                pass
            elif _action == 'cloudenv':
                pass

            # generate all the lines
            for script_line in data:
                print >> outfile, script_line
            # if test no footer needed the test is selfcontanted and
            # does not need script streaming
            if _action not in ['test', 'inspect', 'ssh', 'ps','cloudenv']:
                print >> outfile, self.data_wrapper_footer
