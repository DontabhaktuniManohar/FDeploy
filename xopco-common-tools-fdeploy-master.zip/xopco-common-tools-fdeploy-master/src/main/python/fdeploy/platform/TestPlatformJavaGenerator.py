import unittest2
import fdeploy
import os
from fdeploy.platform import load_file, assertLines, basePlatformTest
from fdeploy import Options


class TestJavaGenerator(basePlatformTest):

    properties =  '''   # Generating the current properties for this version
   cat <<EOF > "${_target_path}/${_archive_version}.properties"
#!/bin/bash
# Generated property file for application.
export APPD_ACCOUNT="fedex1-test"
export APPD_APPNAME="SU-SEFS-RELY-L1"
export APPD_CONTROLLER_HOST="fedex1-test.saas.appdynamics.com"
export ARTIFACTID="share-cache-plugin"
export EUREKA_HOST="urh00600.ute.fedex.com"
export GROUPID="com.fedex.sefs.cache.plugins"
export HTTP_PORT="8096"
export LEVEL="L1"
export SPRING_PROFILE="L1"

EOF
'''

    def test_properties_creation(self):
        options = Options(command='deploy',action='properties',identity='.',
        X=True, id = None, path=".", no_wait = False, level='L1',
        user='sefs')
        self.assertPropertiesGeneration(options,'javaGenerator',
            'JAVA_SHARE_CACHE_SERVICE_%0d',
            '../../test/resources/FXE_fdeploy/fxe-share-cache-plugin.json')

if __name__ == '__main__':
    unittest.main()
