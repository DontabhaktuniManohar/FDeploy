import unittest2
import fdeploy
import codecs
from fdeploy import Options
from fdeploy.platform.bash_tibcobw_generator import tibco_bwGenerator
from fdeploy.UtilsForTesting import AbstractTestCase
import os

component = fdeploy.fdeployComponent({
    'id': 'componentId',
    'platform': 'bash_generator',
    'type': 'tibco_bw',
    'rtv': [
        {
            "name": "TRA_HOME",
            "value": "tibcosilver@srh00607.ute.fedex.com:/opt/tibco/silver/persistentdata/FXE/apps/CLEARANCEFeed"
        },
        {
            "name": "JMX_PORT",
            "value": "abcdef"
        },
        {
            "name": "PROCESS_NAME",
            "value": "tibcosilver@srh00607.ute.fedex.com:/opt/tibco/silver/persistentdata/FXE/apps/CLEARANCEFeed"
        },
        {
            "name": "ADMIN_TARGET_URL",
            "value": "tibcosilver@srh00607.ute.fedex.com:/opt/tibco/silver/persistentdata/FXE/apps/CLEARANCEFeed"
        },
        {
            "name": "EAINUMBER",
            "value": "#CLEARANCEFeed"
        },
        {
            "name": "APPMANAGE_CREDENTIALS",
            "value": "#CLEARANCEFeed"
        },
        {
            "name": "EAINUMBER",
            "value": "#CLEARANCEFeed"
        },
        {
            "name": "APPMANAGE_XML",
            "value": "../../test/resources/bw5/FXFShipFeed_template_l2.xml"
        },
        {
            "name": "APPMANAGE_PLAN",
            "value": "../../test/resources/bw5/FXFShipFeed_plan-descriptors.xml"
        }


    ],
    'content':  [{
        "gav": "com.fedex.sefs.core:sefs_suCLEARANCEFeed:1.0.0:zip",
        "relativePath": "apparchives",
        "saveArchiveName": "sefs_suCLEARANCEFeed.zip"
    }],
    'name_format': 'format',
    'levels':
    [{
        'level': 'L1',
        'filter' : { 'maxHeapSize' : 'value2'},
        'targets' : [ 'a@com', 'b@com', 'c@com']
    }]

}, 'inline.json')

component_no_version = fdeploy.fdeployComponent({
    'id': 'componentId2',
    'platform': 'bash_generator',
    'type': 'tibco_bw',
    'rtv': [
        {
            "name": "TRA_HOME",
            "value": "tibcosilver@srh00607.ute.fedex.com:/opt/tibco/silver/persistentdata/FXE/apps/CLEARANCEFeed"
        },
        {
            "name": "JMX_PORT",
            "value": "abcdef"
        },
        {
            "name": "PROCESS_NAME",
            "value": "tibcosilver@srh00607.ute.fedex.com:/opt/tibco/silver/persistentdata/FXE/apps/CLEARANCEFeed"
        },
        {
            "name": "ADMIN_TARGET_URL",
            "value": "tibcosilver@srh00607.ute.fedex.com:/opt/tibco/silver/persistentdata/FXE/apps/CLEARANCEFeed"
        },
        {
            "name": "EAINUMBER",
            "value": "#CLEARANCEFeed"
        },
        {
            "name": "APPMANAGE_CREDENTIALS",
            "value": "#CLEARANCEFeed"
        },
        {
            "name": "EAINUMBER",
            "value": "#CLEARANCEFeed"
        },
        {
            "name": "APPMANAGE_XML",
            "value": "../../test/resources/bw5/FXFShipFeed_template_l2.xml"
        },
        {
            "name": "APPMANAGE_PLAN",
            "value": "../../test/resources/bw5/FXFShipFeed_plan-descriptors.xml"
        }


    ],
    'content':  [{
        "gav": "com.fedex.sefs.core:sefs_suCLEARANCEFeed:zip",
        "relativePath": "apparchives",
        "saveArchiveName": "sefs_suCLEARANCEFeed.zip"
    }],
    'name_format': 'format',
    'levels':
    [{
        'level': 'L1',
        'filter' : { 'maxHeapSize' : 'value2'},
        'targets' : [ 'a@com', 'b@com', 'c@com']
    }]

}, 'inline.json')

class TestTibcoBWGenerator(AbstractTestCase):

    options = None

    rtvs =  [
        { 'name': 'APP_REF', 'value' : '${APPMANAGE_PLAN}.backupt'},
        { 'name': 'LEVEL', 'value' : 'L1'}]


    def setUp(self):
        self.options = Options(command='deploy',action='stage',identity='.', X=True, id = None, path=".", no_wait = False, level='L1',user='sefs')

    def tearDown(self):
        try:
            os.remove('platformBW5-1.txt')
            os.remove('platformBW5-2.txt')
            fdeploy.logLevel = fdeploy.Priority.ERROR
            pass
        except OSError:
            pass


    def test_init(self):
        generator = tibco_bwGenerator(component, self.options)

    def test_generate(self):
        generator = tibco_bwGenerator(component, self.options)
        targets = []
        fdeploy.logLevel = fdeploy.Priority.TRACE
        struct = {'level': {'level':'L1','rtv' : self.rtvs }, 'directory': '.', 'contents': component.content, 'targets': targets,  'uuid': 'all'}
        with open("platformBW5-1.txt", "w") as fh:
            generator.generate(struct, fh)
        was = self.load_file_as_string("platformBW5-1.txt")
        expected = self.load_file_as_string("../../test/resources/bw5/platformBW5-1.expected")
        self.assertlines(expected, was)

    def test_generate_with_version_resolve(self):
        generator = tibco_bwGenerator(component_no_version, self.options)
        targets = []
        fdeploy.logLevel = fdeploy.Priority.TRACE
        #print "\n%s\n" % (component_no_version.content[0])
        cont = fdeploy.content_factory(component_no_version.content[0])
        self.assertEquals("com.fedex.sefs.core:sefs_suCLEARANCEFeed:zip", component_no_version.content[0]['gav'])
        self.assertEquals("sefs_suCLEARANCEFeed", cont.artifactId)
        self.assertIsNone(cont.version)
        struct = {'level': {'level':'L1','rtv' : self.rtvs }, 'directory': '.', 'contents': component_no_version.content, 'targets': targets,  'uuid': 'all'}
        with open("platformBW5-2.txt", "w") as fh:
            generator.generate(struct, fh, 'start')
        was = self.load_file_as_string("platformBW5-2.txt")
        expected = self.load_file_as_string("../../test/resources/bw5/platformBW5-2.expected")
        self.assertlines(expected, was, False)


if __name__ == '__main__':
    unittest.main()
