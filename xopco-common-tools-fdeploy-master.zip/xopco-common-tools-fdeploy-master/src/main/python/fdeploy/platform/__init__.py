# -*- coding: utf-8 -*-
import codecs
import sys
import os
import re
import fdeploy
import inspect
import subprocess
import itertools
import time
import unittest
import analytics
import fdeploy.segment

def load_snippet(snippetFile):
    snippet_text = ''
    #with open ("snippets/" + snippetFile, "r") as snippet:
    with codecs.open ("snippets/" + snippetFile, "r", "utf-8") as snippet:
        snippet_text=snippet.read()
    return snippet_text.encode('utf8', 'ignore')

def load_file(sile):
    text = ''
    with codecs.open (sile, "r", "utf-8") as snippet:
        text=snippet.read()
    return text.encode('utf8', 'ignore')

def assertLines(unittest,jsonFile, expected,actual, skip=True):
    unittest.assertIsNotNone(expected)
    unittest.assertIsNotNone(actual)
    lines_a = expected.split("\n")
    lines_b = actual.split("\n")
    unittest
    j = 0
    for i in lines_b:
        fdeploy.info("generating for [%s] " % ( i ))
        if skip == True:
            if re.search('# ---- begin - remote_properties_snippet.sh',i):
                skip=False
            continue
        if skip == False and re.search('# ---- end - remote_properties_snippet.sh',i):
            break
        print "[%s]\n[expect]\t%3d '%s'\n[actual]\t%3d '%s'" % (jsonFile,j,lines_a[j],j,i)
        if not 'PCF_PASSWORD' in lines_a[j]:
            unittest.assertEquals(lines_a[j],i)
        j +=1


class  basePlatformTest(unittest.TestCase):

    def assertPropertiesGeneration(self,options, fdeployType,fdeployName, jsonFile):
        fdeployTypeFile = "testfile.%s" % (fdeployType)
        fdl = fdeploy.fdeployLoader(options)
        fdl.readDescriptors(
            [jsonFile])
        self.assertEquals(1, len(fdl.components))
        clz,classname=fdl.components[0].get_generator_class(options,'.')
        self.assertEquals(fdeployType, str(classname))
        self.assertEquals(fdeployName, str(clz.name))
        with open(fdeployTypeFile, 'w') as outfile:
            clz.generate({'contents': None, 'targets': ['sefs@urh00601.ute.fedex.com'],
                'level': fdl.components[0].get_level(options.level), 'uuid': 'all'},outfile,action=options.action)
        outfile.close()
        actual = load_file(fdeployTypeFile)
        #print actual
        assertLines(self, jsonFile, self.properties,actual)


class baseGenerator(object):
    ' ! The base class for bash generators'

    data_wrapper_header = load_snippet('data_wrapper_header.sh')
    data_wrapper_footer = load_snippet('data_wrapper_footer.sh')
    data_wrapper_execute = load_snippet("master_execute.sh")

    pki_ssh_snippet = load_snippet('pki_ssh_snippet.sh')
    ps_test_snippet = load_snippet('ps_test_snippet.sh')
    inspect_snippet = load_snippet('inspect_snippet.sh')
    upload_snippet = load_snippet('upload_snippet.sh')
    cloudenv_snippet = load_snippet('cloudenv_test_snippet.sh')
    done_deal_snippet = '''done'''

    remote_script_begin= load_snippet('remote_script_begin.sh')
    remote_overwrite_snippet = load_snippet('remote_overwrite_snippet.sh')
    remote_stage_snippet_begin = load_snippet('remote_stage_snippet_begin.sh')
    remote_cleanup_snippet = load_snippet('remote_cleanup_snippet.sh')
    remote_wipeout_snippet = load_snippet('remote_wipeout_snippet.sh')
    remote_relink_snippet = load_snippet('remote_relink_snippet.sh')
    remote_restart_snippet = load_snippet('remote_restart_snippet.sh')
    remote_stop_snippet = load_snippet('remote_stop_snippet.sh')
    remote_run_snippet = load_snippet('remote_run_snippet.sh')
    remote_status_snippet = load_snippet('remote_status_snippet.sh')
    remote_stage_snippet_end = load_snippet('remote_stage_snippet_end.sh')
    remote_script_end = load_snippet('remote_script_end.sh')
    remote_properties_snippet = load_snippet('remote_properties_snippet.sh')


    def __init__(self, component, cli_options, stage_directory='.', target_spec = None):
        self.options = cli_options
        # validate if the action is registered thru introspection
        # the vocabulary of this implementation
        analytics.write_key = None
        fdeploy.segment.USE_ANALYTICS=False
        if type(cli_options) == dict:
            try:
                self.__class__.has_action(self, cli_options['action'])
            except KeyError as keyerr:
                print str(keyerr)
                raise Exception("action was not supplied in cli_options %s" % (cli_options))

        else:
            self.__class__.has_action(self, cli_options.action)
        cwd = os.getcwd()
        self.stage_directory = str(cwd) + '/' + str(stage_directory)
        self.extension = 'sh'
        self.component = component
        self.name = component.name_format
        self.id = id
        self.level = None
        self.ssh_options = '-oConnectTimeout=20 -oStrictHostKeyChecking=no \
-oBatchMode=yes -oLogLevel=error -oUserKnownHostsFile=/dev/null'
        self.indicator = re.sub(r"_?%\d*[dsf]", "", self.name)
        if os.path.isdir(self.stage_directory) == False:
            os.makedirs(self.stage_directory, 0755)
                #print str(target_spec)
        self.target_spec = re.compile('(\S+)\@([a-z0-9-\._]+):(\S+)') if target_spec is None else target_spec

        fdeploy.debug(" < init baseGenerator: stage_directory > " +
                      str(self.stage_directory))

    def needs_nexus_version(self,action):
        return True

    def get_target_list(self, __targets):
        target = None
        target_list = ''
        _continue = True
        for target in __targets:
            if self.target_spec.match(target) is None:
                fdeploy.error(
                    " ! ERROR: '%s' is ill-formed target location." % (target))
                _continue = False
            elif type(self.options) is dict and 'user' in self.options.keys():
                target = re.sub(
                    r'^(\S+)\@', self.options['user'] + str('@'), target)
                if 'path' in self.options.keys() and self.options['path'] is not None:
                    target = re.sub(r':(\S+)', ':' + self.options.path, target)
            elif self.options.user is not None:
                target = re.sub(
                    r'^(\S+)\@', self.options.user + str('@'), target)
                if self.options.path is not None:
                    target = re.sub(r':(\S+)', ':' + self.options.path, target)
            target_list = target_list + "   \"%s\"\n" % (target)
        if _continue == False:
            raise Exception("No targets have been listed!")
        return target,target_list

    ''' create list of upload items in the : : : : notation for extraction on the backend'''
    def get_upload_list(self,struct,version):
        upload_list=''
        if struct['contents'] is not None:
            for upload_item in struct['contents']:
                fdeploy.debug("upload_item: %s:%s" % (upload_item,upload_item.isRelative() if hasattr(upload_item, 'isRelative')  else '---'))
                path = version
                owner = ''
                perms =  ''
                dirs = ''
                if type(upload_item) == dict:
                    # turn dictionary into class
                    upload_item = fdeploy.content_factory(upload_item)
                if isinstance(upload_item, fdeploy.contentClass):
                    if  upload_item.prependpath:
                        dirs = upload_item.prependpath
                    if  upload_item.permission:
                        perms = upload_item.permission
                    if  upload_item.owner:
                        owner = upload_item.owner
                    if upload_item.isRelative() == False:
                        path = '.'
                elif isinstance(upload_item, fdeploy.gavClass):
                    path = version
                    if upload_item.isRelative() == True and upload_item.relativePath:
                        # backwards compatibility with older json files that have relativepaths
                        if 'apparchives' not in upload_item.relativePath:
                            path = "%s/%s" % (version, upload_item.relativePath)
                    elif upload_item.isRelative() == False:
                        path = "."
                else:
                    raise Exception("Unknown content class %s : %s" % (str(type(upload_item)),upload_item))
                if upload_list != '':
                    upload_list = upload_list  + ' '
                upload_list = upload_list + "\"%s:%s:%s:%s:%s\"" % \
                    (upload_item.saveArchiveName, path, dirs, perms, owner)
        return upload_list

    '''returning the nexus content in a list of content'''
    # version can get supplied not recommended, however added for testing purpose
    def get_first_nexus_component_in_content(self,mandatory_flag=True, version=None):
        # pick the first Nexus resolved component artifact.
        #deploy.dump(mandatory_flag)
        for nexusContent in self.component.contents:
            if self.component.isNexusArtifact(nexusContent):
                break
        fdeploy.debug("versioned-content: %s" % (str(nexusContent)))
        if nexusContent is None:
            raise Exception("No Nexus content was found for this component.")
        if self.component.isNexusArtifact(nexusContent) == True:
            if nexusContent.version is None and version is not None:
                nexusContent.version = version
                return nexusContent
            if nexusContent.version is None and mandatory_flag == True:
                raise Exception("unable to generate script with %s without resolved version" % (nexusContent))
        else:
            if mandatory_flag == True:
                raise Exception("unable find nexus content with %s without resolved version" % (nexusContent))

        return nexusContent

    ''' find the application user with the cloudenv user for cm and app distinguishment'''
    def get_app_user(self,target,app_user,_action):
        #
        # find the application user, assuming the user being supplied is the cm user
        # based on the last processed target
        #
        if  not target is None:
            if self.options.user is not None:
                app_user = self.options.user
            elif _action in fdeploy.ACTIONS_APP_USER_REQUIRED:
                # switch to app user when we are dealing with CloudVMs authority roles
                if 'cm@' in target:
                    app_user = ''
                else:
                    app_user = re.sub(r'\@.+', '', target)
            else:
                # use the default user specified in the target
                # the user will be parse by data_wrapper_header
                app_user = re.sub(r'\@.+', '', target)
            fdeploy.debug("using '%s' for execution" % (app_user))
        fdeploy.info("app_user[%s]=%s" % ( _action, app_user))
        return app_user

    def write_refactored(self, outfile, _action, data, log_array,
            envvar_list, verboseFlag, app_user):
        _remote_script_begin= self.remote_script_begin% (
            log_array[0], log_array[1], log_array[2], log_array[3],
            envvar_list, verboseFlag)
        _remote_properties_snippet = self.remote_properties_snippet % (envvar_list)
        fdeploy.info("generating for [%s] as %s" % ( _action, app_user))
        self.write(outfile,_action,data,_remote_script_begin,_remote_properties_snippet)

    def write(self, outfile, _action, data, _remote_script_begin,
            _remote_properties_snippet):
        self.write_with_end(outfile, _action, data, _remote_script_begin,
                _remote_properties_snippet,self.data_wrapper_footer)

    def write_with_end(self, outfile, _action, data, _remote_script_begin,
            _remote_properties_snippet,_data_wrapper_footer):
        if _action == 'stage':
            data.append(self.upload_snippet)
            data.append(_remote_script_begin)
            data.append(self.remote_stage_snippet_begin)
            data.append(_remote_properties_snippet)
            data.append(self.remote_stage_snippet_end)
            data.append(self.remote_script_end)
        elif _action == 'install':
            data.append(self.upload_snippet)
            data.append(_remote_script_begin)
            data.append(self.remote_overwrite_snippet)
            data.append(self.remote_stage_snippet_begin)
            data.append(_remote_properties_snippet)
            data.append(self.remote_create_scripts_snippet)
            data.append(self.remote_relink_snippet)
            data.append(self.remote_stage_snippet_end)
            data.append(self.remote_script_end)
        elif _action == 'properties':
            data.append(_remote_script_begin)
            data.append(_remote_properties_snippet)
            data.append(self.remote_script_end)
        elif _action == 'restart':
            data.append(_remote_script_begin)
            data.append(self.remote_restart_snippet)
            data.append(self.remote_script_end)
        elif _action == 'stop':
            data.append(_remote_script_begin)
            data.append(self.remote_stop_snippet)
            data.append(self.remote_script_end)
        elif _action == 'start':
            data.append(_remote_script_begin)
            data.append(self.remote_restart_snippet)
            data.append(self.remote_script_end)
        elif _action == 'run':
            data.append(_remote_script_begin)
            data.append(self.remote_run_snippet)
            data.append(self.remote_script_end)
        elif _action == 'relink':
            data.append(_remote_script_begin)
            data.append(self.remote_relink_snippet)
            data.append(self.remote_script_end)
        elif _action == 'status':
            data.append(_remote_script_begin)
            data.append(self.remote_status_snippet)
            data.append(self.remote_script_end)
        elif _action == 'clean':
            data.append(_remote_script_begin)
            data.append(self.remote_cleanup_snippet)
            data.append(self.remote_script_end)
        elif _action == 'wipeout':
            data.append(_remote_script_begin)
            data.append(self.remote_wipeout_snippet)
            data.append(self.remote_script_end)
        elif _action == 'ssh':
            data.append(self.pki_ssh_snippet)
            data.append(self.done_deal_snippet)
        elif _action == 'inspect':
            data.append(self.inspect_snippet)
            data.append(self.done_deal_snippet)
        elif _action == 'ps':
            data.append(self.ps_test_snippet)
            data.append(self.done_deal_snippet)
        elif _action == 'cloudenv':
            data.append(self.cloudenv_snippet)
            data.append(self.done_deal_snippet)

        # generate all the lines
        for script_line in data:
            print >> outfile, script_line
        # if test no footer needed the test is selfcontanted and
        # does not need script streaming
        if _action not in ['test', 'inspect', 'ssh', 'ps','cloudenv']:
            print >> outfile, _data_wrapper_footer


    def deploying(self, files, verbose=False):
        p = []
        i = 0
        if len(files) < 1:
            raise Exception("Abort! No files were generated for this deployment of type %s." % (self))
        for _file in files:
            i += 1
            fdeploy.debug(" > deploying execution: %s of %s / %s" % (i,len(files),_file))
            fdeploy.trace(" > files are %s" % (files))
            __file = str(self.stage_directory) + "/" + str(_file)
            _filename = str(self.stage_directory) + \
                "/deploy-" + str(_file) + ".log"
            os.chmod(__file, 0b111101101)  # rwxr-xr-x make it executable
            # subprocess.call(["/var/tmp/fdeploy/xls.sh"])
            # remote invocation of the generated script
            my_env = os.environ.copy()
            with open(_filename, 'w') as __stdout:
                #subprocess.call([__file], stdout=__stdout)
                if self.options.parallel == False:
                    proc=subprocess.Popen(__file, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                    for line in proc.stdout:
                        if verbose:
                            sys.stdout.write(line)
                        __stdout.write(line)
                    proc.wait()
                else:
                    with open(os.devnull, 'r+b', 0) as DEVNULL:
                        px = subprocess.Popen([__file],
                            stdin=DEVNULL, stdout=DEVNULL, stderr=__stdout, env=my_env,
                            close_fds=True)
                        p.append(px)
                        # Wait until process terminates
                        while px.poll() is None:
                            time.sleep(1)
            fdeploy.debug(" > deploying execution done: %s for %s" % (i,_file))



    def report(self,__reports):
        show_pattern = None
        if 'show' in self.options:
            if self.options.show == 'running' or self.options.show == 'up' or self.options.show == 'started':
                show_pattern = 1
            elif self.options.show == 'not-running' or self.options.show == 'down' or self.options.show == 'stopped':
                show_pattern = 2
        # uniques only
        reports = []
        for _r in __reports:
            if not _r in reports:
                reports.append(_r)
        for _filename in sorted(reports):
            fdeploy.info("examining: %s" % (_filename))
            #fdeploy.trace(">>>>>> : %s" % (os.path.dirname(_filename)))
            _filein_ = []
            with open(_filename, 'r') as f:
                _file = os.path.basename(_filename)
                _filein_ = f.readlines()
            show_file_based_on_content = False
            if not show_pattern is None:
                for line in _filein_:
                    if 'is not running' in line:
                        fdeploy.trace(" %d = %s" % (show_pattern, line))
                        show_file_based_on_content = True
                        break
                if show_pattern == 1:
                    show_file_based_on_content = False if show_file_based_on_content == True else True
            else:
                show_file_based_on_content = True
            if show_file_based_on_content == True:
                for line in _filein_:
                    print("%s : %s" % (_file, line)),

    def has_action(self, action):
        if action not in self.REGISTERED_ACTIONS:
            raise Exception("Action %s not registered as a fucntion with %s" % (action, self) )
