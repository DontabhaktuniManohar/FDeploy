import unittest2
import os
import codecs
import unicodedata


class AbstractTestCase(unittest2.TestCase):

    def assertlines(self,generated,expected, remove_empty_lines=True):
        lines1 = generated.split('\n')
        lines2 = expected.split('\n')
        #print "%s" % (generated)
        i=1
        for l in lines1:
            #l2 = lines2[i-1]
            l = remove_control_characters(l)
            l2 = remove_control_characters(lines2[i-1])

            if remove_empty_lines == True and l == "":
                continue
            if l == "" and l2 == "":
                i+=1
                continue
            if l2 == "":
                i+=1
                continue
            #print " lines %s:  match '%s' vs '%s'" % (i,l,l2)
            if 'src/main/python' not in l2 and 'PCF_PASSWORD' not in l2:
                self.assertEquals(l,l2, " lines %s: dont match '%s' vs '%s'" % (i,l,l2))
            i+=1
            #if i > 10:
            #    break

    def load_file_as_string(self,sfile, strip=False):
        snippet_text = ''
        #with open ("snippets/" + snippetFile, "r") as snippet:
        with codecs.open (sfile, "r", "utf-8") as snippet:
            snippet_text=snippet.read()
        return snippet_text

def remove_control_characters(s):
    return "".join(ch for ch in s if unicodedata.category(ch)[0]!="C").strip()


if __name__ == '__main__':
    unittest.main()
