# -*- coding: utf-8 -*-
import codecs
import unittest2
import fdeploy.deployer
import pprint
from fdeploy import resolve_filter
import glob
import imp
import sys
import copy
import logging

def addOrReplace(base, command):
    for c in command:
        base.append(c)
    #print "base: ", str(base)


def doSsh(jsonfile,level='L1'):
    addOrReplace(sys.argv, [TestFdeploy.VERBOSE_LEVEL, '-t', 'test', '-a', 'ssh', '-f', jsonfile, '-l', level])
    runpy = imp.load_source('__main__', 'fdeploy.py')
def doMl(jsonfile,level='L1'):
    addOrReplace(sys.argv, [TestFdeploy.VERBOSE_LEVEL, '-t', 'test', '-a', 'ml', '-f', jsonfile, '-l', level])
    runpy = imp.load_source('__main__', 'fdeploy.py')
def doPs(jsonfile,level='L1'):
    addOrReplace(sys.argv, [TestFdeploy.VERBOSE_LEVEL, '-t', 'test', '-a', 'ps', '-f', jsonfile, '-l', level])
    runpy = imp.load_source('__main__', 'fdeploy.py')
def doDeployStage(jsonfile,level='L1'):
    addOrReplace(sys.argv, ['-nd', '-t',TestFdeploy.VERBOSE_LEVEL, 'deploy', '-a', 'stage', '-f', jsonfile, '-l', level])
    runpy = imp.load_source('__main__', 'fdeploy.py')
def doDeployInstall(jsonfile,level='L1',no_download=True):
    arr=['-nd', '-t',TestFdeploy.VERBOSE_LEVEL, 'deploy', '-a', 'install', '-f', jsonfile, '-l', level]
    if no_download == True:
        arr.insert(0,'-nd')
    addOrReplace(sys.argv, arr)
    runpy = imp.load_source('__main__', 'fdeploy.py')
def doDeployDeploy(jsonfile,level='L1'):
    addOrReplace(sys.argv, ['-nd','-t',TestFdeploy.VERBOSE_LEVEL, 'deploy', '-a', 'deploy', '-f', jsonfile, '-l', level])
    runpy = imp.load_source('__main__', 'fdeploy.py')
def doControlStop(jsonfile,level='L1'):
    addOrReplace(sys.argv, ['-nd', '-t',TestFdeploy.VERBOSE_LEVEL, 'control', '-a', 'stop', '-f', jsonfile, '-l', level])
    runpy = imp.load_source('__main__', 'fdeploy.py')
def doControlStopById(jsonfile,level='L1',id='fxe-'):
    addOrReplace(sys.argv, ['-nd', '-t',TestFdeploy.VERBOSE_LEVEL, 'control', '-a', 'stop', '-f', jsonfile, '-l', level, '-id',id])
    runpy = imp.load_source('__main__', 'fdeploy.py')
def doControlStatus(jsonfile,level='L1'):
    addOrReplace(sys.argv, ['-nd', '-t',TestFdeploy.VERBOSE_LEVEL, 'control', '-a', 'status', '-f', jsonfile, '-l', level])
    runpy = imp.load_source('__main__', 'fdeploy.py')
def doControlPublish(jsonfile,level='L1'):
    addOrReplace(sys.argv, ['-ns', '-nr', '-rc','../../test/resources/FXE_fdeploy/.fdeployunittest', '-t',TestFdeploy.VERBOSE_LEVEL,'control', '-a', 'publish', '-f', jsonfile, '-l', level])
    runpy = imp.load_source('__main__', 'fdeploy.py')
def doControlUnpublish(jsonfile,level='L1'):
    addOrReplace(sys.argv, ['-nd', '-t',TestFdeploy.VERBOSE_LEVEL, 'control', '-a', 'unpublish', '-f', jsonfile, '-l', level])
    runpy = imp.load_source('__main__', 'fdeploy.py')


class TestFdeploy(unittest2.TestCase):

    VERBOSE_LEVEL='-v'

    _original_argv_ = []

    def setUp(self):
        fdeploy.log()
        logging.basicConfig(level=logging.DEBUG)
        #print sys.argv
        if len(self._original_argv_) < 1:
            self._original_argv_ = copy.deepcopy(sys.argv)
        #print "setUp: %s (class-argv=%s)" % (self, TestFdeploy._original_argv_)
        sys.argv = copy.deepcopy(TestFdeploy._original_argv_)
        self.options = {'nexusURL': 'http://sefsmvn.ute.fedex.com:9999'}
        pass
#  ╔╦╗╦╔╗ ╔═╗╔═╗  ╔╗ ╔═╗
#   ║ ║╠╩╗║  ║ ║  ╠╩╗║╣
#   ╩ ╩╚═╝╚═╝╚═╝  ╚═╝╚═╝
    def testTestSshBE(self):
        doSsh('../../test/resources/FXE_fdeploy/fxe-be-sefsContainer.json')
    def testDeployStageBE(self):
        doDeployStage('../../test/resources/FXE_fdeploy/fxe-be-sefsContainer.json')
    def testDeployInstallBE(self):
        doDeployInstall('../../test/resources/FXE_fdeploy/fxe-be-sefsContainer.json')
    def testControlStopBE(self):
        doControlStop('../../test/resources/FXE_fdeploy/fxe-be-sefsContainer.json')
    def testControlStatusBE(self):
        doControlStatus('../../test/resources/FXE_fdeploy/fxe-be-sefsContainer.json')
#  ╔╦╗╦╔╗ ╔═╗╔═╗  ╔╗ ╦ ╦
#   ║ ║╠╩╗║  ║ ║  ╠╩╗║║║
#   ╩ ╩╚═╝╚═╝╚═╝  ╚═╝╚╩╝
    def testTestSshBW(self):
        doSsh('../../test/resources/FXE_fdeploy/fxe-bw-sefsAutoDGFeed.json')
    def testDeployInstallBW(self):
        doDeployInstall('../../test/resources/FXE_fdeploy/fxe-bw-sefsAutoDGFeed.json')
    def testDeployInstallAnotherBW(self):
        doDeployInstall('../../test/resources/fxg-bw-test.json',no_download=False)
    def testDeployStageBW(self):
        doDeployStage('../../test/resources/FXE_fdeploy/fxe-bw-sefsAutoDGFeed.json')
    def testControlStatusBW(self):
        try:
            doControlStatus('../../test/resources/FXE_fdeploy/fxe-bw-sefsAutoDGFeed.json')
            raise Exception("should have failed no control status")
        except:
            pass
    def testControlStopBW(self):
        doControlStop('../../test/resources/FXE_fdeploy/fxe-bw-sefsAutoDGFeed.json')
    def testControlUnPublishBW(self):
        doControlUnpublish('../../test/resources/bw5/FXE_SULEGACY.json')
        # tests local download as well
    def testControlPublishBW(self):
        doControlPublish('../../test/resources/bw5/FXE_SULEGACY.json')
#  ╔╦╗╦╔╗ ╔═╗╔═╗  ╔╗ ╦ ╦  ┌┬┐┬ ┬┌─┐
#   ║ ║╠╩╗║  ║ ║  ╠╩╗║║║   │ ││││ │
#   ╩ ╩╚═╝╚═╝╚═╝  ╚═╝╚╩╝   ┴ └┴┘└─┘
    def testTestSshBW2(self):
        doSsh('../../test/resources/FXE_fdeploy/fxe-bw2-ClearanceFeed.json')
    def testDeployStageBW2(self):
        doDeployStage('../../test/resources/FXE_fdeploy/fxe-bw2-ClearanceFeed.json')
    def testControlStatusBW2(self):
        try:
            doControlStatus('../../test/resources/FXE_fdeploy/fxe-bw2-ClearanceFeed.json')
            raise Exception("should have failed no control status")
        except:
            pass
    def testControlStopBW2(self):
        doControlStop('../../test/resources/FXE_fdeploy/fxe-bw2-ClearanceFeed.json')
#  ╔╦╗╦╔╗ ╔═╗╔═╗  ╔═╗╔═╗
#   ║ ║╠╩╗║  ║ ║  ╠═╣╚═╗
#   ╩ ╩╚═╝╚═╝╚═╝  ╩ ╩╚═╝
    def testTestSshAS(self):
        doSsh('../../test/resources/FXE_fdeploy/fxg-sds-as-engine.json')
    def testDeployStageAS(self):
        doDeployStage('../../test/resources/FXE_fdeploy/fxg-sds-as-engine.json')
    def testControlStatusAS(self):
        doControlStatus('../../test/resources/FXE_fdeploy/fxg-sds-as-engine.json')
    def testControlStopAS(self):
        doControlStop('../../test/resources/FXE_fdeploy/fxg-sds-as-engine.json')

#  ╔╦╗╦╔╗ ╔═╗╔═╗  ╔═╗╔═╗╦  ╔═╗╔═╗╔═╗╦ ╦
#   ║ ║╠╩╗║  ║ ║  ╠═╣╚═╗║  ║╣ ║╣ ║  ╠═╣
#   ╩ ╩╚═╝╚═╝╚═╝  ╩ ╩╚═╝╩═╝╚═╝╚═╝╚═╝╩ ╩

    def testTestSshASLeech(self):
        doSsh('../../test/resources/FXE_fdeploy/fxg-sds-as-leech.json')
    def testDeployStageASLeech(self):
        doDeployStage('../../test/resources/FXE_fdeploy/fxg-sds-as-leech.json')
    def testControlStatusASLeech(self):
        doControlStatus('../../test/resources/FXE_fdeploy/fxg-sds-as-leech.json')
    def testControlStopASLeech(self):
        doControlStop('../../test/resources/FXE_fdeploy/fxg-sds-as-leech.json')
#   ╦╔═╗╦  ╦╔═╗
#   ║╠═╣╚╗╔╝╠═╣
#  ╚╝╩ ╩ ╚╝ ╩ ╩
    def testTestMlJava(self):
        doMl('../../test/resources/FXE_fdeploy/fxe-plefs-cache-plugin.json')
    def testTestPSJava(self):
        doPs('../../test/resources/FXE_fdeploy/fxe-plefs-cache-plugin.json')
    def testTestSshJava(self):
        doSsh('../../test/resources/FXE_fdeploy/fxe-plefs-cache-plugin.json')
    def testDeployStageJava(self):
        doDeployStage('../../test/resources/FXE_fdeploy/fxe-plefs-cache-plugin.json')
    def testDeployInstallJava(self):
        doDeployInstall('../../test/resources/FXE_fdeploy/fxe-plefs-cache-plugin.json')
    def testControlStopJava(self):
        doControlStop('../../test/resources/FXE_fdeploy/fxe-plefs-cache-plugin.json')
    def testControlStopJava(self):
        doControlStopById('../../test/resources/FXE_fdeploy/fxe-plefs-cache-plugin.json')
    def testControlStatusJava(self):
        doControlStatus('../../test/resources/FXE_fdeploy/fxe-plefs-cache-plugin.json')
#   ╦╔═╗╦  ╦╔═╗    ╔═╗╦ ╦╔╦╗╔═╗
#   ║╠═╣╚╗╔╝╠═╣    ╠═╣║ ║ ║ ║ ║
#  ╚╝╩ ╩ ╚╝ ╩ ╩────╩ ╩╚═╝ ╩ ╚═╝
    def testTestSshJavaAuto(self):
        doSsh('../../test/resources/FXE_fdeploy/scm-java-auto.json')
    def testDeployStageJavaAuto(self):
        doDeployStage('../../test/resources/FXE_fdeploy/scm-java-auto.json')
    def testDeployInstallJavaAuto(self):
        doDeployInstall('../../test/resources/FXE_fdeploy/scm-java-auto.json')
    def testControlStopJavaAuto(self):
        doControlStop('../../test/resources/FXE_fdeploy/scm-java-auto.json')
    def testControlStatusJavaAuto(self):
        doControlStatus('../../test/resources/FXE_fdeploy/scm-java-auto.json')
#  ╔═╗╔═╗╔═╗
#  ╠═╝║  ╠╣
#  ╩  ╚═╝╚
    def testTestSshPCF(self):
        doSsh('../../test/resources/FXE_fdeploy/scm-pmi-boot-pcf.json')
    def testDeployStagePCF(self):
        doDeployStage('../../test/resources/FXE_fdeploy/scm-pmi-boot-pcf.json')
    def testDeployInstallPCF(self):
        doDeployInstall('../../test/resources/FXE_fdeploy/scm-pmi-boot-pcf.json')
    def testControlStopPCF(self):
        doControlStop('../../test/resources/FXE_fdeploy/scm-pmi-boot-pcf.json')
    def testControlStatusPCF(self):
        doControlStatus('../../test/resources/FXE_fdeploy/scm-pmi-boot-pcf.json')
#  ╔╦╗╔═╗╔╦╗╔═╗╔═╗╔╦╗
#   ║ ║ ║║║║║  ╠═╣ ║
#   ╩ ╚═╝╩ ╩╚═╝╩ ╩ ╩
    def testTestSshPCF(self):
        doSsh('../../test/resources/FXE_fdeploy/tomcat.json')
    def testDeployStagePCF(self):
        doDeployStage('../../test/resources/FXE_fdeploy/tomcat.json')
    def testDeployInstallPCF(self):
        doDeployInstall('../../test/resources/FXE_fdeploy/tomcat.json')
    def testControlStopPCF(self):
        doControlStop('../../test/resources/FXE_fdeploy/tomcat.json')
    def testControlStatusPCF(self):
        doControlStatus('../../test/resources/FXE_fdeploy/tomcat.json')
#  ╔═╗┬╦  ╔═╗╔═╗╔═╗╔═╗╦ ╦
#  ╠╣ │║  ║╣ ║  ║ ║╠═╝╚╦╝
#  ╚  ┴╩═╝╚═╝╚═╝╚═╝╩   ╩
    def testTestSshFileCopy(self):
        doSsh('../../test/resources/FXE_fdeploy/fxe-filecopy.json')
    def testDeployStageFileCopy(self):
        doDeployStage('../../test/resources/FXE_fdeploy/fxe-filecopy.json')
    def testDeployInstallFileCopy(self):
        doDeployInstall('../../test/resources/FXE_fdeploy/fxe-filecopy.json')
    def testControlStopPCF(self):
        try:
            doControlStop('../../test/resources/FXE_fdeploy/fxe-filecopy.json')
            raise Exception("should have failed no control status")
        except:
            pass
    def testControlStatusFileCopy(self):
        try:
            doControlStatus('../../test/resources/FXE_fdeploy/fxe-filecopy.json')
            raise Exception("should have failed no control status")
        except:
            pass

if __name__ == '__main__':
    unittest.main()
