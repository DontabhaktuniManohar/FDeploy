python silverControl.py --stop --delete --unpublish  ~/workspace/fxs-deploy/branches/1.7.0/silvercontrol/L2/*.common.properties ~/workspace/fxs-deploy/branches/1.7.0/silvercontrol/L2/broker.*  ~/workspace/fxs-deploy/branches/1.7.0/silvercontrol/L2/sefs.java.fxs.dashboard-web.properties


