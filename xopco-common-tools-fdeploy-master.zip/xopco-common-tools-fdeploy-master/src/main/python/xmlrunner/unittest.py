
from __future__ import absolute_import

import sys
# pylint: disable-msg=W0611
import unittest2
from unittest2 import TextTestRunner
from unittest2 import TestResult, _TextTestResult
from unittest2.result import failfast
from unittest2.main import TestProgram
try:
    from unittest2.main import USAGE_AS_MAIN
    TestProgram.USAGE = USAGE_AS_MAIN
except ImportError:
    pass

__all__ = (
    'unittest', 'TextTestRunner', 'TestResult', '_TextTestResult',
    'TestProgram', 'failfast')
