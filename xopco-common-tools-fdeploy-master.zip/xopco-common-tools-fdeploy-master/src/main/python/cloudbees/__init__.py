import fdeploy
from fdeploy.nexusVersionResolver import NEXUSv3, NEXUSv2
import re
import os

# SEE TESTCASES UNDER fdeploy NEXUS RESOLVER

class CloudBees(object):

    nexusURL = fdeploy.nexusVersionResolver.nexusURL
    nexusRepo = fdeploy.nexusVersionResolver.nexusRepo
    nexusVersionResolver = None
    echo = os.getenv('FDEBUG')
    no_words = None

    def __init__(self, _nexusURL='https://nexus.prod.cloud.fedex.com:8443', _repoName='public', _no_words=True):
        if _nexusURL is not None:
            self.nexusURL = _nexusURL
        if _repoName is not None:
            self.nexusRepo = _repoName
        self.no_words = _no_words
        self.nexusVersionResolver = fdeploy.nexusVersionResolver({ 'nexusURL' : self.nexusURL, 'silent' : 'True'})
        if self.echo:
            print self.__dict__

    def nextVersion(self,pom_dir='.',pom_file='pom.xml'):
        pom=fdeploy.pomResolver(pom_dir,pom_file)
        lookup_version=pom.version
        if self.echo:
            print "nextVersion:\t\t\tpom=%s " % (pom.version)
        for nexusRepo in [ NEXUSv3, NEXUSv2 ]:
            gav=self.increment_major_minor_version({'groupId':pom.groupId, 'artifactId' : pom.artifactId}, lookup_version, nexusRepo)
            lookup_version = gav.version
        if self.echo:
            print "nextVersion:\t\t\tgav=%s => %s" % (gav, lookup_version)
        return gav.version

    def increment_major_minor_version(self, gav, versionNumber, repoName=None):
        if 'groupId' not in gav:
            raise AttributeError('missing groupId in gav dictionary %s' % (gav))
        if 'artifactId' not in gav:
            raise AttributeError('missing artifactId in gav dictionary %s' % (gav))
        gavresult=self.latest_released_version(gav,versionNumber, repoName)
        # if no result was found then this is the first number
        if gavresult.version is None:
            gavresult.version, range = self.nexusVersionResolver.get_base_number(versionNumber, True)
        if (self.echo):
            print "increment_major_minor_version:\tincr_maj_min-> bfore: %s -> wasSnap=%s[%s]" % (gavresult.version,gavresult.has_no_releases,versionNumber)
        newVersion = re.sub( r'-SNAPSHOT$', '', gavresult.version)

        gavresult.version = self.increment_version(newVersion,gavresult.has_no_releases)
        if self.echo:
            print "increment_major_minor_version:\tincr_maj_min-> after: %s -> wasSnap=%s[%s]" % (gavresult,gavresult.has_no_releases,versionNumber)
        return gavresult

    def resolve_version_nexus(self, gav, majorMinorVersion, repoName=None):
        if repoName is None:
            repoName = self.nexusRepo
        gavString = "%s:%s:jar" % (gav['groupId'], gav['artifactId'])
        if self.echo:
            print "resolve_version_nexus:\t\tgavstring=%s <<%s>>" % (gavString,majorMinorVersion)
        gavObject = fdeploy.gavClass({'gav' : gavString, 'saveArchiveName' : 'temp.zip', 'repoName' : repoName })
        result = self.nexusVersionResolver.resolve(gavObject, majorMinorVersion)
        if self.echo:
            resolved=None
            if 'version' in gav.keys():
                resolved = gav['version']
            print "\nresolve_version_nexus:\t\tgav resvld=%s -> %s (%s)=>" % (result, majorMinorVersion, resolved )
        return result

    def latest_released_version(self, gav, versionNumber, repoName=None):
        majmin = self.getMajorMinorVersion(versionNumber)[0]
        gavresult = self.resolve_version_nexus(gav,majmin, repoName)
        # if there is no version released and we only have a snapshot
        if self.echo:
            msg =""
            if gavresult.version:
                msg=gavresult.version
            print "\nlatest_released_version:\t(dots=%s) %s %s -->has_no_releases=%s" % (len(msg.split('.')), versionNumber, gavresult.version, gavresult.has_no_releases)
        if gavresult.version is None and gavresult.has_no_releases is None:
            gavresult.version = None
        elif gavresult.version is None and gavresult.has_no_releases:
            gavresult.version = gavresult.has_no_releases
        elif len(gavresult.version.split('.')) > 3:
            gavresult.version = re.sub( r'-SNAPSHOT$', '', gavresult.version)
        elif gavresult.version.endswith('-SNAPSHOT') and versionNumber.endswith('-SNAPSHOT'):
            gavresult.version = majmin
        elif versionNumber.startswith(gavresult.version) \
                and versionNumber.endswith('-SNAPSHOT') \
                and gavresult.has_no_releases:
            gavresult.version = gavresult.has_no_releases
        if (self.echo):
            print "\nlatest_released_version:\tgav_resolv=%s" % (gavresult)
        return gavresult

    def getMajorMinorVersion(self,versionNumber):
            return self.nexusVersionResolver.get_base_number(versionNumber, True)

    def __firstNumbers(self, versionNumber):
        majmin=[]
        for item in versionNumber.split('.'):
            try:
                n = int(item)
                majmin.append(n)
            except:
                break;
        return majmin

    def increment_version(self, versionNumber, has_no_releases):
        if self.echo:
            print "increment_version:\t\t%s -> %s" % (versionNumber, has_no_releases)
        buildId=0
        has_more_than_3_digits = len(versionNumber.split('.')) > 2
        has_less_than_2_digits = len(versionNumber.split('.')) <= 2
        if has_no_releases:
            has_less_than_2_digits = len(has_no_releases.split('.')) <= 2
            if has_less_than_2_digits:
                return "%s.0" % (has_no_releases)
            else:
                return has_no_releases
        if versionNumber is None:
            raise AttributeError("must supply semantic version number as argument")
        if "-SNAPSHOT" in versionNumber:
            versionNumber = re.sub( r'-SNAPSHOT$', '', versionNumber)
        if has_less_than_2_digits is True:
            return "%s.0" % (versionNumber)
        base_name,rest = self.nexusVersionResolver.get_base_number(versionNumber, False)
        majmin = self.__firstNumbers(versionNumber)
        #print "<2=%s and >2=%s" % (has_less_than_2_digits,has_more_than_3_digits)
        try:
            items=base_name.split('.')
            buildId = -1
            # find the first digit from the right
            words=[]
            nrs=[]
            # 7.0.1.MASTER
            _semantic=list(items)
            for idx, item in enumerate(_semantic):
                if self.echo:
                    print "increment_version:\t\titem = %s dig=%s : %s : %s [%s]" % (item, has_more_than_3_digits, majmin,0, has_no_releases)
                buildId=int(item)
                if idx == len(items)-1 : #and len(majmin) == len(items): # last item increment
                    buildId = buildId + 1
                nrs.append(buildId)
            nrs.extend(rest)
            nn = []
            for n in nrs:
                nn.append(str(n))
            if self.echo:
                print "increment_version-1:\t \t%s" % ('.'.join(nn))
            return '.'.join(nn)
        except IndexError as ie:
            print ie
            if len(base_name.split('.')) > 3:
                number, rest = self.get_base_name(versionNumber, True)
                return number + ".".join(rest)
            elif len(base_name.split('.')) < 2:
                number, rest = self.get_base_name(versionNumber, False)
                return number + ".".join(rest)
            else:
                return versionNumber
