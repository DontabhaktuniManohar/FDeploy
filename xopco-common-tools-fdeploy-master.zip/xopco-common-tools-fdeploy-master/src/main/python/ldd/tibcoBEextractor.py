import xmltodict
import os
import os.path
import ConfigParser
import fdeploy
import re
import logging
import pprint
import ldd
from ldd import get_new_name
from ldd.tibcoextractor import tibcoextractor

def _debug_(*args):
    pass
    #fdeploy.LOGGER.debug(args


class tibcoBEextractor(tibcoextractor):

    def __init__(self,sc_prop_file,opco, level,config_logger=None):
        super(tibcoBEextractor,self).__init__(sc_prop_file, opco, level, config_logger, 'BE')
        self.lookup = self.getHostTranslationFromSilver(self.__config__)
        return

    def getHostTranslationFromSilver(self,parser=None):
    # Define a dictionary of UNIQUE components|stacks based on properties passed in: [component|stack].APP.[common|UNIQUE]
        be_arche={}
        headers=[]
        tlm_to_host={}
        if parser is None:
            parser = self.__config__
        components = {}
        newname = None
        artifactId = None
        comp_index = -1
        # find first name if most configs are in common section
        for section in parser.sections():
            current=section.split('.')
            if len(current) == 3 and current[0] == 'component' and current[len(current)-1] != 'common':
                newname=parser.get(section,'name')
                components[newname]={ 'deployId' : newname }
                break

        # globals
        JMXPORT=None
        QUERY=None
        HOST=None
        for section in parser.sections():
            _debug_( newname, section)
            current = section.split('.')
            resource = "%s.%s.%s.allocationrules.ResourcePreferenceHostname.properties" % (current[0],current[1],current[len(current)-1])
            if resource not in headers:
                headers.append(resource)
            if 'contentfiles' in section and artifactId is None:
                artifactId=parser.get(section,'nexusartifact')

            if current[0] == 'component' and current[len(current)-1] != 'common':
                #if 'common' in section and not 'runtimevariables' in section:
                #    continue
                _debug_( "\n\nanalyzing [%s --> %s]" % (newname,section))
                name = "%s.%s" % (current[1], current[2])
                if len(current) == 3:
                    _debug_( "new component? %s " % (section))
                    if 'query' not in components[newname] and QUERY:
                        components[newname]['query'] = QUERY
                    if 'jmxport' not in components[newname] and JMXPORT:
                        components[newname]['jmxport'] = JMXPORT
                    if 'host' not in components[newname] and HOST:
                        components[newname]['host'] = HOST
                    oldname=newname
                    newname=parser.get(section,'name')
                    if newname != oldname or newname not in components.keys():
                        components[newname]={}
                    _name = re.sub(r'^BE_','',newname)
                    components[newname]['name']=_name
                    components[newname]['artifactId']=artifactId
                    #components[newname]['query']=name
                    components[newname]['deployId']=newname
                    comp_index+=1
                else:
                    #rint "sections: " + str(parser.items(section))
                    if '_JMX_PORT' in section:
                        _debug_( "%s store %s - - - -> %s" % (section, newname, parser.get(section,'value')))
                        components[newname]['jmxport']= parser.get(section,'value')
                        _debug_( str(components))
                    if '_NAME' in section and not 'MEMBER_NAME' in section and not 'TIER_NAME' in section:
                        _debug_( newname, section, parser.get(section,'value'), QUERY)
                        components[newname]['query']= parser.get(section,'value')
                        if not QUERY:
                            QUERY = components[newname]['query']
                _debug_( str(components))
            elif current[0] == 'stack':
                resource = "%s.%s.%s.allocationrules.ResourcePreferenceHostname.properties" % (current[0],current[1],current[len(current)-1])
                for nvp in parser.items(section):
                    if 'components' in nvp:
                        s_array=str(parser.get(section,'components')).split(',')
                        _debug_( "schedule_arr: " + str(s_array))
                        for schedule in s_array:
                            tlm_name = schedule.split(';')
                            _debug_( "assigned to :%s ; %s [%s]" % (tlm_name, schedule, str(tlm_name[0]) in components))
                            if str(tlm_name[0]) in components.keys():
                                _debug_( "\n\nfound host \n")
                                components[str(tlm_name[0])]['host'] = parser.get(resource,'propertyValue')
                                if not HOST:
                                    HOST=parser.get(resource,'propertyValue')

        if len(components.keys()) < 1:
            raise Exception("ERROR: No tlm host found in TLM silver propeties file, check tlm_output.log")
        _debug_( str(components))
        return components



def test():
    ##
    ## ANDREs-MacBook-Pro:python akaan$ export PYTHONPATH=`pwd`
    ## ANDREs-MacBook-Pro:python akaan$ python ldd/tibcoBEextractor.py
    ## Standalone testing of the routines
    ##
    logging.basicConfig(filename="test.log", level=logging.INFO)
    config_logger = ConfigLogger(logging)
    extr = tibcoBEextractor("../../test/resources/sefs.be.properties",'FXF','L1',config_logger)
    #extr.findJmxPorts(extr.doc['application']['services']['bw']['NVPairs']['NameValuePair'])
    extr.extractBindingsAsHost('myartifact')
    #extr.processRepeatingSections()
