import xmltodict
import os
import os.path
import ConfigParser
import fdeploy
import re
import copy
import logging
import json
import fnmatch
import ldd
from ldd.tibcoextractor import tibcoextractor
#from ldd import get_new_name
#,get_base_components,read_bw_bindings

def get_bindings_list(doc):
	eroot = doc['application']['services']['bw']['bindings']['binding']
	if type(doc['application']['services']['bw']['bindings']['binding']) is not list:
		eroot = [eroot]
	return eroot

def read_host_allocation_properties(property_file):
	fdeploy.LOGGER.debug("files =  %s",property_file)
	return ldd.process_property_files(read_properties(property_file,only_tlm=False))
def read_properties(pfiles,only_tlm=True):
	pfiles = [pfiles] if type(pfiles) != list else pfiles
	for pfile in pfiles:
		if not os.path.isfile(str(pfile)):
			#fdeploy.LOGGER.debug(os.path.abspath(str(pfile))
			#fdeploy.LOGGER.debug(str(pfile)
			raise Exception("must be file %s" % (pfile))
		tlm_properties = []
		_files = []
		_dirname = os.path.dirname(pfile)
		_files = os.listdir(_dirname)
		#fdeploy.LOGGER.debug("pdir=%s, files=%s, only_tlm=%s" % (pdir, _files, pattern)
		for _tlm_file in _files:
			_tlm_file = "%s/%s" % (_dirname, _tlm_file)
			if _tlm_file not in tlm_properties and '_TLM' in _tlm_file and not 'Persistent' in _tlm_file and  "properties" in _tlm_file:
				tlm_properties.append(_tlm_file)
		fdeploy.LOGGER.debug(tlm_properties)
		# add the property file.
		tlm_properties.append(pfile)
	return tlm_properties

def get_docs_by_artifactId(docs,artifactId):
	doc_list = []
	for doc in docs:
		#fdeploy.LOGGER.debug(" --> %s -->\n" % (doc)
		if doc['artifactId'] != artifactId:
			fdeploy.LOGGER.debug("[tibcoBWextractor.extractBindingsAsHost] %s %s", doc['artifactId'], doc['documentName'])
		else:
			doc_list.append(doc)
	return doc_list

def get_app_name(doc):
	try:
		return doc['application']['@name']
	except KeyError as keys:
		pass

def get_archive_name(doc):
	archive_name = None
	domain = None
	try:
		archive_name = re.sub(
			r'\.pa.+$', '', doc['application']['services']['bw']['@name'])
	except KeyError as keys:
		try:
			archive_name = doc['application']['@name']
		except KeyError as keys:
			pass
	# Here the rules ... if there is
	# a remoInstanceName the namign will be [repoInstanceName]-[idx]-]appname(par)]
	repo_instance_presence=None
	try:
		# remove the first part %DOMAIN%-fxg-bw-bla-bla to fxg-bw-bla-bla
		domain = "-".join(doc['application']['repoInstanceName'].split('-')[1:])
		fdeploy.trace( "alters     = %s" % (domain))
	except:
		pass
	if archive_name is None:
		archive_name = domain

	archive_name = re.sub(r'\s', '_', archive_name)
	return archive_name

def get_instance_number(doc,value):
	try:
		return doc['application']['services']['bw']['bindings']['binding'][value]
	except:
		return None

def get_num_of_instances(doc):
	return len(doc['application']['services']['bw']['bindings']['binding'])

def get_instance_names(docs, targets):
	instances_list =[]
	appCount = 0
	totalCount = 0
	mapping = {}
	i = 0
	for target in targets:
		(tlm, host) = target.split('@')
		mapping[tlm]=host
		mapping[host]=tlm
	for doc in docs:
		nofinstances = get_num_of_instances(doc)
		totalCount+=1
		app_name = get_app_name(doc)
		archive_name = get_archive_name(doc)
		if i != 0:
			app_name = "%s-%s" % (app_name, i)
		if nofinstances > 1:
			# if there is one document for this artifact just add appname index (i)
			for value in range(0,nofinstances):
				name = __building_instance_name(app_name, archive_name, value)
				tlm = get_instance_number(doc, value)['machine']
				if len(mapping) != 0:
					try:
						host = mapping[tlm]
					except:
						raise Exception("%s not found in mapping %s" % (tlm,mapping))
				else:
					host = 'NA'
				instances_list.append({ 'name' : name, 'host' : host, 'tlm' : tlm, 'instance' : value, 'total' : totalCount, 'app#' : app_name, 'archive_name' : archive_name  })
		else:
			# if there is one documets for this artifact just add appname index (i)
			instances_list.append({ 'name' : app_name, 'instance' : 1, 'total' : 1, 'app#' : app_name, 'archive_name' : archive_name  })
		i+=1
	return instances_list, mapping

def __building_instance_name(app_name, archive_name, value):
	if int(value) < 1:
		return "%s-%s" % (app_name, archive_name)
	else:
		return "%s-%s-%s" % (app_name, archive_name, value)

def get_instance_name(docs,doc,self_domain=None):
	app_name = None
	domain = None
	try:
		app_name = re.sub(
			r'\.pa.+$', '', doc['application']['services']['bw']['@name'])
	except KeyError as keys:
		pass
	# Here the rules ... if there is
	# a remoInstanceName the namign will be [repoInstanceName]-[idx]-]appname(par)]
	repo_instance_presence=None
	try:
		fdeploy.trace("repoInstance = %s" % (doc['application']['repoInstanceName']))
	except:
		fdeploy.trace("repoInstance = %s" % ('NA'))
		pass
	try:
		fdeploy.trace("PP-->Nm        %s" % (doc['application']['@name']))
	except:
		fdeploy.trace("app-->name   = %s" % ('NA'))
		pass
	try:
		# remove the first part %DOMAIN%-fxg-bw-bla-bla to fxg-bw-bla-bla
		shadow_domain = "-".join(doc['application']['repoInstanceName'].split('-')[1:])
		domain = shadow_domain
		fdeploy.trace( "alters     = %s" % (domain))
	except:
		domain = self_domain
		pass
	if app_name is None:
		app_name = domain

	app_name = re.sub(r'\s', '_', app_name)
	instances_list =[]
	if len(get_docs_by_artifactId(docs, doc['artifactId'])) > 1 and doc['instance'] > 1:
		# if there is one document for this artifact just add appname index (i)
		instances_list.append( "%s-%s" % (domain, doc['instance']-1))
	else:
		# if there is one documets for this artifact just add appname index (i)
		instances_list.append( "%s" % (domain))
	return [domain,app_name,doc['instance'], instances_list]


	# collected_bindings =[]
	# for _file in tlm_files:
	# 	if not os.path.isfile(_file):
	# 		raise Exception("Bindings XML File '%s' not existing or readable." % (_file))
	# 	fdeploy.LOGGER.debug("reading '%s'" % (_file)
	# 	with open(_file) as fd:
	# 		__doc = xmltodict.parse(fd.read(), dict_constructor=dict)
	# 		doc['instance']=ii
	# 		doc['documentName']=_file
	# 		doc['artifactId']=artifactId
	# 		doc['binding']=get_bindings_list(__doc)
	# 		doc['file']=_file
	# 		collected_bindings.append(doc)


def locate_source_property_file(fdxcfg, stackName, componentName, contentFile=None):
	# backtrack where this component got loaded from
	found = None
	fdeploy.LOGGER.debug("[silverStacks.locate] %s:%s -> %s",stackName, componentName, contentFile)
	sourceFiles = []
	for pfile in fdxcfg.loadedPropertyFiles:
		if "broker." in pfile:
			continue
		# fdeploy.LOGGER.debug("locate source for [%s] pfile=%s" % (componentName, pfile)
		prsr = ConfigParser.ConfigParser()
		prsr.optionxform = str
		prsr.read(pfile)
		for section in prsr.sections():
			if 'contentfiles' in section:
				# fdeploy.LOGGER.debug("-->", section
				try:
					# fdeploy.LOGGER.debug("content: " , content, "Section", prsr.items(section)
					# if the nexusSaveArchiveName is found in the local archive name
					if contentFile and prsr.get(section, 'nexusSaveArchiveName') in contentFile and len(sourceFiles) == 0:
						#fdeploy.LOGGER.debug("[silverStacks.locate] found in file ", str(pfile)
						found = pfile
						sourceFiles.append(found)
				except:
					pass
			elif 'stack' in section:
				try:
					if 'allocation' not in section:
						pass
						# fdeploy.LOGGER.debug("%20s %s : %s" %(stackName, section, prsr.get(section, "name"))
					if prsr.get(section, "name") in stackName:
						#fdeploy.LOGGER.debug("[silverStacks.locate] %20s %s : %s" % (stackName, section, prsr.get(section, "name"))
						if pfile not in sourceFiles:
							sourceFiles.append(pfile)
				except:
					pass

	# fdeploy.LOGGER.debug(str(self.fdxcfg.loadedPropertyFiles)
	#fdeploy.LOGGER.debug("found: %s" % (str(sourceFiles))
	return sourceFiles


class tibcoBWextractor(tibcoextractor):

	domain = None
	pathName = None
	deployName = None
	total = {}
	tlm_properties = None
	doc = None

	def __init__(self, bindings_files, tibcoxml, property_files, opco, level, artifactId, config_logger=None):
		bindings_files = [bindings_files] if type(bindings_files) is not list else bindings_files
		self.property_files = property_files
		self.lookup, processed_files = read_host_allocation_properties(property_files)
		#fdeploy.LOGGER.debug(str(processed_files), str(property_files)
		#fdeploy.LOGGER.debug(str(self.lookup)
		self.host_lookup = copy.deepcopy(self.lookup)

		self.property_files = processed_files
		self.doc = ldd.read_bw_bindings(bindings_files,artifactId)
		super(tibcoBWextractor, self).__init__(self.property_files, opco, level, config_logger, 'BW')
		# need parser initializaed
		#stack_info = self.getHostTranslationFromSilver(read_host_allocation_properties(self.property_files))
		#fdeploy.LOGGER.debug(json.dump(self.host_lookup)
		ii=1
		self.total={}

		if not os.path.isfile(tibcoxml):
			raise Exception("TIBCO XML File %s not existing or readable." % (tibcoxml))
		#fdeploy.LOGGER.debug("reading %s" % (tibcoxml)
		tibdoc = None
		try:
			with open(tibcoxml) as fd:
				tibdoc = xmltodict.parse(fd.read(), dict_constructor=dict)
				self.pathName = tibdoc['DeploymentDescriptors']['Modules']['pathName']
				self.domain = tibdoc['DeploymentDescriptors']['name']
				for nvp in tibdoc['DeploymentDescriptors']['NameValuePairs'][1]['NameValuePair']:
					if nvp['name'] == 'Deployment':
						self.deployName = nvp['value']
						break
		except:
			pass
		fdeploy.LOGGER.debug("deployName = %s",self.deployName)
		fdeploy.trace(" %s " % (str(self.host_lookup)))
		return

	def get_bindings_list(self,doc):
		eroot = doc['application']['services']['bw']['bindings']['binding']
		if type(doc['application']['services']['bw']['bindings']['binding']) is not list:
			eroot = [eroot]
		return eroot

	def extractBindingsAsHost(self, artifactId):
		# need file checks here for non perfect world scenarios
		machines = {}
		ref = []
		app_name = None
		if artifactId not in self.total:
			self.total[artifactId]=0
		# get the deployment documents list
		doc_list = get_docs_by_artifactId(self.doc, artifactId)
		docIndex = 0
		lmref = {} # logical machine reference
		bla = None

		# go thru documents and find the bindings for this artifactId
		for doc in doc_list:
			bla=get_instance_name(doc_list,doc,self.domain)
			eroot = get_bindings_list(doc)
			for binding in eroot:
				machine = str(binding['machine'])
				#try:
				if machine not in lmref:
					lmref[machine]=1
				else:
					lmref[machine]+=1
		fdeploy.trace("lmref# = %s" % (lmref))
		fdeploy.trace( "bla    = %s" % (bla))
		#fdeploy.LOGGER.debug("%s --8<----8<----> %s" % (artifactId, self.host_lookup)
		for doc in doc_list:
			docIndex += 1
			if doc['artifactId'] != artifactId:
				fdeploy.LOGGER.debug("[tibcoBWextractor.extractBindingsAsHost] %s - %s", doc['artifactId'], doc['documentName'])
				continue
			bla=get_instance_name(doc_list,doc,self.domain)
			eroot = get_bindings_list(doc)
			fdeploy.trace( " > > > > > > > > > docindex[%s] #bindings[%s] bla=%s" % (docIndex, len(eroot), bla))

			index = 0
			# loop thru the bindings
			for binding in eroot:
				machine = str(binding['machine'])
				#
				#fdeploy.LOGGER.debug(str(binding['@name'])
				#fdeploy.LOGGER.debug(json.dumps(binding)
				binding_name = binding['@name']
				if binding_name is None or len(binding_name) == 0:
					binding_name = bla[0]
				app_name = bla[0]
				if docIndex > 1:
					qname = "%s-%s-%s" % (app_name, docIndex-1, binding_name)
				else:
					qname = "%s-%s" % (app_name,binding_name)

				#fdeploy.LOGGER.debug("TIB-BW   - machine [%s] - %s (%s/%s)" % (machine, qname, artifactId, self.total[artifactId])
				key = "_".join(machine.split('_')[2:])
				#fdeploy.LOGGER.debug("key: %s [%s]" % (key, self.host_lookup)
				# fdeploy.LOGGER.debug(self.host_lookup[key]
				# fdeploy.LOGGER.debug("lookup = %s" % (self.lookup[key])
				if key in self.lookup.keys() and 'host' in self.lookup[key]:
					#fdeploy.LOGGER.debug("%s %s" % (key, self.lookup[key])
					host = self.lookup[str(key)]['host']
					tlm = self.lookup[key]['deployId']
					#stack = self.lookup[key]['stack_name']
				else:
					#continue
					raise Exception("%s 'host' not found in %s" % (key,self.host_lookup.keys()))
				jmxport = self.findJmxPorts(doc)
				# double registration just in case the bw/@name does not match the file name
				suffix = re.sub(r'^.+TLM', '', machine)
				key_key = "%s@%s" % (machine,qname)
				#fdeploy.LOGGER.debug("key_key=%s, key=%s, host=%s, app_name=%s, qname=%s\n" % (key_key, key, host, app_name, qname)
				self.total[artifactId] += 1
				qname = self.query_lookup[artifactId] if artifactId in self.query_lookup else qname
				if key_key not in machines:
					machines[key_key]={'machine': str(machine), 'artifactId' : artifactId, 'suffix': "_%02d" % (self.total[artifactId]),
													 'jmxport': jmxport, 'tlm' : tlm,  'host': host, 'query': qname, \
													  }
				index +=1
		if len(machines) < 1:
			fdeploy.LOGGER.warn("No MACHINES found for %s",app_name)
		# uncomment if you want to view the lookup table TLM to host
		# fdeploy.LOGGER.debug(str(self.host_lookup)
		fdeploy.trace("all Machines: " + json.dumps(machines,indent=4))
		return machines

	def findJmxPorts(self, doc, node=None):
		jmxport = None
		_set = [doc['application']['services']
				['bw']['NVPairs']['NameValuePair']]
		if node:
			_set.append(node)
		for __set in _set:
			for nvpair in __set:
				# fdeploy.LOGGER.debug(nvpair['name']
				if 'jmx' in nvpair['name'].lower() and 'port' in nvpair['name'].lower():
					# fdeploy.LOGGER.debug("\nfound pair jmx %s = %s\n" % (nvpair['name'], nvpair['value'])
					jmxport = nvpair['value']
		# return the last found jmxport of the __set
		return jmxport

	def get(self, section, name, required=True):
		try:
			value = self.__config__.get(section, name)
			if self.debug:
				fdeploy.LOGGER.debug("DEBUG: silverConfig.get(%s,%s) found=%s",section, name, value)
			return value
		except:
			if required:
				print("Missing required section=[%s] name=%s",
					str(section), str(name))
			else:
				return ''

	def getHostTranslationFromSilver(self, property_files, parser=None):
		# Define a dictionary of UNIQUE components|stacks based on properties passed in: [component|stack].APP.[common|UNIQUE]
		if parser is None:
			parser = self.__config__
		contents=[]
		components = {}
		artifactId = None

		for section in parser.sections():
			if 'contentfiles' in section and artifactId is None and parser.has_option(section,'nexusArtifact'):
				#fdeploy.LOGGER.debug("%s" % (section)
				artifactId=parser.get(section,'nexusArtifact')
				contents.append(artifactId)
		#fdeploy.LOGGER.debug(str("-------->"), str(contents)
		if len(contents) == 0:
			raise Exception("no content found")
		for artifactId in contents:
			comp_index = 0
			for section in parser.sections():
				current = section.split('.')
				if (current[0] == 'stack'):
					resource = "%s.%s.%s.allocationrules.ResourcePreferenceHostname.properties" % (
						current[0], current[1], current[len(current) - 1])
					for nvp in parser.items(section):
						if 'components' in nvp:
							stack_name = parser.get(
								section, 'components').split(';')[:1]
							components[stack_name[0]]=[]
							__new=ldd.get_new_name(stack_name[0],comp_index-1)
							components[stack_name[0]].append({'name' : __new, 'host' : parser.get(resource, 'propertyValue') })
			#fdeploy.LOGGER.debug(str(components.keys())
			for section in parser.sections():
				current=section.split('.')
				if len(current) == 3:
					if current[0] == 'component' and current[len(current)-1] != 'common':
						base_name=parser.get(section,'name')
						newname=ldd.get_new_name(base_name)
						#if "TLM" in newname or "Persistent" in newname:
						#	continue
						comp_index += 1
						#chash=components[newname][0]
						#fdeploy.LOGGER.debug("---> %s --> %s" % ( newname,  type(components[newname]))

						chash={}
						#chash=chash[0]
						chash.update({'deployId': newname})
						chash.update({'artifactId':artifactId})
						args='parser.get(as_log_section,'
						chash.update({'query': args})
						chash.update({'jmxport': 0})
						machines = self.extractBindingsAsHost(artifactId)
						#fdeploy.LOGGER.debug(str(machines)
						#fdeploy.LOGGER.debug(newname, str(components)

						components[str(stack_name[0])] = machines
		if len(components.keys()) < 1:
			raise Exception(
				"ERROR: No tlm host found in TLM silver propeties file, check tlm_output.log")
		comp_refs={}
		for ckey in components.keys():
			comp_refs[ckey]=components[ckey]
		components = comp_refs
		#fdeploy.LOGGER.debug("components: " + json.dumps(machines,indent=4)
		return components


def test():
	##
	# Standalone testing of the routines
	##
	logging.basicConfig(filename="test.log", level=logging.INFO)
	config_logger = ConfigLogger(logging)
	extr = tibcoBWextractor("../../test/resources/bindings.xml",
							"../../test/resources/sefs.admin.BW_TLM.properties", 'FXG', 'L1', config_logger)
	# extr.findJmxPorts(extr.doc['application']['services']['bw']['NVPairs']['NameValuePair'])
	extr.extractBindingsAsHost('SOEFeed')
	# extr.processRepeatingSections()

# test()
