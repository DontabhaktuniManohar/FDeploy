import xmltodict
import os
import os.path
import ConfigParser
import fdeploy
import re
import logging
import pprint
import ldd
from ldd.tibcoextractor import tibcoextractor

class tibcoMiscextractor(tibcoextractor):

    ADMIN_RESOURCE = 'stack.admin.Default.allocationrules.ResourcePreferenceHostname.properties'

    def __init__(self,sc_prop_file,opco, level,config_logger=None, queryCmd='hawkagent'):
        super(tibcoMiscextractor,self).__init__(sc_prop_file, opco, level, config_logger, 'ADMIN')
        self.lookup = self.getHostTranslationFromSilver(self.__config__,queryCmd)
        return

    def getHostTranslationFromSilver(self,parser=None,queryCmd=None):
    # Define a dictionary of UNIQUE components|stacks bJAVAed on properties passed in: [component|stack].APP.[common|UNIQUE]
        AS_arche={}
        headers=[]
        tlm_to_host={}
        ref=[]
        if parser is None:
            parser = self.__config__
        components = {}
        newname = None
        artifactId = None
        base_name = None
        done = False
        comp_index = 0
        #fdeploy.LOGGER.debug("getHostTransalctions: %s" % (self)
        # find first name if most configs are in common section
        QUERY="hawkagent"
        if queryCmd:
            QUERY=queryCmd
        for section in parser.sections():
            current=section.split('.')
            if len(current) == 3 and current[0] == 'component' and current[len(current)-1] != 'common':
                comp_index += 1
                base_name=newname
                host=''
                if parser.has_section(self.ADMIN_RESOURCE):
                    newname = parser.get(section,'name')
                    host = parser.get(self.ADMIN_RESOURCE, 'propertyValue')
                    components[newname]={ 'deployId' : newname, 'name' : newname, 'jmxport' : '0', 'host' : host, 'query' : QUERY }
                    return components
                else:
                    newname = get_new_name(parser.get(section,'name'),comp_index)
                    artifact = newname #re.sub(r'_?\d$', '', get_new_name(parser.get(section,'name')))
                ref.append(newname)
                components[newname]={ 'deployId' : newname, 'name' : artifact, 'jmxport' : '0', 'host' : host, 'query' : QUERY }

        #fdeploy.LOGGER.debug("read  %s TLM names" % (ref)
        # globals caputiring .common. runtimevariables
        JMXPORT=""
        for section in parser.sections():
            if done == True:
                break
            #fdeploy.LOGGER.debug(newname, section
            current = section.split('.')
            #fdeploy.LOGGER.debug("(%20s) %s" % (newname, components[newname])
            if current[0] == 'stack':
                #fdeploy.LOGGER.debug("her8: %s" % (components[newname])
                # if parser.has_section('stack.admin.Default.allocationrules.ResourcePreferenceHostname.properties'):
                #     __new = newname
                #     fdeploy.LOGGER.debug("\tfound host %s for key[%s] >> " % (parser.get('stack.admin.Default.allocationrules.ResourcePreferenceHostname.properties','propertyValue'),__new)
                #     components[__new]['host'] = parser.get('stack.admin.Default.allocationrules.ResourcePreferenceHostname.properties','propertyValue')
                #     components[__new]['query'] = QUERY
                #     done=True
                #     break
                resource = "%s.%s.%s.allocationrules.ResourcePreferenceHostname.properties" % (current[0],current[1],current[len(current)-1])
                #fdeploy.LOGGER.debug("lookup section: %s (%s)" % (resource, section)
                #fdeploy.LOGGER.debug(str(parser.items(section))
                for nvp in parser.items(section):
                    #fdeploy.LOGGER.debug("%40s %s" % (section,nvp)
                    if 'components' in nvp:
                        #fdeploy.LOGGER.debug("stack [%s] section; %s" % (newname,section)
                        for schedule in parser.get(section,'components').split(","):
                            tlm_name = schedule.split(';')[:1]
                            # add an index to the name if the name does not have an number at the end.
                            if parser.has_section(resource):
                                __new = get_new_name(tlm_name[0],comp_index-1)
                            if __new in components.keys():
                                #fdeploy.LOGGER.debug("%s ==> %s keys%s" % (__new,__new in components.keys(),components.keys())
                                #fdeploy.LOGGER.debug("\tfound host %s for key[%s] >> " % (parser.get(resource,'propertyValue'),__new)
                                components[__new]['host'] = parser.get(resource,'propertyValue')
                                components[__new]['query'] = QUERY
                                #fdeploy.LOGGER.debug(str(components[newname])
        if 'query' not in components[newname]:
            components[newname]['query']=QUERY

        if len(components.keys()) < 1:
            raise Exception("ERROR: No tlm host found in TLM silver propeties file, check tlm_output.log")
        # for comp in components.keys():
        #     #if 'host' not in components[comp]:
        #         fdeploy.LOGGER.debug("[%10s] %s" % (comp,components[comp])
        return components



def test():
    ##
    ## ANDREs-MacBook-Pro:python akaan$ export PYTHONPATH=`pwd`
    ## ANDREs-MacBook-Pro:python akaan$ python ldd/tibcoBEextractor.py
    extr = tibcoMiscextractor(["../../test/resources/sefs.admin.properties"],'FXF','L3')
    #extr = tibcoMiscextractor(["../../test/resources/sefs.admin.properties","../../test/resources/comp.admin.common.properties"],'FXF','L3')
    #extr = tibcoMiscextractor(["../../test/resources/sefs.admin.BW_TLM.properties", "../../test/resources/sefs.admin.BW_TLM_VM.properties"],'FXF','L3')
    fdeploy.LOGGER.debug("REPORT")
    fdeploy.LOGGER.debug("======")
    for c in extr.lookup.keys():
        fdeploy.LOGGER.debug("%20s %s" ,c,str(extr.lookup[c]))

#test()
