import unittest2
import sys
import fdeploy
import inspect
from ldd.tibcoBWextractor import tibcoBWextractor, read_host_allocation_properties, get_docs_by_artifactId
from ldd import read_bw_bindings

import os

class TestBWExtractorMethods(unittest2.TestCase):

    extractor = None

    def setUp(self):
        #fdeploy.LOGGER.debug(">>> init >>>"
        tibco_file = '../../test/resources/sefs_suAddrChgFeedTIBCO.xml'
        bindings = '../../test/resources/sefs_suAddrChgFeed_template.xml'
        property_files = ['../../test/resources/sefs.admin.BW_TLM.properties','../../test/resources/sefs.bw.suAddrChgFeed.properties']
        self.extractor = tibcoBWextractor([bindings],tibco_file,property_files,
            'FXE','L4','sefs_suAddrChgFeed')
        self.assertEquals(29, len(self.extractor.lookup.keys()))
        self.assertEquals(1,len(self.extractor.doc))

    def test_read_host_allocation_properties_exception(self):
        ##sys.stderr.write("%s\n" % (inspect.stack()[0][3]))
        with self.assertRaises(Exception):
            read_host_allocation_properties('../../test/resources/FXFBLANBA-SC')

    def test_read_host_allocation_properties(self):
        ##sys.stderr.write("%s\n" % (inspect.stack()[0][3]))
        components, property_files = read_host_allocation_properties('../../test/resources/FXF-SC/L4/sefs.bw.FXFEquipFeed.AppManage.properties')
        self.assertEquals(1, len(property_files))
        self.assertEquals("../../test/resources/FXF-SC/L4/sefs.bw.FXFEquipFeed.AppManage.properties",property_files[0] )

    def test_read_bw_bindings(self):
        ##sys.stderr.write("%s\n" % (inspect.stack()[0][3]))
        docs = read_bw_bindings(['../../test/resources/sefs_suAddrChgFeed_template.xml'],'sefs_suAddrChgFeed')
        self.assertEquals(1, len(docs))

    # def test_locate_source_properties(self):
    #     #sys.stderr.write("%s\n" % (inspect.stack()[0][3]))
    #     import fedex
    #     fdxcfg=fedex.silverConfig()
    #     fdxcfg.readConfig(["../../test/resources/FXF-SC/L1/sefs.admin.BW_TLM.properties", "../../test/resources/FXF-SC/L2/sefs.bw.FXFShipFeed.AppManage.properties","../../test/resources/FXF-SC/L1/broker.common.properties","../../test/resources/FXF-SC/L1/broker.properties","../../test/resources/FXF-SC/L1/comp.bw.common.properties" ])
    #     fdxComponents = fedex.silverComponents(fdxcfg)
    #     fdxStacks = fedex.silverStacks(fdxcfg)
    #     files = fdxStacks.locate_source_propety_file( 'BW_AppManage_FXFShipFeedStack', 'BW_AppManage_FXFShipFeed', 'FXFShipFeed.ear')
    #     self.assertEquals(1, len(files))

    # def test_extractor_instantiating(self):
    #     #sys.stderr.write("%s\n" % (inspect.stack()[0][3]))
    #     import fedex
    #     _files = ["../../test/resources/FXF-SC/L2/sefs.bw.FXFShipFeed.AppManage.properties",\
    #     "../../test/resources/FXF-SC/L2/broker.common.properties",\
    #     "../../test/resources/FXF-SC/L2/broker.properties",\
    #     "../../test/resources/FXF-SC/L2/comp.bw.common.properties" ]
    #     fdxcfg=fedex.silverConfig()
    #     fdxcfg.readConfig(_files)
    #     fdxComponents = fedex.silverComponents(fdxcfg)
    #     fdxStacks = fedex.silverStacks(fdxcfg)
    #     files = fdxStacks.locate_source_propety_file( 'BW_AppManage_FXFShipFeedStack', 'BW_AppManage_FXFShipFeed', 'FXFShipFeed.ear')
    #     self.assertEquals(1, len(files))
    #     self.assertEquals('../../test/resources/FXF-SC/L2/sefs.bw.FXFShipFeed.AppManage.properties', files[0])
    #     components, property_files = read_host_allocation_properties(_files)
    #     self.assertEquals('../../test/resources/FXF-SC/L2/sefs.admin.BW_TLM.properties', property_files[0])
    #     binding = os.path.abspath('../../test/resources/FXF-SC//config/L2/FXFShipFeed_template.xml')
    #     files.extend(property_files)
    #     fdeploy.LOGGER.debug("####> %s" % (files)
    #     extractor = tibcoBWextractor(binding, '../../test/resources/FXF-SC/config/TIBCO.xml', files, 'FXF', 'L2', 'FXFShipfeed')
    #     fdeploy.LOGGER.debug("\n\n%s\n\n" % (extractor.host_lookup)
    #     # two TLM's and one BW process = 3
    #     self.assertEquals(len(extractor.lookup.keys()),2)
    #     doc = get_docs_by_artifactId(extractor.doc, 'FXFShipfeed')
    #     self.assertIsNotNone(doc)
    #     self.assertEquals(1,len(doc))
    #     #fdeploy.LOGGER.debug(str(doc)
    #     #fdeploy.LOGGER.debug(str(doc[0]['application']['services']['bw']['bindings']['binding'])
    #     self.assertEquals(2, len(doc[0]['application']['services']['bw']['bindings']['binding']))
    #     tlm_array = extractor.extractBindingsAsHost('FXFShipfeed')
    #     # two TLM's / one BW process
    #     self.assertEquals(2, len(tlm_array))

    def basic_test_on_suAddrChgFeed(self,ret):
        #sys.stderr.write("%s\n" % (inspect.stack()[0][3]))
        self.assertEquals(1,len(self.extractor.doc))
        self.assertEquals('sefs_suAddrChgFeed', self.extractor.doc[0]['artifactId'])
        self.assertEquals(1,len(ret))

    # bindings_files, tibcoxml, tlm_bindings,
    #     def __init__(self, bindings_files, tibcoxml, tlm_bindings, opco, level, artifactId, config_logger=None):
    def test_bw_doc_by_artifact(self):
        #sys.stderr.write("%s\n" % (inspect.stack()[0][3]))
        ret=get_docs_by_artifactId(self.extractor.doc, 'sefs_suAddrChgFeed')
        self.basic_test_on_suAddrChgFeed(ret)
        doc=ret[0]
        eroot = doc['application']['services']['bw']['bindings']['binding']
        self.assertEquals(7, len(eroot))
        self.assertEquals('FXE_L4_FXE_BW_TLM_2', eroot[0]['machine'])

    def test_get_bindings(self):
        #sys.stderr.write("%s\n" % (inspect.stack()[0][3]))
        ret=self.extractor.get_bindings_list(self.extractor.doc[0])
        self.assertEquals(7,len(ret))
        self.assertEquals('FXE_L4_FXE_BW_TLM_4', ret[6]['machine'])
        self.assertEquals('FXE_L4_FXE_BW_TLM_3', ret[5]['machine'])

    def test_extractBindingsAsHost(self):
        #sys.stderr.write("%s\n" % (inspect.stack()[0][3]))
        ret=self.extractor.extractBindingsAsHost('sefs_suAddrChgFeed')
        self.assertEquals(4, len(ret))
        #fdeploy.LOGGER.debug(ret['FXE_L4_FXE_BW_TLM_3@SUADDRCHGFeed-SUADDRCHGFeed'])
        self.assertEquals('FXE_L4_FXE_BW_TLM_3', ret['FXE_L4_FXE_BW_TLM_3@SUADDRCHGFeed-SUADDRCHGFeed']['machine'])

    def test_jmx_port(self):
        #sys.stderr.write("%s\n" % (inspect.stack()[0][3]))
        ret=self.extractor.findJmxPorts(self.extractor.doc[0])
        self.assertEquals(1, len(self.extractor.doc))
        self.assertEquals('29020',ret)

    def test_bw_singler(self):
        #sys.stderr.write("%s\n" % (inspect.stack()[0][3]))
        self.assertEquals(29, len(self.extractor.lookup.keys()))
        self.assertEquals(25, len(self.extractor.host_lookup.keys()))
        fdeploy.LOGGER.debug(self.extractor.host_lookup.keys())
        fdeploy.LOGGER.debug("%s",self.extractor.extractBindingsAsHost('sefs_suAddrChgFeed'))
        fdeploy.LOGGER.debug(self.extractor.host_lookup.keys())
        self.assertTrue( 'BW_AppManage_suAddrChgFeed' in self.extractor.host_lookup.keys())
        rec=self.extractor.host_lookup['BW_AppManage_suAddrChgFeed']
        self.assertEquals(dict,type(rec))



if __name__ == '__main__':
    unittest.main()
