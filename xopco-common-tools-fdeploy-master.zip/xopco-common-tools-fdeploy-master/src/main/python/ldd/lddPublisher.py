# -*- coding: utf-8 -*-

import os
import os.path
import sys
import contextlib
import zipfile
import re
import fdeploy
import ConfigParser
import requests
import dns.resolver
import ldd
#from ldd.tibcoBWextractor import tibcoBWextractor
from ldd.tibcoBWextractor import get_instance_name
from ldd.tibcoBWextractor import get_instance_names, get_app_name, get_num_of_instances, get_archive_name

from fdeploy.nexusVersionResolver import nexusVersionResolver
from fdeploy.segment import track_statistics

def dns_cname(host):
    # first see if there is an alias
    try:
        answers = dns.resolver.query(host, 'CNAME')
        fdeploy.trace('query qname: %s num ans. %s' % (answers.qname,  len(answers)))
        # print "\n\n"
        # #print answers.__dict__['response'].__dict__
        # print "\n"
        # print answers.__dict__
        # print "\n"
        # #print answers.__dict__['rrset'].__dict__
        # print "\n\n"
        for rdata in answers:
            target = re.sub(r'\..+$', '', str(rdata.target))
            fdeploy.LOGGER.debug('cname target address: %s',target)
            return target,host
    except:
        pass
    # when arriving here there was not CNAME available
    hosts=[]
    if host.find('.') < 0:
        hosts.append( "%s.ute.fedex.com" % (host))
        hosts.append( "%s.test.cloud.fedex.com" % (host))
    for qhost in hosts:
        try:
            answers = dns.resolver.query(qhost)
            print answers
            # if answer is found
            for rdata in answers:
                target = re.sub(r'\..+$', '', str(answers.qname))
                qname = re.sub(r'\.$','', str(answers.qname))
                return target, qname
        except Exception as err:
            pass
    return host, host



class lddPublisher(object):

    options = None
    base_dir = None
    level = None
    queue = None
    queue_ref = []
    resolver = None

    def normalize_level(self, level):
        if level.startswith('L'):
            m = re.match('^(L[0-9])', level)
            level = m.groups()[0]
        elif level.startswith('PR'):
            m = re.match('^(PRO?D)',level)
            level = m.groups()[0]
        else:
            raise Exception('level notation %s not supported must start with L1/2/3/4/5/6 or PRD/PROD.')
        return level

    def __init__(self,level,options,base_dir,resolver):
        self.base_dir = base_dir
        self.options = options
        self.level = level
        self.resolver = resolver
        self.queue = []
        self.ldd_url = 'http://c0009869.test.cloud.fedex.com:8090/sefs-dashboard'
        defaults=None
        if type(self.options) == dict:
            if 'defaults' in self.options:
                defaults = self.options['defaults']
        elif ('defaults' in self.options.__dict__):
            defaults = self.options.defaults
        if defaults is not None:
            if 'ldd_url' in defaults:
                self.ldd_url = defaults['ldd_url']
                fdeploy.LOGGER.warn("overwriting LDD url to '%s'" % (self.ldd_url))

    ''' needed for publishing : artifact : {version,artifactId}, comp : { source}, level, targets'''
    def publish(self,level, artifact,comp,meta_data=None):
        fdeploy.LOGGER.info(" artifact %s / version %s" % (artifact.artifactId, artifact.version))
        if artifact.version is None:
            fdeploy.warn("skipping artifact %s, since there is no version available." % (artifact))
        fdeploy.LOGGER.debug("publishing %s in %s for %s specified in %s" % (artifact.artifactId, level, artifact.version,comp.source))
        # extracting the opco or app group
        targets = None
        for _level in comp.levels:
            if level.startswith(_level['level']):
                targets = fdeploy.flatten_level_targets(_level['targets'],self.options.group, self.options.regex)
        if targets is None:
            raise Exception(">>>no targets for this environment")
        fdeploy.trace("using selected targets: %s" % (targets) )
        self.queue_query_request('register', comp,artifact,level,targets,'publish', self.queue)

    ''' gathering unpublishing requests and queue them up '''
    def unpublish(self,level, artifact, comp):
        fdeploy.LOGGER.info(" artifact %s / version %s in level %s" % (artifact.version, artifact.artifactId, level))
        fdeploy.LOGGER.debug("unpublishing %s for %s specified in %s" % (artifact.artifactId, artifact.version,comp.source))
        # extracting the opco or app group
        targets = None
        for _level in comp.levels:
            if level.startswith(_level['level']):
                targets = fdeploy.flatten_level_targets(_level['targets'],self.options.group, self.options.regex)
        if targets is None:
            raise Exception(">>>no targets for this environment")
        fdeploy.trace("using selected targets: %s" % (targets) )
        self.queue_query_request('unregister', comp,artifact,level,targets,'unpublish', self.queue)


    def unpublishRequests(self, path="unregisterApplications", message="unpublishing"):
        self.__doRequests(path, message)

    def publishRequests(self,path="registerApplications", message="publishing"):
        self.__doRequests(path, message)

    def reportRequests(self,path="registerApplications", message="publishing"):
        self.__doRequests(path, message, None, True)


    def fdeployBWQueryHost(self,level, comp,artifact, targets, host_name):
        # Download the artifact and extract it ...
        if self.resolver is None:
            raise Exception("resolver is required for BW")
        found = self.resolver.resolveGavs(comp, True)
        if not found:
            raise Exception("component %s cannot be resolved or found" %(comp))
        deployment_config_xml, tibcoxml = fdeploy.extract_deployment_xml(level, artifact.archiveFileName, \
            'tmp/target', artifactId=artifact.artifactId)
        docs = ldd.read_bw_bindings(deployment_config_xml, artifact.artifactId)
        instances, mapping = get_instance_names(docs,targets)
        queries = []
        for instance in instances:
            if  host_name == instance['host']:
                queries.append( instance )
        return queries


    def queue_query_request(self, operation, comp, artifact, level, targets, message, __queue):
        _COM=re.compile('.+\/config\.(\w+)\/.*')
        m = _COM.match(comp.source)
        if artifact.version is None and 'unregister' != operation:
            fdeploy.LOGGER.error("no archive found for %s" % (artifact))
            return

        if ('app_group' in self.options or (m is not None and m.group(1))):
            app_group = m.group(1) if (m is not None and m.group(1)) else self.options.app_group
            fdeploy.LOGGER.info("publishing for app_group %s to %d hosts" % (app_group,len(targets)))
            index = 1
            for host_name in targets:
                fdeploy.trace(host_name)
                if 'TIBCO_BW' == comp.lddtype.upper() or 'TIBCO_BW2' == comp.lddtype.upper():
                    COM=re.compile('(\S+)\@([a-z0-9-\._]+)')
                    h = COM.match(host_name)
                    if h is not None and h.group(2):
                        if 'register' == operation or operation == 'publish':
                            instances = self.fdeployBWQueryHost(level, comp, artifact,targets, h.group(2))
                            #fdeploy.LOGGER.debug(instances
                            for query in instances:
                                req = self.__create_publish_request(
                                    comp.lddtype,query['host'],artifact,operation,app_group,\
                                    query['name'],level,index)
                                if req:
                                    __queue.append(req)
                                    self.queue_ref.append(str(req['deployId']))
                                    index += 1
                        elif 'unregister' == operation or 'unpublish' == operation:
                            req = self.__create_publish_request(
                                comp.lddtype,h.group(2),artifact,operation,app_group,\
                                'query',level,index)
                            if req:
                                __queue.append(req)
                                self.queue_ref.append(str(req['deployId']))
                                index += 1


                else:
                    qname = artifact.artifactId
                    COM=re.compile('(\S+)\@([a-z0-9-\._]+):.+')
                    # overwrite query from json
                    #fdeploy.LOGGER.debug(str(comp.rtv)

                    for query_key in comp.rtv:
                        if 'name' in query_key.keys() and query_key['name'] == "QUERY":
                            fdeploy.LOGGER.debug('overwriting calculated query %s with %s.' % (qname,query_key['value']) )
                            qname = query_key['value']
                            break
                    h = COM.match(host_name)
                    #fdeploy.LOGGER.debug(str(h)
                    fdeploy.trace("%s -> %s" % (comp.rtv,qname))
                    if h is not None and h.group(2):
                        req = self.__create_publish_request(\
                            comp.lddtype,h.group(2),artifact,operation,app_group,qname,level,index)
                        if req:
                            __queue.append(req)
                            self.queue_ref.append(str(req['deployId']))
                            index += 1
                    else:
                        fdeploy.LOGGER.debug("targets=%s, comp=%s",targets, comp.lddtype)
                        fdeploy.LOGGER.info("no host found in %s", host_name)
        else:
            fdeploy.LOGGER.debug("no opco/app_group found in %s" % (comp.source))

    def __create_publish_request(self, lddtype, host, artifact, operation,app_group, query, level,index):
        _type = re.sub( r'TIBCO_', '',lddtype.upper())
        cname,fqname = dns_cname(host)
        cname = cname.lower()
        fqname = fqname.lower()
        deployId = "%s_%s" % (artifact.artifactId, index)
        deploy_id_act= "%s@%s" % (deployId,operation)
        if str(deploy_id_act) not in self.queue_ref:
            return {'deployId': str(deployId), 'artifactId' : str(artifact.artifactId), 'version' : str(artifact.version), \
                'level' : str(level), 'opco' : str(app_group), 'queryHost' : str(cname), \
                'host' : str(fqname), 'queryCmd' : str(query), 'type' : str(_type)}
        return None


    def doRequests(self, path='unregisterApplications', message='unpublishing', queue=None):
        self.__doRequests(path, message, queue)

    ''' BATCH DEPLOYMENT REGISTRATION '''
    def __doRequests(self, path='unregisterApplications', message='unpublishing', queue=None, reportOnly=False):
        if queue is not None:
            self.queue = queue
        if self.queue is None or len(self.queue) == 0:
            raise Exception("no requests in queue, publish or unpublish first on the service")
        for req in self.queue:
            level = self.normalize_level(req['level'])
            if req['level'] != level:
                req['level']=level
        requrl = "%s/api/public/query/%s" % ( self.ldd_url, path)
        fdeploy.LOGGER.info("%s to %s",message,requrl)
        fdeploy.LOGGER.debug("issuing request to %s for %s",path, requrl)
        fdeploy.LOGGER.debug("issued request: ",self.queue)
        if reportOnly == False:
            ret = requests.post(requrl, json=self.queue, proxies=fdeploy.FDX_PROXIES)
            response = 'successful' if ret.ok in [200, 201] or ret.ok == True else "failed: code %s" % (ret.ok)
            fdeploy.LOGGER.info("last artifact registered: %s %s - %s" % (message, req['artifactId'], req['version']))
        if reportOnly == True:
            self.reporting()
        track_statistics(self.queue, message)

    def refresh(self,level):
        fdeploy.LOGGER.info("refreshing %s" % (level))
        m =  re.match('^(.+:).+',self.ldd_url)
        if m and m.groups():
            # refresh_url = "%s7003/ping" % (m.groups()[0])
            # fdeploy.trace("refreshing harvester with by calling %s" % (refresh_url))
            # ret = requests.get(refresh_url, proxies=fdeploy.FDX_PROXIES)
            # response = 'successful' if ret.ok in [200, 201] or ret.ok == True else "failed: code %s" % (ret.ok)
            # fdeploy.LOGGER.debug("LDD     - refresh response %s",response)
            pass
        else:
            fdeploy.LOGGER.debug("LDD     - refresh response %s",response)
            fdeploy.LOGGER.error("failed to send refresh, skipping %s",self.ldd_url)

    def reporting(self):
        index = 1
        report = []
        fdeploy.trace( str(self.queue))
        for req in self.queue:
            fdeploy.LOGGER.debug( "%s of %s : %s",index,len(self.queue), req)
            report.append( "%03d | %4s | %15s | %30s | %30s | %60s | %s  " % (index, req['type'], req['queryHost'], req['artifactId'], req['deployId'], req['queryCmd'],  req['host'] ))
            index += 1
        file = open("Reporting.log", "w")
        for report_line in report:
            file.write("%s\n" % (report_line))
        fdeploy.LOGGER.warn("see Reporting.log for details")



#
# for level in ['L4', 'L4B', 'PROD', 'PRD-COS', 'L4C-COS']:
#     fdeploy.LOGGER.debug("BEFORE %s" % (level)
#     if level.startswith('L'):
#         m = re.match('^(L[0-9])', level)
#         level = m.groups()[0]
#     elif level.startswith('PR'):
#         m = re.match('^(PRO?D)',level)
#         level = m.groups()[0]
#     else:
#         raise Exception('level notation %s not supported must start with L1/2/3/4/5/6 or PRD/PROD.')
#     fdeploy.LOGGER.debug("AFTER %s" % (level)
