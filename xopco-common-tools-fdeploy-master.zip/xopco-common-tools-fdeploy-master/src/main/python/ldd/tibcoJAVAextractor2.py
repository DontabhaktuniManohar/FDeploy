import xmltodict
import os
import os.path
import ConfigParser
import fdeploy
import re
import logging
import pprint
import ldd
from ldd.tibcoextractor import tibcoextractor

def hasNumbers(inputString):
    return any(char.isdigit() for char in inputString)


class tibcoJAVAextractor(tibcoextractor):

    def __init__(self,sc_prop_file,opco, level,config_logger=None):
        super(tibcoJAVAextractor,self).__init__(sc_prop_file, opco, level, config_logger, 'JAVA')
        #self.lookup = self.getHostTranslationFromSilver(self.__config__)
        return

    def getHostTranslationFromSilver(self,parser=None):
        # Define a dictionary of UNIQUE components|stacks based on properties passed in: [component|stack].APP.[common|UNIQUE]
        if parser is None:
            parser = self.__config__
        components = {}
        newname = None
        artifactId = None
        comp_index = 0

        contents=[]

        for section in parser.sections():
            fdeploy.LOGGER.debug(section)
            if 'contentfiles' in section and artifactId is None:
                if parser.has_option(section,'nexusArtifact'):
                    artifactId=parser.get(section,'nexusArtifact')
                    contents.append(artifactId)
                elif parser.has_option(section,'localFile') and 'asmm' in parser.get(section,'localFile'):
                    artifactId='asmm'
                    contents.append(artifactId)
            elif 'archivefiles' in section and artifactId is None:
                if parser.has_option(section,'nexusArtifact'):
                    artifactId=parser.get(section,'nexusArtifact')
                    if 'as-query' in artifactId:
                        artifactId = 'org.apache.catalina.tomcat'
                    contents.append(artifactId)


        for artifactId in contents:
            comp_index = 0
            # find first name if most configs are in common section
            for section in parser.sections():
                current=section.split('.')
                if current[0] == 'stack':
                    resource = "%s.%s.%s.allocationrules.ResourcePreferenceHostname.properties" % (current[0],current[1],current[len(current)-1])
                    for nvp in parser.items(section):
                        if 'components' in nvp:
                            #fdeploy.LOGGER.debug("stack [%s] section; %s" % (newname,section)
                            for schedule in parser.get(section,'components').split(","):
                                tlm_name = schedule.split(';')[:1]
                                components[tlm_name[0]]=[]
                                # add an index to the name if the name does not have an number at the end.
                                if hasNumbers(tlm_name[0]) == False:
                                    comp_index = 2
                                __new=self.get_new_name(tlm_name[0],comp_index-1)
                                components[tlm_name[0]].append({ 'name' : __new, 'host' : parser.get(resource,'propertyValue') })
            for section in parser.sections():
                current=section.split('.')
                if len(current) == 3:
                    if current[0] == 'component' and current[len(current)-1] != 'common':
                        comp_index += 1
                        base_name=parser.get(section,'name')
                        newname=self.get_new_name(base_name,comp_index)
                        if newname not in components:
                            newname = base_name
                        chash=components[newname][0]
                        chash['deployId']=newname
                        chash['artifactId']=artifactId
                        if 'org.apache.catalina.tomcat' in artifactId:
                            chash['query']="org.apache.catalina.startup.Bootstrap start"
                            chash['jmxport']= '0'
                            continue
                        as_leech_section="%s.%s.common.runtimevariables.UNIX_START_COMMAND_ARGS" % (current[0],current[1])
                        as_leech_section2="%s.runtimevariables.UNIX_START_COMMAND_ARGS" % (section)
                        if parser.has_section(as_leech_section2):
                            as_leech_section = as_leech_section2

                        fdeploy.LOGGER.debug("--> comp=%s, section=%s, newname=%s" % (section, as_leech_section, newname))
                        if parser.has_section(as_leech_section):
                            args=parser.get(as_leech_section,'value').split(' ')
                            if 'analytics' in newname.lower():
                                chash['query']="com.fedex.sefs.analytics.AnalyticsDriver"
                                chash['jmxport']= args[len(args)-1]
                            elif 'asmm' in newname.lower():
                                chash['query']="java -jar asmm.jar"
                                chash['jmxport']= '0'
                            elif 'purge' in newname.lower():
                                chash['query']='sefs_purge.zip_Files/scripts/startSilver.sh'
                                chash['jmxport']= args[len(args)-1]
                            elif 'sefsosv' in newname.lower():
                                chash['query']="bin/%s" % artifactId
                                chash['jmxport']= args[len(args)-2].split("=")[:2][1]
                            else:
                                if len(args) != 0: # noargs found in start command
                                    id=args[len(args)-1].split('.')
                                    #fdeploy.LOGGER.debug(str(args), newname
                                    #fdeploy.LOGGER.debug(str(chash)
                                    chash['query']= "%s -autojoin" % (id[1])
                                    chash['jmxport']= args[len(args)-3]
                        else:
                            fdeploy.LOGGER.debug("no as_log section found for %s" % (section)
        comp_refs={}
        for ckey in components.keys():
            comp_refs[ckey]=components[ckey][0]
        components = comp_refs
        return components

    # def oldgetHostTranslationFromSilver(self,parser=None):
    # # Define a dictionary of UNIQUE components|stacks bJAVAed on properties passed in: [component|stack].APP.[common|UNIQUE]
    #     AS_arche={}
    #     headers=[]
    #     tlm_to_host={}
    #     ref=[]
    #     if parser is None:
    #         parser = self.__config__
    #     components = {}
    #     newname = None
    #     artifactId = None
    #     base_name = None
    #     comp_index = 0
    #     # find first name if most configs are in common section
    #     for section in parser.sections():
    #         current=section.split('.')
    #         if len(current) == 3 and current[0] == 'component' and current[len(current)-1] != 'common':
    #             comp_index += 1
    #             base_name=newname
    #             newname=self.get_new_name(parser.get(section,'name'),comp_index)
    #             ref.append(newname)
    #             components[newname]={ 'deployId' : newname }
    #             break
    #
    #     # globals caputiring .common. runtimevariables
    #     JMXPORT=None
    #     QUERY=None
    #     for section in parser.sections():
    #         #fdeploy.LOGGER.debug(newname, section
    #         current = section.split('.')
    #         resource = "%s.%s.%s.allocationrules.ResourcePreferenceHostname.properties" % (current[0],current[1],current[len(current)-1])
    #         if resource not in headers:
    #             headers.append(resource)
    #         if 'contentfiles' in section and artifactId is None and parser.has_option(section,'nexusArtifact'):
    #             artifactId=parser.get(section,'nexusArtifact')
    #         elif 'artifactId' in components[newname].keys():
    #             artifactId=components[newname]['artifactId']
    #             #fdeploy.LOGGER.debug("in section: %s => %s" % (artifactId,section)
    #         #fdeploy.LOGGER.debug("(%20s) %s" % (newname, components[newname])
    #         if current[0] == 'component' and current[len(current)-1] != 'common':
    #             #if 'common' in section and not 'runtimevariables' in section:
    #             #    continue
    #             #fdeploy.LOGGER.debug("\n\nanalyzing [%s --> %s]" % (newname,section)
    #             name = "%s.%s" % (current[1], current[2])
    #             if len(current) == 3:
    #                 # back fiill if jmxport and query were not found but were found on a global level
    #                 #fdeploy.LOGGER.debug("new []%s[] store %s - - [end] - -> %s" % (section, newname, components[newname])
    #                 #fdeploy.LOGGER.debug("QUERY = %s" % (QUERY)
    #                 #fdeploy.LOGGER.debug("JMXPORT = %s" % (JMXPORT)
    #                 if 'query' not in components[newname] and QUERY:
    #                     components[newname]['query'] = QUERY
    #                 if 'jmxport' not in components[newname] and JMXPORT:
    #                     components[newname]['jmxport'] = JMXPORT
    #                 oldname=base_name
    #
    #                 newname=self.get_new_name(parser.get(section,'name'),comp_index)
    #                 #fdeploy.LOGGER.debug("[starting] %s (exists=%s) [sixe=%s]" % (newname, newname in components.keys(), len(components.keys()))
    #
    #                 if len(components.keys()) > 1:
    #                     #fdeploy.LOGGER.debug("her1:"
    #                     if newname not in ref:
    #                         ref.append(newname)
    #                         #fdeploy.LOGGER.debug("her2: []%s] %s" % (newname, None)
    #                         components[newname]={}
    #                         if QUERY:
    #                             components[newname]['query']= QUERY
    #                         if JMXPORT:
    #                             components[newname]['jmxport']= JMXPORT
    #
    #                     else:
    #                         # already processed
    #                         fdeploy.LOGGER.debug("already processed: %s " % (newname)
    #                         continue
    #                 else:
    #                     if newname not in components:
    #                         components[newname]={}
    #                     if 'name' not in components[newname]:
    #                         components[newname]['name'] = name
    #                     if 'artifactId' not in components[newname]:
    #                         components[newname]['artifactId'] = artifactId
    #                     #fdeploy.LOGGER.debug("what %s" % (components[newname])
    #                 _name = re.sub(r'^BE_','',newname)
    #                 #_name = re.sub(r'^AS_','',newname)
    #                 components[newname]['name']=_name
    #                 #components[newname]['name']=name
    #                 components[newname]['artifactId']=artifactId
    #                 #fdeploy.LOGGER.debug("her5: %s" % (components[newname])
    #                 components[newname]['deployId']=newname
    #                 if JMXPORT:
    #                     components[newname]['jmxport'] = JMXPORT
    #                 comp_index+=1
    #                 #fdeploy.LOGGER.debug("her6: %s %s" % (components[newname], section)
    #             else:
    #                 #fdeploy.LOGGER.debug("her7:"
    #                 if True == False:
    #                     try:
    #                         fdeploy.LOGGER.debug("- - - ->[%40s]: %s" %  (section, parser.get(section,'value'))
    #                     except ConfigParser.NoOptionError:
    #                         pass
    #                 #fdeploy.LOGGER.debug("sections: %s / %s" % (section, newname)
    #                 if 'tomcat' in section.lower():
    #                     components[newname]['artifactId']="org.apache.catalina.tomcat"
    #                     components[newname]['query']="org.apache.catalina.startup.Bootstrap start"
    #                     components[newname]['jmxport']= 'NA'
    #                     if QUERY is None:
    #                         QUERY = components[newname]['query']
    #                     if JMXPORT is None:
    #                         JMXPORT = components[newname]['jmxport']
    #                 elif 'asquery' in section.lower():
    #                     if 'AS_MEMBER_NAME' in section:
    #                         components[newname]['query']=parser.get(section,'value')
    #                         if QUERY is None:
    #                             QUERY = parser.get(section,'value')
    #                     if 'AS_LISTEN_URL_FOR_REMOTE' in section:
    #                         ## split tcp://${sfs_script_HOST_PRIVATE_IP}:16007
    #                         args=parser.get(section,'value').split(':')
    #                         components[newname]['jmxport']= args[len(args)-1]
    #                         if JMXPORT is None:
    #                             JMXPORT = components[newname]['jmxport']
    #                 elif 'UNIX_START_COMMAND_ARGS' in section:
    #                     #fdeploy.LOGGER.debug("%s store %s - - - -> %s" % (section, newname, parser.get(section,'value'))
    #                     args=parser.get(section,'value').split(' ')
    #                     if 'analytics' in newname.lower():
    #                         components[newname]['query']="com.fedex.sefs.analytics.AnalyticsDriver"
    #                         components[newname]['jmxport']= args[len(args)-1]
    #                     elif 'asmm' in newname.lower():
    #                         components[newname]['query']="java -jar asmm.jar"
    #                         components[newname]['jmxport']= ''
    #                     elif 'purge' in newname.lower():
    #                         components[newname]['query']='sefs_purge.zip_Files/scripts/startSilver.sh'
    #                         components[newname]['jmxport']= args[len(args)-1]
    #                     elif 'sefsosv' in newname.lower():
    #                         #fdeploy.LOGGER.debug("  >>", str(args), newname
    #                         #fdeploy.LOGGER.debug("  >>", str(components[newname])
    #                         components[newname]['query']="bin/%s" % artifactId
    #                         components[newname]['jmxport']= args[len(args)-2].split("=")[:2][1]
    #                         if QUERY is None:
    #                             QUERY = components[newname]['query']
    #                         if JMXPORT is None:
    #                             JMXPORT = components[newname]['jmxport']
    #                     else:
    #                         if len(args) != 0: # noargs found in start command
    #                             id=args[len(args)-1].split('.')
    #                             #fdeploy.LOGGER.debug(str(args), newname
    #                             #fdeploy.LOGGER.debug(str(components[newname])
    #                             components[newname]['query']= "%s -autojoin" % (id[1])
    #                             components[newname]['jmxport']= args[len(args)-3]
    #                             #fdeploy.LOGGER.debug(str(components[newname])
    #                             #sys.exit(1)
    #                         if QUERY is None:
    #                             QUERY = components[newname]['query']
    #                         if JMXPORT is None:
    #                             JMXPORT = components[newname]['jmxport']
    #                     #fdeploy.LOGGER.debug("\n\n" + str(components) + "\n"
    #                 elif 'AS_LISTEN_PORT' in section:
    #                     if not 'jmxport' in components[newname]:
    #                         args=parser.get(section,'value').split(' ')
    #                         components[newname]['jmxport']= args[len(args)-2]
    #                         if JMXPORT is None and components[newname]['jmxport'] is not None:
    #                             JMXPORT = parser.get(section,'value')
    #                 elif section.endswith('AS_LOG'):
    #                     #fdeploy.LOGGER.debug("%s store %s - - - -> %s" % (section, newname, parser.get(section,'value'))
    #                     #if not 'query' in components[newname]:
    #                     components[newname]['query']= parser.get(section,'value')
    #                     if QUERY is None and components[newname]['query'] is not None:
    #                         QUERY = parser.get(section,'value')
    #             #fdeploy.LOGGER.debug(str(components)
    #         elif current[0] == 'stack':
    #             #fdeploy.LOGGER.debug("her8: %s" % (components[newname])
    #             resource = "%s.%s.%s.allocationrules.ResourcePreferenceHostname.properties" % (current[0],current[1],current[len(current)-1])
    #             for nvp in parser.items(section):
    #                 if 'components' in nvp:
    #                     #fdeploy.LOGGER.debug("stack [%s] section; %s" % (newname,section)
    #                     for schedule in parser.get(section,'components').split(","):
    #                         tlm_name = schedule.split(';')[:1]
    #                         # add an index to the name if the name does not have an number at the end.
    #                         __new=self.get_new_name(tlm_name[0],comp_index-1)
    #                         #fdeploy.LOGGER.debug("%s ==> %s [%s]" % (__new,__new in components.keys(),components.keys())
    #                         if __new in components.keys():
    #                             #fdeploy.LOGGER.debug("\nfound host %s\n" % (parser.get(resource,'propertyValue'))
    #                             components[__new]['host'] = parser.get(resource,'propertyValue')
    #                             #fdeploy.LOGGER.debug(str(components[newname])
    #     if 'query' not in components[newname]:
    #         components[newname]['query']=QUERY
    #
    #     if len(components.keys()) < 1:
    #         raise Exception("ERROR: No tlm host found in TLM silver propeties file, check tlm_output.log")
    #     # for comp in components.keys():
    #     #     #if 'host' not in components[comp]:
    #     #         fdeploy.LOGGER.debug("[%10s] %s" % (comp,components[comp])
    #     return components
    #


def test():
    ##
    ## ANDREs-MacBook-Pro:python akaan$ export PYTHONPATH=`pwd`
    ## ANDREs-MacBook-Pro:python akaan$ python ldd/tibcoBEextractor.py
    ## Standalone testing of the routines
    ##
    logging.basicConfig(filename="test.log", level=logging.INFO)
    config_logger = ConfigLogger(logging)
    #extr = tibcoJAVAextractor("../../test/resources/sefs.AS.properties",'FXF','L1',config_logger)
    #extr = tibcoJAVAextractor("../../test/resources/gsefs.java.fxg.ASMM.properties",'FXF','L1',config_logger)
    extr = tibcoJAVAextractor("../../test/resources/gsefs.as.fxg.SDS_Proxy.properties",'FXF','L1',config_logger)
    #extr = tibcoJAVAextractor("../../test/resources/sefs.as.proxy.multipleinstances.properties",'FXF','L1',config_logger)
    fdeploy.LOGGER.debug("REPORT"
    fdeploy.LOGGER.debug("======"
    for c in extr.lookup.keys():
        fdeploy.LOGGER.debug("%20s %s" % (c,str(extr.lookup[c]))

#test()
