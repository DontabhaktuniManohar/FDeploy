import unittest2
import ldd
import json
import os
import fdeploy
from ldd.tibcoJAVAextractor import tibcoJAVAextractor
from ldd.tibcoBEextractor import tibcoBEextractor
from ldd.tibcoBWextractor import tibcoBWextractor
from ldd.tibcoASextractor import tibcoASextractor
from ldd.tibcoMiscextractor import tibcoMiscextractor
from ldd.lddPublisher import lddPublisher
from ldd.tibcoBWextractor import get_instance_names, get_app_name, get_num_of_instances, get_archive_name
from fdeploy.content.gavClass import gavClass
from fdeploy.content.contentClass import contentClass


class TestLddPublisher(unittest2.TestCase):

    options = {}
    extractor = None
    docs = None
    resolver = None
    lddService = None

    @classmethod
    def setUpClass(clz):
        #fdeploy.log()
        pass

    def setUp(self):
        cdw = os.path.abspath("%s/../../test/resources" % (os.getcwd()))
        self.options['nexusURL'] = 'file://%s/local' % (cdw)

        #fdeploy.LOGGER.debug(">>> init >>>"
        json_file = '../../test/resources/fxe-bw-sefsAutoDGFeed.json'
        bindings_file = [
            '../../test/resources/bw5/sefs_suAutoDGFeed_template.xml']
        # create artifact resovler with caching features.
        self.resolver = fdeploy.nexusVersionResolver(self.options,
                                                     fdeploy.useCache, 'target')
        self.extractor = lddPublisher('L1', {}, '', self.resolver)
        self.docs = ldd.read_bw_bindings(bindings_file, 'FXFShipFeed')
        self.lddService = lddPublisher('L1', self.options,
                                       'target', self.resolver)

    # bindings_files, tibcoxml, tlm_bindings,
    #     def __init__(self, bindings_files, tibcoxml, tlm_bindings, opco, level, artifactId, config_logger=None):
    def test_bw_doc_by_artifact(self):
        self.assertIsNotNone(self.docs)
        self.assertEqual(1, len(self.docs))

    def test_get_nof_instances(self):
        #fdeploy.LOGGER.debug(json.dumps(self.docs, indent=2)
        self.assertEqual(4, get_num_of_instances(self.docs[0]))

    def test_bw_get_app_name(self):
        name = get_app_name(self.docs[0])
        self.assertEqual('SUAutoDGFeed', name)

    def test_bw_get_archive_name(self):
        self.assertEqual('Process_Archive', get_archive_name(self.docs[0]))

    def test_bw_get_instance_names(self):
        instances, mapping = get_instance_names(self.docs, [])
        self.assertEqual(4, len(instances))
        self.assertEqual('SUAutoDGFeed-Process_Archive-3',
                         instances[3]['name'])
        self.assertEqual('SUAutoDGFeed-Process_Archive-2',
                         instances[2]['name'])
        self.assertEqual('SUAutoDGFeed-Process_Archive-1',
                         instances[1]['name'])
        self.assertEqual('SUAutoDGFeed-Process_Archive',
                         instances[0]['name'])

    def test_bw_get_instance_names_multidoc(self):
        bindings_files = ['../../test/resources/bw5/sefs_suAddress_template.xml',
                          '../../test/resources/bw5/sefs_suAddress_template2.xml',
                          '../../test/resources/bw5/sefs_suAddress_template3.xml']
        docs = ldd.read_bw_bindings(bindings_files, 'sefs_suAddress')
        self.assertEqual(3, len(docs))
        name = get_app_name(docs[0])
        self.assertEqual('SUAddress', name)
        self.assertEqual('SUAddress', get_app_name(docs[1]))
        self.assertEqual('SUAddress', get_app_name(docs[2]))
        instances,mapping  = get_instance_names(docs, [])
        self.assertEquals(9, len(instances))
        self.assertEqual('SUAddress-Process_Archive', instances[0]['name'])
        self.assertEqual('SUAddress-1-Process_Archive', instances[3]['name'])
        self.assertEqual('SUAddress-2-Process_Archive', instances[6]['name'])
        self.assertEqual('FXE_L4_FXE_BW_TLM_2', instances[0]['tlm'])
        self.assertEqual('FXE_L4_FXE_BW_TLM_2', instances[3]['tlm'])
        self.assertEqual('FXE_L4_FXE_BW_TLM_2', instances[6]['tlm'])

    def test_bw_get_instance_names_fxflegacyadapter_issue(self):
        bindings_files = ['../../test/resources/bw5/FXFLegacyTemplateL2.xml']
        docs = ldd.read_bw_bindings(bindings_files, 'FXFLegacyAdapter')
        self.assertEqual(1, len(docs))
        name = get_app_name(docs[0])
        self.assertEqual('FXFLegacyAdapter', name)
        instances = get_instance_names(docs)
        self.assertEquals(2, len(instances))
        self.assertEqual('FXFLegacyAdapter-FXFLegacyAdapter',
                         instances[0]['name'])
        self.assertEqual('FXFLegacyAdapter-FXFLegacyAdapter-1',
                         instances[1]['name'])

    def test_bw_get_instance_names_fxflegacyadapter_issue(self):
        bindings_files = ['../../test/resources/bw5/FXFLegacyTemplateL2.xml']
        docs = ldd.read_bw_bindings(bindings_files, 'FXFLegacyAdapter')
        self.assertEqual(1, len(docs))
        name = get_app_name(docs[0])
        self.assertEqual('FXFLegacyAdapter', name)

        targets = ['FXF_L2_FXF_BW_TLM_1@c000124.test.cloud.fedex.com',
                   'FXF_L2_FXF_BW_TLM_2@c000125.test.cloud.fedex.com']

        instances,mapping = get_instance_names(docs, targets)
        self.assertEquals(2, len(instances))
        self.assertEqual('FXFLegacyAdapter-FXFLegacyAdapter',
                         instances[0]['name'])
        self.assertEqual('FXFLegacyAdapter-FXFLegacyAdapter-1',
                         instances[1]['name'])
        self.assertEqual(mapping['FXF_L2_FXF_BW_TLM_1'],'c000124.test.cloud.fedex.com')
        self.assertEqual(mapping['FXF_L2_FXF_BW_TLM_2'],'c000125.test.cloud.fedex.com')
        self.assertEqual(mapping['c000124.test.cloud.fedex.com'],'FXF_L2_FXF_BW_TLM_1')
        self.assertEqual(mapping['c000125.test.cloud.fedex.com'],'FXF_L2_FXF_BW_TLM_2')
        self.assertEqual('FXF_L2_FXF_BW_TLM_1', instances[0]['tlm'])
        self.assertEqual('FXF_L2_FXF_BW_TLM_2', instances[1]['tlm'])
        self.assertEqual('FXF_L2_FXF_BW_TLM_1', instances[0]['tlm'])
        self.assertEqual('FXF_L2_FXF_BW_TLM_2', instances[1]['tlm'])
        self.assertEqual('c000124.test.cloud.fedex.com', instances[0]['host'])
        self.assertEqual('c000125.test.cloud.fedex.com', instances[1]['host'])

    def test_ldd_bw_fdeployBW(self):
        level = 'L4'
        fdl = fdeploy.fdeployLoader({'level': level})
        fdl.readDescriptors(['../../test/resources/bw5/FXE_SULEGACY.json'])
        comp = fdl.components[0]
        comp.source = './config.FXE/FXE_SULEGACY.json'
        artifact = comp.contents[0]
        targets = [
            "FXE_L4_FXE_BW_TLM_1@c0005131.test.cloud.fedex.com",
            "FXE_L4_FXE_BW_TLM_2@c0005132.test.cloud.fedex.com",
            "FXE_L4_FXE_BW_TLM_3@c0005133.test.cloud.fedex.com",
            "FXE_L4_FXE_BW_TLM_4@c0005134.test.cloud.fedex.com",
            "FXE_L4_FXE_BW_TLM_5@c0005135.test.cloud.fedex.com",
            "FXE_L4_FXE_BW_TLM_6@c0005136.test.cloud.fedex.com",
            "FXE_L4_FXE_BW_TLM_7@c0005137.test.cloud.fedex.com",
            "FXE_L4_FXE_BW_TLM_8@c0005138.test.cloud.fedex.com",
            "FXE_L4_FXE_BW_TLM_9@c0005139.test.cloud.fedex.com"
        ]
        query = self.lddService.fdeployBWQueryHost(level, comp, artifact, targets, 'c0005131.test.cloud.fedex.com')
        self.assertEqual(0, len(query))
        query = self.lddService.fdeployBWQueryHost(level, comp, artifact, targets, 'c0005132.test.cloud.fedex.com')
        self.assertEqual(3, len(query))
        self.assertEqual('SUAddress-Process_Archive', query[0]['name'])
        self.assertEqual('c0005132.test.cloud.fedex.com', query[0]['host'])
        self.assertEqual('SUAddress-1-Process_Archive', query[1]['name'])
        self.assertEqual('c0005132.test.cloud.fedex.com', query[1]['host'])
        self.assertEqual('SUAddress-2-Process_Archive', query[2]['name'])
        self.assertEqual('c0005132.test.cloud.fedex.com', query[2]['host'])
        query = self.lddService.fdeployBWQueryHost(level, comp, artifact, targets, 'c0005134.test.cloud.fedex.com')
        self.assertEqual(3, len(query))
        self.assertEqual('SUAddress-Process_Archive-2', query[0]['name'])
        self.assertEqual('c0005134.test.cloud.fedex.com', query[0]['host'])
        self.assertEqual('SUAddress-2-Process_Archive-2', query[2]['name'])
        self.assertEqual('c0005134.test.cloud.fedex.com', query[2]['host'])

        queue = []
        self.lddService.queue_query_request('publish',comp, artifact, level, targets, 'messages', queue)
        self.assertEqual(9, len(self.lddService.queue_ref))
        self.lddService.queue_query_request('unregister',comp, artifact, level, targets, 'messages', queue)
        self.assertEqual(18, len(self.lddService.queue_ref))
        fdeploy.LOGGER.debug(self.lddService.queue_ref)
        fdeploy.LOGGER.debug(queue)



if __name__ == '__main__':
    unittest.main()
