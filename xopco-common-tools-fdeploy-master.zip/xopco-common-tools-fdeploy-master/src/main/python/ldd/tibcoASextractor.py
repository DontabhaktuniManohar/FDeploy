import xmltodict
import os
import glob
import os.path
import ConfigParser
import fdeploy
import re
import logging
import pprint
import ldd
from ldd import get_new_name
from ldd.tibcoextractor import tibcoextractor


class tibcoASextractor(tibcoextractor):

    def __init__(self,sc_prop_file,opco, level,config_logger=None):
        super(tibcoASextractor,self).__init__(sc_prop_file, opco, level, config_logger, 'AS')
        return

    def getHostTranslationFromSilver(self,parser=None):
    # Define a dictionary of UNIQUE components|stacks based on properties passed in: [component|stack].APP.[common|UNIQUE]
        if parser is None:
            parser = self.__config__
        components = {}
        newname = None
        artifactId = None
        comp_index = 0

        contents=[]

        for section in parser.sections():
            if 'contentfiles' in section and artifactId is None and parser.has_option(section,'nexusArtifact'):
                artifactId=parser.get(section,'nexusArtifact')
                contents.append(artifactId)

        for artifactId in contents:
            comp_index = 0
            # find first name if most configs are in common section
            for section in parser.sections():
                current=section.split('.')
                if current[0] == 'stack':
                    resource = "%s.%s.%s.allocationrules.ResourcePreferenceHostname.properties" % (current[0],current[1],current[len(current)-1])
                    for nvp in parser.items(section):
                        if 'components' in nvp:
                            #fdeploy.LOGGER.debug("stack [%s] section; %s" % (newname,section)
                            for schedule in parser.get(section,'components').split(","):
                                tlm_name = schedule.split(';')[:1]
                                components[tlm_name[0]]=[]
                                # add an index to the name if the name does not have an number at the end.
                                __new=get_new_name(tlm_name[0],comp_index-1)
                                components[tlm_name[0]].append({ 'name' : __new, 'host' : parser.get(resource,'propertyValue') })
            for section in parser.sections():
                current=section.split('.')
                if len(current) == 3:
                    if current[0] == 'component' and current[len(current)-1] != 'common':
                        comp_index += 1
                        base_name=parser.get(section,'name')
                        newname=get_new_name(base_name,comp_index)
                        chash=components[newname][0]
                        chash['deployId']=newname
                        chash['artifactId']=artifactId
                        as_log_section="%s.%s.common.runtimevariables.AS_LOG" % (current[0],current[1])
                        as_log_section2="%s.runtimevariables.AS_LOG" % (section)
                        #fdeploy.LOGGER.debug("comp=%s, section=%s" % (section, as_log_section)
                        if parser.has_section(as_log_section2):
                            as_log_section = as_log_section2
                        if parser.has_section(as_log_section):
                            args=parser.get(as_log_section,'value')
                            chash['query']= args
                            chash['jmxport']= "NA"
                        else:
                            fdeploy.LOGGER.debug("no as_log section found for %s",section)
        comp_refs={}
        for ckey in components.keys():
            comp_refs[ckey]=components[ckey][0]
        components = comp_refs
        return components
