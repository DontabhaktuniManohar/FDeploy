import unittest2
import ConfigParser
import ldd
import fdeploy
from tibcoJAVAextractor import tibcoJAVAextractor
from tibcoBEextractor import tibcoBEextractor
from tibcoBWextractor import tibcoBWextractor
from tibcoASextractor import tibcoASextractor
from tibcoMiscextractor import tibcoMiscextractor
from tibcoextractor import tibcoextractor
from ldd import get_new_name
from ldd import get_base_components
from ldd import process_property_files
class TestExtractorMethods(unittest2.TestCase):


    def test_get_new_name(self):
        extractor = tibcoextractor('../../test/resources/gsefs.as.fxg.properties','FXG','L1')
        self.assertEquals('base_1', get_new_name('base',1))
        self.assertEquals('base', get_new_name('base'))
        self.assertEquals('base_1', get_new_name('base_1'))
        self.assertEquals('base_1', get_new_name('base_1',32))

    def test_get_base_components(self):
        parser = ConfigParser.ConfigParser()
        _files = ['../../test/resources/gsefs.as.fxg.properties','../../test/resources/sefs.admin.BW_TLM_VM.properties','../../test/resources/sefs.admin.BW_TLM.properties' ]
        parser.read(_files[0])
        components = get_base_components(parser)
        self.assertEquals(2, len(components.keys()))
        parser = ConfigParser.ConfigParser()
        parser.read(_files[1])
        parser.read(_files[2])
        components = get_base_components(parser)
        self.assertEquals(28, len(components.keys()))
        components, property_files = process_property_files(_files)
        fdeploy.LOGGER.debug(components.keys()[0])
        self.assertIsNotNone(components['FXE_BW_TLM_2'])
        self.assertEquals('FXE_BW_TLM_2', components['FXE_BW_TLM_2']['deployId'])
        fdeploy.LOGGER.debug(components['FXE_BW_TLM_1'])
        self.assertTrue('host' in components['FXE_BW_TLM_1'])
        self.assertTrue('host' in components['FXE_BW_TLM_2'])
        self.assertEquals('vrh00920', components['FXE_BW_TLM_2']['host'])
        self.assertEquals('irh00609', components['AS_FXG_SDS_2']['host'])

    def test_as_extractor_simple(self):
        extractor = tibcoASextractor('../../test/resources/gsefs.as.fxg.properties','FXG','L1')
        self.assertEquals(2, len(extractor.host_lookup.keys()))
        self.assertTrue( 'AS_FXG_SDS_1' in extractor.host_lookup.keys())
        rec=extractor.host_lookup['AS_FXG_SDS_1']
        self.assertEquals('AS_FXG_SDS_1', rec['name'])
        self.assertEquals('SDSActiveSpace', rec['artifactId'])
        self.assertEquals('irh00608', rec['host'])
        self.assertEquals('AS_FXG_SDS_1', rec['deployId'])
        self.assertEquals('/var/fedex/tibco/logs/fxg_ActiveSpaceSDS01_std.log', rec['query'])
        self.assertEquals('NA', rec['jmxport'])
        self.assertTrue( 'AS_FXG_SDS_2' in extractor.host_lookup.keys())

    def test_as_extractor_complex(self):
        extractor = tibcoASextractor('../../test/resources/sefs.as.properties','FXE','L1')
        self.assertEquals(8, len(extractor.host_lookup.keys()))
        self.assertTrue( 'AS_sefsConveyance1' in extractor.host_lookup.keys())
        rec=extractor.host_lookup['AS_sefsConveyance1']
        self.assertEquals('AS_sefsConveyance1', rec['name'])
        self.assertEquals('sefs_suActiveSpaces', rec['artifactId'])
        self.assertEquals('vrh00960', rec['host'])
        self.assertEquals('AS_sefsConveyance1', rec['deployId'])
        self.assertEquals('/var/fedex/tibco/logs/FXE_SEFS_CONVEYANCE_AGENT_1.log', rec['query'])
        self.assertEquals('NA', rec['jmxport'])
        self.assertTrue( 'AS_sefsConveyance8' in extractor.host_lookup.keys())
        rec=extractor.host_lookup['AS_sefsConveyance8']
        self.assertEquals('AS_sefsConveyance8', rec['name'])
        self.assertEquals('sefs_suActiveSpaces', rec['artifactId'])
        self.assertEquals('vrh00967', rec['host'])
        self.assertEquals('AS_sefsConveyance8', rec['deployId'])
        self.assertEquals('/var/fedex/tibco/logs/FXE_SEFS_CONVEYANCE_AGENT_1.log', rec['query'])
        self.assertEquals('NA', rec['jmxport'])


    def test_as_extractor_complex2(self):
        extractor = tibcoASextractor('../../test/resources/sefs.as2.properties','FXE','L1')
        self.assertEquals(2, len(extractor.host_lookup.keys()))
        self.assertTrue( 'AS_CustomerVisibility1' in extractor.host_lookup.keys())
        rec=extractor.host_lookup['AS_CustomerVisibility1']
        self.assertEquals('AS_CustomerVisibility1', rec['name'])
        self.assertEquals('sefs_suActiveSpaces', rec['artifactId'])
        self.assertEquals('erh00225', rec['host'])
        self.assertEquals('AS_CustomerVisibility1', rec['deployId'])
        self.assertEquals('/var/fedex/tibco/logs/FXE_SEFS_SU_CUSTOMERVISIBILITY_AGENT_1.log', rec['query'])
        self.assertEquals('NA', rec['jmxport'])


    def test_as_public_leech_extractor(self):
        extractor = tibcoJAVAextractor('../../test/resources/sefs.as.proxy.multipleinstances.properties','FXE','L1')
        self.assertEquals(2, len(extractor.host_lookup.keys()))
        fdeploy.LOGGER.debug(extractor.host_lookup.keys())
        self.assertTrue( 'AS_FXG_SDS_PROXY_2' in extractor.host_lookup.keys())
        rec=extractor.host_lookup['AS_FXG_SDS_PROXY_2']
        self.assertEquals('AS_FXG_SDS_PROXY_2', rec['name'])
        self.assertEquals('sefs_asProxy', rec['artifactId'])
        self.assertEquals('vrh00967', rec['host'])
        self.assertEquals('AS_FXG_SDS_PROXY_2', rec['deployId'])
        self.assertEquals('AS_FXG_SDS_PROXY_1 -autojoin', rec['query'])
        self.assertEquals('18541', rec['jmxport'])

    def test_java_asmm_extractor_complex(self):
        extractor = tibcoJAVAextractor('../../test/resources/gsefs.java.fxg.ASMM.properties','FXE','L1')
        self.assertEquals(1, len(extractor.host_lookup.keys()))
        fdeploy.LOGGER.debug(extractor.host_lookup.keys())
        self.assertTrue( 'JAVA_FXG_ASMM_1' in extractor.host_lookup.keys())
        rec=extractor.host_lookup['JAVA_FXG_ASMM_1']
        self.assertEquals('JAVA_FXG_ASMM_1', rec['name'])
        self.assertEquals('JAVA_FXG_ASMM_1', rec['deployId'])
        self.assertEquals('asmm', rec['artifactId'])
        self.assertEquals('srh00605', rec['host'])
        self.assertEquals('java -jar asmm.jar', rec['query'])
        self.assertEquals('0', rec['jmxport'])

    def test_java_analytics(self):
        extractor = tibcoJAVAextractor('../../test/resources/sefs.java.suDvisAnalytics.properties','FXE','L1')
        self.assertEquals(1, len(extractor.host_lookup.keys()))
        fdeploy.LOGGER.debug(extractor.host_lookup.keys())
        self.assertTrue( 'JAVA_sefsDvisAnalytics_1' in extractor.host_lookup.keys())
        rec=extractor.host_lookup['JAVA_sefsDvisAnalytics_1']
        self.assertEquals('JAVA_sefsDvisAnalytics_1', rec['name'])
        self.assertEquals('JAVA_sefsDvisAnalytics_1', rec['deployId'])
        self.assertEquals('sefs_analytics', rec['artifactId'])
        self.assertEquals('urh00609', rec['host'])
        self.assertEquals('com.fedex.sefs.analytics.AnalyticsDriver', rec['query'])
        self.assertEquals('25011', rec['jmxport'])

    def test_java_purge(self):
        extractor = tibcoJAVAextractor('../../test/resources/sefs.java.suDvisPurge.properties','FXE','L1')
        self.assertEquals(1, len(extractor.host_lookup.keys()))
        fdeploy.LOGGER.debug(extractor.host_lookup.keys())
        self.assertTrue( 'JAVA_sefsDvisPurge_1' in extractor.host_lookup.keys())
        rec=extractor.host_lookup['JAVA_sefsDvisPurge_1']
        self.assertEquals('JAVA_sefsDvisPurge_1', rec['name'])
        self.assertEquals('JAVA_sefsDvisPurge_1', rec['deployId'])
        self.assertEquals('sefs_purge', rec['artifactId'])
        self.assertEquals('urh00609', rec['host'])
        self.assertEquals('sefs_purge.zip_Files/scripts/startSilver.sh', rec['query'])
        self.assertEquals('24011', rec['jmxport'])

    def test_java_osv_boot(self):
        extractor = tibcoJAVAextractor('../../test/resources/sefs.java.osv-consolidation.properties','FXE','L1')
        self.assertEquals(1, len(extractor.host_lookup.keys()))
        fdeploy.LOGGER.debug(extractor.host_lookup.keys())
        self.assertTrue( 'JAVA_sefsOsvCons_1' in extractor.host_lookup.keys())
        rec=extractor.host_lookup['JAVA_sefsOsvCons_1']
        self.assertEquals('JAVA_sefsOsvCons_1', rec['name'])
        self.assertEquals('JAVA_sefsOsvCons_1', rec['deployId'])
        self.assertEquals('osv-consolidation', rec['artifactId'])
        self.assertEquals('c0004536', rec['host'])
        self.assertEquals('bin/osv-consolidation', rec['query'])
        self.assertEquals('10001', rec['jmxport'])

    def test_tomcat_asquery(self):
        extractor = tibcoJAVAextractor('../../test/resources/sefs.tomcat.ASQuery.properties','FXE','L1')
        self.assertEquals(3, len(extractor.host_lookup.keys()))
        fdeploy.LOGGER.debug(extractor.host_lookup.keys())
        self.assertTrue( 'ASQuery_tomcat3' in extractor.host_lookup.keys())
        rec=extractor.host_lookup['ASQuery_tomcat3']
        self.assertEquals('ASQuery_tomcat3', rec['name'])
        self.assertEquals('ASQuery_tomcat3', rec['deployId'])
        self.assertEquals('org.apache.catalina.tomcat', rec['artifactId'])
        self.assertEquals('urh00602', rec['host'])
        self.assertEquals('org.apache.catalina.startup.Bootstrap start', rec['query'])
        self.assertEquals('0', rec['jmxport'])

if __name__ == '__main__':
    unittest.main()
