#import fedex
import fdeploy
import xmltodict
import os
import os.path
import ConfigParser
import fdeploy
import re
import logging

def get_new_name(base_name, comp_index=None):
	if not base_name[-1].isdigit():
		if comp_index is not None:
			base_name = "%s_%s" % (base_name,comp_index)
	#fdeploy.LOGGER.debug("base_name : %s" % (base_name)
	return base_name

def get_base_components(parser, components=None):
	components = {} if components is None else components
	ref = []
	newname = None
	artifactId = None
	base_name = None
	comp_index = 0
	# find first name if most configs are in common section
	for section in parser.sections():
		current = section.split('.')
		if len(current) == 3 and current[0] == 'component' and current[len(current) - 1] != 'common':
			comp_index += 1
			base_name = newname
			newname = get_new_name(
				parser.get(section, 'name'), comp_index)
			ref.append(newname)
			components[newname] = {'deployId': newname}
	return components

def process_property_files(property_files):
	property_files = [property_files] if type(property_files) != list else property_files
	components = {}
	for _file in property_files:
		__config__ = ConfigParser.ConfigParser()
		if not os.path.isfile(_file):
			raise Exception("property file '%s' not existing or readable." % (_file))
		#fdeploy.LOGGER.debug("reading property file '%s'" % (_file)
		with open(_file) as fd:
			__config__.read(_file)
		components=get_base_components(__config__, components)
		comp_index = 1
	#fdeploy.LOGGER.debug(str(components.keys())

	# process each file seperatly to avoid section similarities
	for _file in property_files:
		__config__ = ConfigParser.ConfigParser()
		with open(_file) as fd:
			__config__.read(_file)
		for section in __config__.sections():
			#fdeploy.LOGGER.debug(newname, section
			current = section.split('.')
			resource = "%s.%s.%s.allocationrules.ResourcePreferenceHostname.properties" % (
				current[0], current[1], current[len(current) - 1])
			if current[0] == 'stack':
				resource = "%s.%s.%s.allocationrules.ResourcePreferenceHostname.properties" % (
					current[0], current[1], current[len(current) - 1])
				for nvp in __config__.items(section):
					if 'components' in nvp:
						#fdeploy.LOGGER.debug("stack [%s] section; %s" % (current[0],section)
						for schedule in __config__.get(section, 'components').split(","):
							stack_name = schedule.split(';')[:1]
							# add an index to the name if the name does not have an number at the end.
							__new = get_new_name(stack_name[0], comp_index - 1)
							#fdeploy.LOGGER.debug("%s ==> %s [%s]" % (__new,__new in components.keys(),components.keys())
							if __new in components.keys():
								#components[__new]['stack_name'] = current[1]
								#fdeploy.LOGGER.debug("\nfound host %s\n" % (parser.get(resource,'propertyValue'))
								components[__new]['host'] = __config__.get(
									resource, 'propertyValue')
	#fdeploy.LOGGER.debug("%s xx %s" % ('processed.', components)
	return components, property_files

def read_bw_bindings(bindings_files, artifactId):
	docs = []
	ii = 1
	for bindings_file in  bindings_files:
		if not os.path.isfile(bindings_file):
			raise Exception("Bindings XML File %s not existing or readable [%s]." % (bindings_file,bindings_files))
		fdeploy.LOGGER.debug("reading %s", bindings_file)
		with open(bindings_file) as fd:
			doc = xmltodict.parse(fd.read(), dict_constructor=dict)
			doc['instance']=ii
			doc['documentName']=bindings_file
			doc['artifactId']=artifactId
			ii+=1
			docs.append(doc)
	return docs



class ConfigLogger(object):
	def __init__(self, log):
		self.__log = log
	def __call__(self, config):
		self.__log.info("Config:")
		config.write(self)
	def write(self, data):
		# stripping the data makes the output nicer and avoids empty lines
		line = data.strip()
		self.__log.info(line)
