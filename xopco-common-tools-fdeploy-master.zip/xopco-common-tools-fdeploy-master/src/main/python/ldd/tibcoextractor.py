#import fedex
import fdeploy
import xmltodict
import os
import os.path
import ConfigParser
import fdeploy
import re
import logging
import ldd
#from ldd import load_properties


class ConfigLogger(object):
    def __init__(self, log):
        self.__log = log
    def __call__(self, config):
        self.__log.info("Config:")
        config.write(self)
    def write(self, data):
        # stripping the data makes the output nicer and avoids empty lines
        line = data.strip()
        self.__log.info(line)


class tibcoextractor(object):
    doc=[] # bindings document
    __config__=None
    host_lookup=None
    lookup = None
    opco=None
    level=None
    query_lookup = {}

    def __init__(self,sc_prop_file,opco, level,config_logger=None,ptype='Java'):
        fdeploy.LOGGER.debug("TIB-%s  - processing %s (%s)" ,ptype, sc_prop_file, type(sc_prop_file))
        __files = sc_prop_file
        if type(__files) is not list:
            __files = [sc_prop_file]
        self.__config__ = ConfigParser.ConfigParser()
        # setting default logger for tracing misconfigs
        if config_logger is None:
            logging.basicConfig(filename="tlm_output.log", level=logging.DEBUG)
            config_logger = ConfigLogger(logging)
        config_logger(self.__config__)

        if os.path.isfile('silver_process_list.txt'):
            self.query_lookup=fdeploy.load_properties('silver_process_list.txt')

        for _file in __files:
            if not os.path.isfile(_file):
                raise Exception("Java properties file %s not existing or readable." % (_file))
            try:
                self.__config__.read(_file)
            except TypeError as err:
                fdeploy.LOGGER.debug("failed to load '%s'... " ,tlm_bindings)
                raise err
        self.opco = opco
        self.level = level
        #fdeploy.LOGGER.debug(self.__class__.__name__
        #fdeploy.LOGGER.debug(str(self.__config__)
        if 'tibcoextractor' != self.__class__.__name__:
            #if 'tibcoBWextractor' != self.__class__.__name__:
            self.host_lookup = self.getHostTranslationFromSilver(self.__config__)
        else:
            self.host_lookup = []
        return

	# the default is parsing from the parser.
	def resolve_from_parser(self):
		return True

    def _debug_(self, *args):
        pass
        #fdeploy.LOGGER.debug(args
