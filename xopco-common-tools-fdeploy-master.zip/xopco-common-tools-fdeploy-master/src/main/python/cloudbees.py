import sys
import os
import getopt
import cloudbees
import requests
import fdeploy
import logging


# disable_warnings warnings SSL
try:
    requests.packages.urllib3.disable_warnings()
except AttributeError as ar:
    pass
# fdeploy revision
fdeploy_version = "fdeploy-${project.version} ${buildNumber.timestamp}"
fdeploy.MUTE_ALL=True
logging.basicConfig(format='')
#logging.getLogger('fdeploy').addHandler(logging.NullHandler())

def main(argv=None):
    os.environ['https_proxy']='https://internet.proxy.fedex.com:3128'
    os.environ['http_proxy']='http://internet.proxy.fedex.com:3128'
    if argv is None:
        argv = sys.argv
    current='.'
    pomfile='pom.xml'
    nexusURL='http://sefsmvn.ute.fedex.com:9999'
    nexusRepo='public'
    no_words=True
    fdeploy.MUTE_ALL=True
    try:
        opts, args = getopt.getopt(argv[1:], "hxd:u:vr:f:w")
    except getopt.error, msg:
        print "Usage: cloudbees.py [-d directory] [-f pomFileNanme] [-w] [-u nexusURL] [-r repositoryname] [-v] [-h]\n%s\n\n-h|--help      - this text" % (msg)
        print >>sys.stderr, msg
        print >>sys.stderr, "for help use --help"
        return 2
    for o, a in opts:
        if o in ("-h", "--help"):
            print __doc__
            sys.exit(0)
        elif o in ("-d"):
            current=a
        elif o in ("-f"):
            pomfile = a
        elif o in ("-u"):
            nexusURL=a
        elif o in ("-r"):
            nexusRepo=a
        elif o in ("-x","--version"):
            print "version: " + fdeploy_version
            sys.exit(0)
        elif o in ("-w"):
            no_words=False
        elif o in ("-v"):
            fdeploy.info("verbose is enabled.")
            fdeploy.MUTE_ALL=False
            fdeploy.logLevel= fdeploy.setLogLevel(4)
    cldbz = cloudbees.CloudBees(nexusURL,nexusRepo,no_words)
    print cldbz.nextVersion(current,pomfile)




if __name__ == "__main__":
    __args = sys.argv
    # strip of the test arguments and take
    # print str(__args)
    # n = 0
    # for i in __args:
    #     print "%2d -> %s" % (n, i)
    #     n+=1

    if __args[0]=='python -m unittest':
        __args = __args[2:] if 'TestCloudbees.TestCloudbees' in __args[1] else __args[5:]
        __args = __args[4:] if 'TestCloudbees.py' in __args[2] else __args
    else:
        pass
    exitcode=main(__args)
    if sys.argv[0]!='python -m unittest' and not sys.argv[0].startswith('suite'):
        sys.exit(exitcode)
