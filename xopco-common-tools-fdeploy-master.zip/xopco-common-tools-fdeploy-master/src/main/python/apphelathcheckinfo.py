import os
import fdeploy
import requests
import json
import re
global word1
class apphelathcheckinfo(object):
    def __init__(self):
        pass

    def tibco_be(self,v,rtvmap):
        found = None
        for keyvalues in v:
            if 'cmd' in keyvalues:
                word = keyvalues["cmd"]
                if (word.find(rtvmap['JMX_PORT']) != -1 and word.find('be-engine') != -1 and word.find(rtvmap['PU_NAME']) !=  -1 and word.find(rtvmap['LOGICAL_NAME']) !=  -1 ):
                    fdeploy.LOGGER.info( "info is retrieved from the probe and Process id is running ")
                    return True
        if found is None :
            fdeploy.LOGGER.info( "info is retrieved from the probe and Process id is NOT running ")
            return False
        return False


    def tibco_bw(self,v,rtvmap):
        found = None
        for keyvalues in v:
            if 'cmd' in keyvalues:
                word = keyvalues["cmd"]
                DOMAIN_NAME =  rtvmap['DOMAIN_NAME']
                DOMAIN_NAME1 = os.path.expandvars(DOMAIN_NAME)
                if (word.find('bwengine') != -1 and word.find(rtvmap['PROCESS_NAME']) != -1 and word.find(DOMAIN_NAME1) !=  -1 ):
                    fdeploy.info( "info is retrieved from the probe and Process id is running ")
                    return True
        if found is None :
            fdeploy.info( "info is retrieved from the probe and Process id is NOT running ")
            return False
        return False
    def java(self,v,rtvmap):
        found = None
        for keyvalues in v:
            if 'cmd' in keyvalues:
                word = keyvalues["cmd"]
                if (word.find(rtvmap['PROCESS_NAME']) != -1 ):
                    fdeploy.info( "info is retrieved from the probe and Process id is running ")
                    return True
        if found is None :
            fdeploy.info( "info is retrieved from the probe and Process id is NOT running ")
            return False
        return False

    def apphelathCheck(self,type,targets,rtvmap):
        status = False
        for target in targets:
            probeurl = ("https://%s:7002/probe" %(target.split("@")[1].split(":")[0]))
            print probeurl
            ret = requests.get(probeurl,verify=False)
            if ret.ok in [ 200, 201] or ret.ok == True:
                v = ret.json()
                if getattr(self, type)(v,rtvmap) == False:
                    return False
                else:
                    status = True
            else:
                fdeploy.LOGGER.error("probe: %s is DOWN.", probeurl )
        return status
