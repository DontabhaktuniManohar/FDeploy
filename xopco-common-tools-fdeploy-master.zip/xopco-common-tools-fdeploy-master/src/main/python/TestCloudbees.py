# -*- coding: utf-8 -*-
import codecs
import unittest2
import fdeploy.deployer
import pprint
from fdeploy import resolve_filter
import glob
import imp
import sys
import re
import copy
from io import TextIOWrapper, BytesIO

def addOrReplace(base, command):
    for c in command:
        base.append(c)
    #print "base: ", str(base)


def doCloudBeesRun():
    addOrReplace(sys.argv, ['-d', '../../test/resources'])
    runpy = imp.load_source('__main__', 'cloudbees.py')

class StdoutBuffer(TextIOWrapper):
    def write(self, string):
        try:
            return super(StdoutBuffer, self).write(string)
        except TypeError:
            # redirect encoded byte strings directly to buffer
            return super(StdoutBuffer, self).buffer.write(string)

class TestCloudbees(unittest2.TestCase):

    VERBOSE_LEVEL='-v'

    _original_argv_ = []

    def setUp(self):
        #print "sys.argv=%s" % (sys.argv)
        if len(self._original_argv_) < 1:
            self._original_argv_ = copy.deepcopy(sys.argv)
        #print "setUp: %s (class-argv=%s)" % (self, self._original_argv_)
        sys.argv = copy.deepcopy(self._original_argv_)
        self.options = {'nexusURL': 'http://sefsmvn.ute.fedex.com:9999'}

        pass

    def testTestCloudBeesIncrementorNoStdout(self):
        # setup the environment
        old_stdout = sys.stdout
        sys.stdout = StdoutBuffer(BytesIO(), sys.stdout.encoding)
        doCloudBeesRun()
        sys.stdout.seek(0)      # jump to the start
        out = sys.stdout.read() # read output
        # restore stdout
        sys.stdout.close()
        sys.stdout = old_stdout
        # do stuff with the output
        out = re.sub('\n', '', out)
        self.assertEquals('6.1.106', out)

if __name__ == '__main__':
    unittest.main()
