#!/bin/bash
#set -e

export PS4='+(${BASH_SOURCE}:${LINENO}): ${FUNCNAME[0]:+${FUNCNAME[0]}(): }'
#export PS4='+(\${BASH_SOURCE}:\${LINENO}): \${FUNCNAME[0]:+\${FUNCNAME[0]}(): }'
#set -xv
# command=%s:action=%s, on level
level=%s
APP_NM=%s
# ---- begin - data_wrapper_header.sh - source
#%secho "[ERROR]: $@"
#%secho "[INFO] : $@"
#%sset -xv
#%secho "[WARN] : $@"

set -m # Enable Job Control
_uuid="%s"
_workdir="%s"
_stagedir="%s"
_timeout="%s"
_archive_version="%s"
_archive_filename="%s"
_artifactId="%s"
_target_path="${_stagedir}/archives"

# Generating the current properties for this version
cat <<EOF > "${_stagedir}/${_archive_version}.properties"
#!/bin/bash
# Generated property file for application.
%s
EOF

# load the RTV's
source ${_stagedir}/${_archive_version}.properties

# expanding variables in YML
while read
do
    eval "echo \"${REPLY}\""
done < ${_workdir}/apps/${_uuid}/manifest.yml > ${_stagedir}/manifest.yml

echo "------generated manifest------"
cat ${_stagedir}/manifest.yml
echo "------generated manifest------"


hostname
which cf
cf_exists=${?}
if [[ "${cf_exists}" != 0 ]]; then
  echo "CloudFoundry_CLI was not found. Abort! (code=${cf_exists})"
  echo "Please export PATH with location of the cf binary (f.e: /opt/fedex/tibco/cf-cli/bin)"
  exit ${cf_exists}
else
  echo "CloudFoundry_CLI found at $(which cf)"
fi

echo "Login to ${DOMAIN}"
cf api https://${DOMAIN}
cf auth ${PCF_USER} ${PCF_PASSWORD}

echo "Set target space '${SPACE}'"
cf target -o ${EAI_NUMBER} -s ${SPACE}
if [[ "${?}" != 0 ]]; then
  echo "Error setting space ${SPACE} in org ${EAI_NUMBER}"
  exit 2
fi
