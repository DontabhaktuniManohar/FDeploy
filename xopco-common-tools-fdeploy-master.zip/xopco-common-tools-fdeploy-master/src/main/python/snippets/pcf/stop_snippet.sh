cf stop ${APP_NM}
