# --- upload ---
echo "app_exists_exit=${app_exists} - ${APP_NM} for ${APP_HOST} in ${DOMAIN}"
set -xv
if [[ "${app_exists}" -ne 0 ]]; then
    echo "Doing overwrite push as wip"
    cf p ${APP_NM}-wip -f  ${_stagedir}/manifest.yml -p ${_target_path}/${_archive_filename} --hostname ${APP_HOST}
    echo "Mapping overwrite route for wip"
    cf map-route ${APP_NM}-wip ${DOMAIN} -n ${APP_HOST}
    echo "Unmapping current active route for ${APP_NM}"
    cf unmap-route ${APP_NM} ${DOMAIN} -n ${APP_HOST}
    cf unmap-route ${APP_NM}-wip ${DOMAIN} -n ${APP_HOST}
    echo "Delete current active route for ${APP_NM}"
    cf delete-route -f ${DOMAIN} -n ${APP_HOST}
    cf delete -f ${APP_NM}
    cf rename ${APP_NM}-wip ${APP_NM}
else
    echo "Pushing ${_target_path}/${_archive_filename} in ${SPACE}"
    cf app ${APP_NM}-wip > /dev/null 2>&1
    wip_exists=${?}
    if [[ "${wip_exists}" -eq 0 ]]; then
      cf delete -f ${APP_NM}-wip
    fi
    cf p ${APP_NM} -f ${_stagedir}/manifest.yml -p ${_target_path}/${_archive_filename} --hostname ${APP_HOST} ${PCF_PUSH_OPTIONS}
fi
# --- end upload ---
