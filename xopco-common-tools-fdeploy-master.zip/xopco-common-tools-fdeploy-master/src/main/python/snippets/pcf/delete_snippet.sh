if [[ "${app_exists}" -ne 0 ]]; then
  cf delete -f -r ${APP_NM}
  echo "exit=$?"
fi
