# -*- coding: utf-8 -*-
import json
import unittest2
import re

test_eit_struct = {
 'project1' : [
  'tcp://mitsg.ute.fedex.com:52034',
  'tcp://mitsg.ute.fedex.com:52034'
 ]
}

class TestAppMd(unittest2.TestCase):

    def test_deconstruct(self):
        self.assertEquals('project1', test_eit_struct.keys()[0])
        for i in test_eit_struct.keys():
            for j in test_eit_struct[i]:
                tcp = re.sub(r'tcp://','',j).split(':')
                print "%s,%s,%s" % ( i, tcp[0], tcp[1])
