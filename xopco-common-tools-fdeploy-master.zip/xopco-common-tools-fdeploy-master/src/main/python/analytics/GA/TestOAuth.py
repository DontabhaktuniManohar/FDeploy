import unittest2
import fdeploy
import cloudbees
import os
import analytics
from analytics.GA.oauth2 import retrieve_authorization_code

# Google: analytics.write_key = 'UA-125042736-3'
analytics.write_key = 'UA-125042736-2'
analytics.client = 'analytics.GA'



class TestOAuth(unittest2.TestCase):

    def test_oauth(self):
        pass
        #retrieve_authorization_code()#



if __name__ == '__main__':
    unittest.main()
