# -*- coding: utf-8 -*-

from datetime import date, datetime
from dateutil.tz import tzutc
import logging
import json
from analytics.api_error import APIError
from analytics.version import VERSION
import time
from requests.auth import HTTPBasicAuth
from requests import sessions
import analytics
from requests.utils import quote
from analytics.utils import remove_trailing_slash
import socket
from analytics.GA.oauth2 import retrieve_authorization_code

_session = sessions.Session()

OAUTH_KEY='6be04acf939e049f2b4a11b7891c6726a93bb375'
DATASOURCE_ID='LQ9OLBDQR9aJVaEnPgiWFg'
#https://www.googleapis.com/analytics/v3/management/accounts/125042736/webproperties/UA-125042736-3/customDataSources/LQ9OLBDQR9aJVaEnPgiWFg/uploads?key=6be04acf939e049f2b4a11b7891c6726a93bb375


# https://developers.google.com/analytics/devguides/collection/protocol/v1/parameters#events

'''
body structure
{
  "anonymousId": null,
  "context": {
    "library": {
      "name": "analytics-python",
      "version": "1.2.9"
    }
  },
  "event": "Download Nexus",
  "integrations": {},
  "messageId": "113ca4cff-bab2-4dc0-8cd2-0f01f35878e9",
  "properties": {
    "category": "nexus",
    "label": "sefs-parent:1.1:com.fedex.sefs.common",
    "value": "True"
  },
  "timestamp": "2018-09-02T17:24:10.241Z",
  "type": "track",
  "userId": "ak751818@2018-09-02T11:24:07.854515",
  "writeKey": "QDujMBQsUavCKoRUpQpPnTeGcwoobbTR",
  "receivedAt": "2018-09-02T17:24:10.754Z",
  "sentAt": "2018-09-02T17:24:08.367Z",
  "originalTimestamp": "2018-09-02T11:24:07.854521-06:00"
}
'''

'''
{
  "body": {
    "cid": 3909169215,
    "ea": "Test Event Name",
    "ec": "All",
    "el": "event",
    "ev": 0,
    "qt": 3719,
    "t": "event",
    "tid": "UA-125042736-3",
    "v": 1
  },
  "headers": {
    "Accept-Encoding": "identity",
    "Content-Type": "application/x-www-form-urlencoded",
    "User-Agent": "Segment.io/1.0"
  },
  "method": "POST",
  "qs": {},
  "url": "https://ssl.google-analytics.com/collect"
}
'''
def post(write_key, host=None, **kwargs):
    """Post the `kwargs` to the API"""
    if analytics.write_key is None:
        return
    log = logging.getLogger('GA')
    body = kwargs
    body["sentAt"] = datetime.utcnow().replace(tzinfo=tzutc()).isoformat()
    url = remove_trailing_slash(host or 'https://www.google-analytics.com') + '/collect'
    body_list = [body]
    if 'batch' in body:
        body_list = body['batch']
    headers = {
        #'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'analytics-python/' + VERSION
    }
    for body in body_list:

        post_data = None
        if body['type'] == 'track':
            post_data = create_track_event(body)
        elif body['type'] == 'screen':
            # https://developers.google.com/analytics/devguides/collection/protocol/v1/devguide#screenView
            post_data = create_app_tracking(body)
        elif body['type'] == 'product':
            # https://developers.google.com/analytics/devguides/collection/protocol/v1/devguide#screenView
            gav="%s:%s:%s" % (body['artifactId'], body['groupId'], body['version']);
            with open('upload.csv', 'w') as outfile:
                # header csv
                outfile.write( "%s\n" % ("ga:productSku,ga:productName,ga:productBrand,ga:productCategoryHierarchy,ga:productVariant"))
                outfile.write( "%s,%s,%s,%s,%s" % (gav, body['artifactId'], body['groupId'], 'java', body['version']))
        else:
            continue
        #if post_data is None:
        #    continue
        log.debug('making event request: %s', post_data)
        res = None
        if body['type'] == 'product':
            files = {'upload_file': open('upload.csv','rb')}
            post_data = {'uploadType' : 'media', 'DB': 'photcat', 'OUT': 'csv', 'SHORT': 'short'}
            # UA-125042736-3
            # https://developers.google.com/apis-explorer/#p/analytics/v3/
            # https://developers.google.com/analytics/devguides/config/mgmt/v3/mgmtReference/management/uploads/uploadData
            url = remove_trailing_slash(host or 'https://www.googleapis.com') + "/upload/analytics/v3/management/accounts/125042736/webproperties/UA-125042736-3/customDataSources/LQ9OLBDQR9aJVaEnPgiWFg/uploads?key=" + OAUTH_KEY
            headers['Content-Type']='application/octet-stream'
            #https://www.lunametrics.com/blog/2016/06/15/extending-google-analytics-programmatic-data-import/
            res = _session.post(url, files=files, data=post_data, headers=headers, timeout=15)
            print res.__dict__
        else:
            res = _session.post(url, data=post_data, headers=headers, timeout=15)
        #log.info(res)
        if res.status_code == 200:
            log.debug('data uploaded successfully')
        else:
            try:
                print res
                payload = res.json()
                log.debug('received response: %s', payload)
                raise APIError(res.status_code, payload['code'], payload['message'])
            except ValueError as e:
                raise APIError(res.status_code, 'unknown', res.text)

#ga:productSku,ga:productName,ga:productBrand,ga:productCategoryHierarchy,ga:productVariant
#To upload the data to Google Analytics, simply POST your CSV to:
#https://www.googleapis.com/upload/analytics/v3/management/accounts/accountId/webproperties/webPropertyId/customDataSources/customDataSourceId/uploads
#Use the MIME Type application/octet-stream, where the webPropertyId is our Property ID (a.k.a. UA number or Tracking ID),
#the accountId is the middle numbers of our UA number (e.g. UA-XXXXXX-YY), and the customDataSourceId
# is our Data Source ID from earlier. Once we\u2019ve posted our data, Google Analytics will return
#an uploads resource with data specific to your freshly uploaded data set, or any errors that occurred.
def register_gav(groupId, artifactId, version):
    return 'upload.csv'

def create_product(body):
    #print str(body)
    return "v=1&t=event&tid=%s&cid=%s&ec=%s&ea=%s&el=%s&ev=%s&z=%s" % (analytics.write_key, 555,
        quote(body['properties']['category']),quote(body['event']),quote(body['properties']['label']),1,time.time())

def create_step(body):
    #v=%s&tid=%s&cid=%s&t=pageview&dh=%s&dp=%s&dt=%s
    return

def create_track_event(body):
    #print str(body)
    return "v=1&t=event&tid=%s&cid=%s&ec=%s&ea=%s&el=%s&ev=%s&z=%s" % (analytics.write_key, 555,
        quote(body['properties']['category']),quote(body['event']),quote(body['properties']['label']),1,time.time())

def create_app_tracking(body):
    return "v=1&t=screenview&tid=%s&cid=%s&an=fdeploy%s&av=%s&aid=%s&aiid=%s&z=%s" % (analytics.write_key, 555,
        fdeploy.version,socket.gethostname(),os.environ['USER'] ,time.time())
