# -*- coding: utf-8 -*-
import getopt
import analytics
import sys
import os
import fdeploy
import analytics
from fdeploy.segment import build_report

os.environ['HTTPS_PROXY'] = "http://internet.proxy.fedex.com:3128"
os.environ['HTTP_PROXY'] = "http://internet.proxy.fedex.com:3128"

def main(argv=None):
    if argv is None:
        argv = sys.argv
    fdeploy.segment.USE_ANALYTICS=True # globaly enabling analytics
    analytics.write_key = 'UA-125042736-3'
    fdeploy.segment.init()
    try:
        opts, args = getopt.getopt(argv[1:], "hn:s:m:b:a:")
    except getopt.error, msg:
        print "Usage: segment.py [-n name] [-s status] [-m message] [-b build_number] [-a author] [-h]\n%s\n\n-h|--help      - this text" % (msg)
        print >>sys.stderr, msg
        print >>sys.stderr, "for help use --help"
        return 2
    author = "NA"
    name = "job_name"
    status = "unknown"
    status_message = ""
    build_number = "#"


    for o, a in opts:
        if o in ("-h", "--help"):
            print __doc__
            sys.exit(0)
        elif o in ("-s"):
            status=a
        elif o in ("-m"):
            status_message = a
        elif o in ("-a"):
            author=a
        elif o in ("-b"):
            build_number=a
        elif o in ("-n"):
            name=a
    build_report(name, status, author, status_message, build_number)



if __name__ == '__main__':
    main(sys.argv)
