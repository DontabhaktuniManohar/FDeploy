 rm -fr *.zip *.py ldd fdeploy cloudbees ssh xmltodict request* config* fedex silverCon* snippets glob2 dns
