[ -e 'install.py' ] && rm 'install.py'
curl -fSL -R -o install.py "http://sefsmvn.ute.fedex.com/install.py"  && python install.py $@
