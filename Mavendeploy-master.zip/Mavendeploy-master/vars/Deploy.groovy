sh returnStatus: true, script: '''#!/bin/bash -e

echo -e "[userStarted]-[${userStarted}]"


if [ "${userStarted}" == "" ] ; then
    echo -e "EMPLOYEE ID MUST BE PUT TO DEPLOY"
    exit 1
fi

export userStarted
export BUILD_URL
export DeployModule=${DeployModule}

##############################################################################
# DEPLOY SOFTWARE
##############################################################################

sshKey="-i /home/jenkins/.ssh/id_rsa -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"
ssh epat@$HOSTNAME ${sshKey} "/opt/fedex/epat/scripts/build_scripts/ciDeploy.sh ${DeployModule} ${artifactID} ${fromLevel} ${toLevel} ${userStarted} ${BUILD_URL}"

'''
