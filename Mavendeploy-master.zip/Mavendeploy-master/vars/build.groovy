stage('build'){
    steps{
    
            mavenBuild("mvn clean source:jar package site -f ePAT/pom.xml \
-Denvironment=ci \
-Dmaven.test.skip=true \
-s /var/fedex/epat/shared/software/apache-maven-3.3.9/conf/settings.xml")

         }
}