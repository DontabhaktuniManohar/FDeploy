def call(body) {
// evaluate the body block, and collect configuration into the object
def config = [:]
body.resolveStrategy = Closure.DELEGATE_FIRST
body.delegate = config
body()
stage ('Clone') {
                    checkout([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'fd05e1f2-2aed-4b67-b55e-a96e82c14095', url: 'https://github.com/DontabhaktuniManohar/Mavendeploy.git']]])
                }
 
} 
